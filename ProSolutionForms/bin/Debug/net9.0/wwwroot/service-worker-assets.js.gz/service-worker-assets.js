self.assetsManifest = {
  "version": "8iTNnuDg",
  "assets": [
    {
      "hash": "sha256-IsM1UdhMPjCN5yD9EraLdftli5Oye8JLeFDIjF1qsEM=",
      "url": "ProSolutionForms.styles.css"
    },
    {
      "hash": "sha256-Nuu0BHvGBlwN6c5FSVjV9yxX0YPfwg3ufdOucRJCOz0=",
      "url": "_content/Microsoft.AspNetCore.Components.QuickGrid/Microsoft.AspNetCore.Components.QuickGrid.25o87uqmvr.bundle.scp.css"
    },
    {
      "hash": "sha256-tnamWuQ2F5I2J8hbtBt4/9i8Mb2y2o+9Tepj5tUrSdU=",
      "url": "_content/Microsoft.AspNetCore.Components.QuickGrid/QuickGrid.razor.js"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-XsRnQkvbM/leotRxAbM8p6giRHM1kT/1feTIEzpYil4=",
      "url": "_content/TinyMCE.Blazor/TinyMce.Blazor.lib.module.js"
    },
    {
      "hash": "sha256-MSQuUWmw/uBMui2/n4kdEKi0h5j0G+EuO1sM6KK6ltM=",
      "url": "_framework/Blazored.FluentValidation.x0xsecpmtx.wasm"
    },
    {
      "hash": "sha256-Dt7DBDag97mASqcSTSWerTCmGMiE8QnbGYMRbfGmqvQ=",
      "url": "_framework/FluentValidation.a26tmul8eq.wasm"
    },
    {
      "hash": "sha256-rvfJ4vWD9REicee49XUtbmMWVdG0gSGCfb9oZFv9gkY=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.esv38zo127.wasm"
    },
    {
      "hash": "sha256-+0pw8eh9ess7ISQ+PBhRIIUqqkQNxObNR00MmvBkPlY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.f7z3anr7a9.wasm"
    },
    {
      "hash": "sha256-QtQH0F71sC0xN/8FWFAnruXDnbOacIsCWaGtPYIgPHM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.aq1ir8e8pl.wasm"
    },
    {
      "hash": "sha256-noUQFi4aGw2cik5qKT8Af+4/PeJVQkTUYAWaM+ILXRQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.QuickGrid.yg4rrwb45o.wasm"
    },
    {
      "hash": "sha256-Rc0KH0I348MJ2xeFIvhkZOlzzGjJINVCTqBTFSEHTT4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.9j9suo3916.wasm"
    },
    {
      "hash": "sha256-AiM3JNbp4qT0SaXuzDaCVGS6hgR2t6Fh1T9u9NLXvx4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.m6tx7dtd50.wasm"
    },
    {
      "hash": "sha256-y+dm9A6GzSMucTLUWmYqGchCJxlAAIiPswzCO4UVFi0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.b0sosqcdpj.wasm"
    },
    {
      "hash": "sha256-RDzFNwWFeDHfByrpBjtoeDosPx0W+62WnUqQnxj4pzs=",
      "url": "_framework/Microsoft.AspNetCore.Components.cwj0bpb71v.wasm"
    },
    {
      "hash": "sha256-UKMDNOwtUqoY3t2M8WJf117cqjUiC8nYYosFnpq5OEQ=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.oekk764ms4.wasm"
    },
    {
      "hash": "sha256-ZIXaCwkw/nFJbQVtpXyC1p+/8+HBXuY23SvQp2APHug=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.wlxxhzcuy2.wasm"
    },
    {
      "hash": "sha256-QJKG5agfskYhNg4CWMzF8EqwsNALoPtT7h5pO9k6aHk=",
      "url": "_framework/Microsoft.CSharp.0krj4ve566.wasm"
    },
    {
      "hash": "sha256-/JOH4hVYQYfS3dxZN5BBSq5b4VCGwvr2bWFcj+qEoIU=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Abstractions.cadj2sz5n8.wasm"
    },
    {
      "hash": "sha256-BEoNVhAV4i+G5YAqzbai+OF7uVR5hrtn9oAcEMclubM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4a55sodx0u.wasm"
    },
    {
      "hash": "sha256-YusQfamnuoA29PdQga09PqG/YJjy3OiEdkJsX0j4Ik4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.2k9gr7miv3.wasm"
    },
    {
      "hash": "sha256-LNfpv2mp9iLubYbOanMsxfLMDF/r7dZx3+3uw9Nry4Y=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.w11q1ch9mx.wasm"
    },
    {
      "hash": "sha256-Gz/79hPuSyKY6a5aSVaMAe5dsL1kdUy+3H1STPOapgM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.l87hutdh9l.wasm"
    },
    {
      "hash": "sha256-r5rDX297wnZIRTez4Qs6sHJnEeYHF6hst+lzA1aqXL4=",
      "url": "_framework/Microsoft.Extensions.Configuration.jnmou9j50n.wasm"
    },
    {
      "hash": "sha256-urlRDIzsnt6SigwpgMw9kwiWTkp9fNKE637lqK2uueI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.uyeezc5cxb.wasm"
    },
    {
      "hash": "sha256-aJQNxSp9O/JQiS3YK/5aopK8Gx9JG4QRdv1gS5yxrqs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.w6rb25gv28.wasm"
    },
    {
      "hash": "sha256-bah0Nrrn3e58rFiSLwDvsBfKe36QdSXmzCEgTpT21KU=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.1308i1c1g1.wasm"
    },
    {
      "hash": "sha256-4kGt4NlVuOka96VH9u6FYRLyx4d5JA7tQ4Zyu33wYVs=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.2k5v83m7ze.wasm"
    },
    {
      "hash": "sha256-2MfNyn9lDk+FqKsWlv9LMlI3a6UAKU7zn6FPndY6yek=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.og5ud5mohu.wasm"
    },
    {
      "hash": "sha256-bXI40g7FV9Auzp7Gkf/qaOpV57AB9LC/77YgdkBPY6Y=",
      "url": "_framework/Microsoft.Extensions.Logging.95bgqrnv72.wasm"
    },
    {
      "hash": "sha256-kRIQ4HhyW0v7+i6zYTjl+BrSzIVS5rdciOLbrEa7+40=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.r95vt1inlr.wasm"
    },
    {
      "hash": "sha256-pnyeMavDPmoZSrcbVUR5oTMXXyZmckP6mmbo05pyQCg=",
      "url": "_framework/Microsoft.Extensions.Options.i5at4ga9io.wasm"
    },
    {
      "hash": "sha256-7VRR3wAuBLbJ6+oanznv5mQCqqMwXDYhYFvtXciSZBU=",
      "url": "_framework/Microsoft.Extensions.Primitives.bq6k0v7oj5.wasm"
    },
    {
      "hash": "sha256-RN8viNNg/Osljyrz0SoRUK6TTBv6eYU4nxc2iJ8mgZA=",
      "url": "_framework/Microsoft.JSInterop.0h2vlrw1wc.wasm"
    },
    {
      "hash": "sha256-+yETq3HNwmgPEHJePavXqUT5HcOeuur5PgP7H5vXEa4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.vzj7d1zf5j.wasm"
    },
    {
      "hash": "sha256-Yo7yLbCzyuItdqdLb8FoWGyyLhzpdzNo1Xt9w15FOQ8=",
      "url": "_framework/Microsoft.Net.Http.Headers.et8r51eav9.wasm"
    },
    {
      "hash": "sha256-Raj1ha4M/EXL7zvyW9Evn28B9GxWHE0gaLR/NXPSrdk=",
      "url": "_framework/Microsoft.VisualBasic.Core.bcw8auwqwc.wasm"
    },
    {
      "hash": "sha256-Wn1A97sEio88/HfvTRdDM1pgRek6RfaNgVkwzSIvIAw=",
      "url": "_framework/Microsoft.VisualBasic.ezua2clavb.wasm"
    },
    {
      "hash": "sha256-fpruv6j/oxW6ShRcvC3R4IzPnm84DB6isAtNqeHrgoU=",
      "url": "_framework/Microsoft.Win32.Primitives.2w82csd6tr.wasm"
    },
    {
      "hash": "sha256-sMbuu2+9aoI7Hg1VxqD7awy9/80c7+mSA2IpQJ9cIiw=",
      "url": "_framework/Microsoft.Win32.Registry.krtg4e9rjb.wasm"
    },
    {
      "hash": "sha256-4Lax9GIshWtdj7YwZSCPLrNpiQ/1tNRQxfxFJerjfYY=",
      "url": "_framework/ProSolutionForms.0k1csysk3b.wasm"
    },
    {
      "hash": "sha256-p/WgW4i8kuySBnFffTKdvPItFuyxcF25QVX+IzSVvHo=",
      "url": "_framework/ProSolutionForms.pw8d4qnclc.pdb"
    },
    {
      "hash": "sha256-wC6hefX/ulHEGaUYIqCLBwi7gA6hQNb0Wx8qMIV9z6s=",
      "url": "_framework/System.AppContext.ch56s52ual.wasm"
    },
    {
      "hash": "sha256-MY+U3ZlBY/4EXlPMdmcAcxpQ3PtuXA/QTcWMig4lBE4=",
      "url": "_framework/System.Buffers.tlm3i6pt76.wasm"
    },
    {
      "hash": "sha256-zNxb6Q2yWey9J5o05rp5/XN2BJbkCWxs9fMZt2D9QY8=",
      "url": "_framework/System.Collections.0loryrgbgz.wasm"
    },
    {
      "hash": "sha256-S34voGnBqYhqsh0kGAp9FGIPyRaYbwLbZnsMN94DxMQ=",
      "url": "_framework/System.Collections.Concurrent.jadgrn67lq.wasm"
    },
    {
      "hash": "sha256-R00latuvi3TzXKtyvI9Rq5n4jVFNbUQZq9lDQxMOIZY=",
      "url": "_framework/System.Collections.Immutable.9o9b1v73b4.wasm"
    },
    {
      "hash": "sha256-W1J4Nps6QP0Xd6+4fg8OERkjgk5aEPSkmvymvC2uHK8=",
      "url": "_framework/System.Collections.NonGeneric.3azrjxh966.wasm"
    },
    {
      "hash": "sha256-tQgQQ+/98VQfR8IGhcUhRrLTDaGfRA9fq7q/gouJUHs=",
      "url": "_framework/System.Collections.Specialized.pf8o02gi88.wasm"
    },
    {
      "hash": "sha256-A8/UlZ7726XTgBgUyeC2Bdqfj7cEw9Q6wkYX87lBc/w=",
      "url": "_framework/System.ComponentModel.1bvu7o7kso.wasm"
    },
    {
      "hash": "sha256-MEYu5tDNKAyvFF+LYTBPSN61MqizjOuE3FsQ62umVng=",
      "url": "_framework/System.ComponentModel.Annotations.ws0vg1jr4x.wasm"
    },
    {
      "hash": "sha256-ofRm47QJlEEj5/ditS6lJ/OFwN9GPd1orZrbk3184bY=",
      "url": "_framework/System.ComponentModel.DataAnnotations.dtsracnza3.wasm"
    },
    {
      "hash": "sha256-U3Mo8M3CzQRvY1qREaldjhXT4mKqxSEu8EHVu32yOQk=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.ra9xq384hx.wasm"
    },
    {
      "hash": "sha256-iA+b3OlObFpC0/Aif4wF6FSDtWOiEGsjHrpeZHYxOLY=",
      "url": "_framework/System.ComponentModel.Primitives.crjaxnx0st.wasm"
    },
    {
      "hash": "sha256-lbIwcqLYoaa5SNCjZPiTD8JT2JDAxgEIg0wVPo5FGf0=",
      "url": "_framework/System.ComponentModel.TypeConverter.z2oi73nl5l.wasm"
    },
    {
      "hash": "sha256-2w+W5e16+eBXhrOFFjDsiXmq54potpxISbp6U39bXAg=",
      "url": "_framework/System.Configuration.bcycfuj8pt.wasm"
    },
    {
      "hash": "sha256-QFSBCNk38q9aia7gARK8J/s1qkjRLWL/6CT+sepwTqY=",
      "url": "_framework/System.Console.w0ay1b4srp.wasm"
    },
    {
      "hash": "sha256-kcBybtj6CRk/fZvUnhTfjCPRJJWLJEuJJOZ+Yo8sLzU=",
      "url": "_framework/System.Core.hclyk32q51.wasm"
    },
    {
      "hash": "sha256-rDRPheqL0Y21f5bnN9z2/ttDPiYdxaaBxm0T0+PGHFM=",
      "url": "_framework/System.Data.8fnvbemkr6.wasm"
    },
    {
      "hash": "sha256-bQIenRafLaZWCon1qGPGOM4AkcfxOPUdBGuc5yrU9OA=",
      "url": "_framework/System.Data.Common.h7ixcjvq7n.wasm"
    },
    {
      "hash": "sha256-EiFxhIvAU86+kjjC6zLjLzNtl6+HquG/e2sKmB5YEHA=",
      "url": "_framework/System.Data.DataSetExtensions.27v8nihu4b.wasm"
    },
    {
      "hash": "sha256-bMz8wdeh6qh0Glsbnk9sqPBfIPz5R4Kx2n1t5fcfU08=",
      "url": "_framework/System.Diagnostics.Contracts.g37ic7xnxa.wasm"
    },
    {
      "hash": "sha256-sFy2+QBSQ1Hv4v3MgMWtpwuVqX0DPbTSM1HXp6FTjZo=",
      "url": "_framework/System.Diagnostics.Debug.cdnw9jdjr1.wasm"
    },
    {
      "hash": "sha256-BevUJO0S3Y7mVFaDzJsZ6eThyn0kC8HY1o3AHcarVFA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.3u89chdpwh.wasm"
    },
    {
      "hash": "sha256-gyGwoikjkAiRgOI79D9hrIfd5uJd7BDpQywb6stIQss=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.t8k8uawqmh.wasm"
    },
    {
      "hash": "sha256-/WQOeNwiRZiB86yHRrZqlmypYYJdcdzSvwSoLmNx+Oc=",
      "url": "_framework/System.Diagnostics.Process.nbu219jctg.wasm"
    },
    {
      "hash": "sha256-ExBa8DBK+IdPS6NcH/lR/EAeaPfjrGBdQaXgztPBKro=",
      "url": "_framework/System.Diagnostics.StackTrace.7f3f9acuyj.wasm"
    },
    {
      "hash": "sha256-a2hGEFZU4f3NY4AUor7hcjqxo2Kx2/xI2E3q/U3v89o=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.l8i9ben6g9.wasm"
    },
    {
      "hash": "sha256-BH1joZ5+NtBBPjrdr9kdXEySXjW3Yf+nQXS9sDWrMrM=",
      "url": "_framework/System.Diagnostics.Tools.su3q70cfjw.wasm"
    },
    {
      "hash": "sha256-cwFQXPENSGEB+XqxrrY7aDhsiFbS5BQ0TtGymIc6ubg=",
      "url": "_framework/System.Diagnostics.TraceSource.777sathwzn.wasm"
    },
    {
      "hash": "sha256-1qN0Q19TU45x/Im/t4R53BL6+iDetXv9BiK7uiI7K34=",
      "url": "_framework/System.Diagnostics.Tracing.qrb1u99ma2.wasm"
    },
    {
      "hash": "sha256-W7QQ6nE401Cz/DrtlEuOFnBu4MLcnIN48U/DOOUMPsY=",
      "url": "_framework/System.Drawing.5kh3shl062.wasm"
    },
    {
      "hash": "sha256-qNXMrmUu8VWriCVAjd4x99fJMlmg88PISG5YV9QHnPI=",
      "url": "_framework/System.Drawing.Primitives.wesyyx6itb.wasm"
    },
    {
      "hash": "sha256-s3Np2Puug4kgzoloDG0Das0RYCSUra8Dk+JuizZMNrw=",
      "url": "_framework/System.Dynamic.Runtime.zwh4o2uogo.wasm"
    },
    {
      "hash": "sha256-zOnjJI1BdX4xmiKvyb21glt7AlFwkyUpq2gjut26icU=",
      "url": "_framework/System.Formats.Asn1.sw73ne3kde.wasm"
    },
    {
      "hash": "sha256-kmIHH4nVicnYxBYQZxYcdf7Ts0e5MloHhlPGP0UTpF8=",
      "url": "_framework/System.Formats.Tar.ucentu0i1k.wasm"
    },
    {
      "hash": "sha256-uKcSR3IsbhlAmzUnOF8LoElE2AeDReUBqz7BT2j3i70=",
      "url": "_framework/System.Globalization.Calendars.wyl6b2gjv4.wasm"
    },
    {
      "hash": "sha256-iP8NezkN9pmUNO1m9fKv3XKdVd8dgqU5p7y8WXotrwI=",
      "url": "_framework/System.Globalization.Extensions.0at1e69ufq.wasm"
    },
    {
      "hash": "sha256-CmeYNP9tuEG8lzVcNAHnM0+pTDrPAEYaSW+UQnn7F0s=",
      "url": "_framework/System.Globalization.ea4xp7l2s8.wasm"
    },
    {
      "hash": "sha256-jBFM3N9fksCOsjJXa2ixhMgtpFpLsCoXaw2a2/5brH0=",
      "url": "_framework/System.IO.Compression.Brotli.4wfk96u424.wasm"
    },
    {
      "hash": "sha256-0Ww+n6u93HyjYEWEMJ9aK2XxqOUq7uAD0+C4VYvuP28=",
      "url": "_framework/System.IO.Compression.FileSystem.fga5z7h1wd.wasm"
    },
    {
      "hash": "sha256-mLtyFapE4sUoJ/7ppXE4Bap82l73KMQ4PLDvByk7WQA=",
      "url": "_framework/System.IO.Compression.ZipFile.kp8u44q6bl.wasm"
    },
    {
      "hash": "sha256-NWa/ooYeUbpjpI2vsZbyHIrQO+Q1bQBf4uI43t9LtV4=",
      "url": "_framework/System.IO.Compression.l063hh1m4m.wasm"
    },
    {
      "hash": "sha256-OM1a5nybzW5KJpJqWX40wqJVB1KXez2NHBwgy6181BI=",
      "url": "_framework/System.IO.FileSystem.AccessControl.gqo8i3yxtl.wasm"
    },
    {
      "hash": "sha256-QblxSOTsuEI65Dkn4KTsQ7Khcvt/vQstRLWH6jfeclI=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.1o666npdpl.wasm"
    },
    {
      "hash": "sha256-re/SYMTA3qOu0RU9/HZDNtDec+d2XzSAhk4l2VynKWI=",
      "url": "_framework/System.IO.FileSystem.Primitives.7j619s2u6b.wasm"
    },
    {
      "hash": "sha256-nqEW6A4CLNfm8yFpxPPoKxvy13Wm4PZjg09+SYzKlqA=",
      "url": "_framework/System.IO.FileSystem.Watcher.i0dqersjke.wasm"
    },
    {
      "hash": "sha256-NdJ+m1FPeukY0vhVF03iHZ8N4bfgDbGr6HcSW5IAtQQ=",
      "url": "_framework/System.IO.FileSystem.xd0pof1l0v.wasm"
    },
    {
      "hash": "sha256-MDpYXnYgTfAMlIi7P7dfB/HgtPEgsWeBIH72oaM5cFM=",
      "url": "_framework/System.IO.IsolatedStorage.86d2nxz30o.wasm"
    },
    {
      "hash": "sha256-bz2InjhxjJys3ql0UjqFJeGPj+Q20QBmYUVZwxNIC1U=",
      "url": "_framework/System.IO.MemoryMappedFiles.hwg4cmnexd.wasm"
    },
    {
      "hash": "sha256-mUhfk0EQo9xhQLG/6XzqLuCAj9BRsxwm0joy8t/pytc=",
      "url": "_framework/System.IO.Pipelines.hyk2aqc7g8.wasm"
    },
    {
      "hash": "sha256-VNK7ZAjEIuB4YolSq9QjtSMFnSedfh8Yu7fNjgervOg=",
      "url": "_framework/System.IO.Pipes.AccessControl.8jmdzj76k5.wasm"
    },
    {
      "hash": "sha256-Ogq9G2wgekC3/9PZg9C2vJNBxsVe88Ea+QNCDGDixGU=",
      "url": "_framework/System.IO.Pipes.itag36er3p.wasm"
    },
    {
      "hash": "sha256-Rc23C5bFm+NvhiYFb2F/JjnhLFVSER+Ebj/kNmY1zRA=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.xl34mv7373.wasm"
    },
    {
      "hash": "sha256-etjJtLeCDXgtTRWot03cMUjMbkzONxqD+7Rpu16Mc9w=",
      "url": "_framework/System.IO.a8lovankol.wasm"
    },
    {
      "hash": "sha256-t5Hx6teTiN+ss+MSc5UsLtUwusl0e5T8Lv+YwF6OOjc=",
      "url": "_framework/System.Linq.982cs7cwl7.wasm"
    },
    {
      "hash": "sha256-TCZ/AZRZm9MkZ9CRDzReCZbB85ijJmjxt5Pzb2GIJhY=",
      "url": "_framework/System.Linq.Expressions.keojcyx7rh.wasm"
    },
    {
      "hash": "sha256-0UxGkKXobQy7ybzPDsnLHKomY/CCVdUyKz4MI2+PT1w=",
      "url": "_framework/System.Linq.Parallel.rt0wj1di9x.wasm"
    },
    {
      "hash": "sha256-J2Blxrg/WYao64RgUe4cap1lRDM8fJnBJi5vEkw7b7w=",
      "url": "_framework/System.Linq.Queryable.xmuj2bfl3h.wasm"
    },
    {
      "hash": "sha256-WmXCKPUHRXCk0NlBi7iFCKUV1GLvpdRos4N6EMmHeNo=",
      "url": "_framework/System.Memory.e21pxyo7f6.wasm"
    },
    {
      "hash": "sha256-Ir1YjR5eIiNstQ14NSwsMO+GjAAiPYcFadrDElTMXNk=",
      "url": "_framework/System.Net.Http.67y0knk64j.wasm"
    },
    {
      "hash": "sha256-dSSvmKzciY92FqsRlD04+cQ1/xJwR1wlCMsNwG2Irik=",
      "url": "_framework/System.Net.Http.Json.158hlj0e3x.wasm"
    },
    {
      "hash": "sha256-+v7c/NCAqhai/cqsi10INRyfL56wed+scAI4jUZ1L3k=",
      "url": "_framework/System.Net.HttpListener.6kj06u2myw.wasm"
    },
    {
      "hash": "sha256-zHyOFCZxXJzndlJY1B0lS4nInYkm/tvKFbcsiv+wK5w=",
      "url": "_framework/System.Net.Mail.of8mvgjv93.wasm"
    },
    {
      "hash": "sha256-tOv/V4XH5WxxREP6fBXdKcukomwgzvv/08ookA7C8qM=",
      "url": "_framework/System.Net.NameResolution.ojvc5fs9x8.wasm"
    },
    {
      "hash": "sha256-1RIK76qrAuN9Ls8QzpMjvFlZckmyeZjDOo8NwvkLMXM=",
      "url": "_framework/System.Net.NetworkInformation.h55ndb6w9r.wasm"
    },
    {
      "hash": "sha256-XdueAWf5/NGXPXSAjHI8Brqw7V3jOzsoyePO8aGv6Ls=",
      "url": "_framework/System.Net.Ping.f5i7hfw2qc.wasm"
    },
    {
      "hash": "sha256-42JPWogxvNPLq4quzArZWkG/QsqUWWm86Cj4C4D1sa8=",
      "url": "_framework/System.Net.Primitives.ppkhii4grn.wasm"
    },
    {
      "hash": "sha256-QkEPh3PvrI4dPDLIpgTygLkFTcEVkrTUCZNEsX+w9JU=",
      "url": "_framework/System.Net.Quic.6n4jzsrw88.wasm"
    },
    {
      "hash": "sha256-rJcamXzNO1ekGh8RWXMtOh+N8AAGY4aWd8SEibSO+N0=",
      "url": "_framework/System.Net.Requests.cy4h9bs3pl.wasm"
    },
    {
      "hash": "sha256-7pBbQ3JNwdsbpSCe64kP6y5J3WNLl0geBY2nyCObfE8=",
      "url": "_framework/System.Net.Security.ibdm0dxxqk.wasm"
    },
    {
      "hash": "sha256-m5RH4cT0q+UB9jZ3rXwBoaHGOGdAKuuSmSSWCEErWgs=",
      "url": "_framework/System.Net.ServicePoint.fb4vl6a7xv.wasm"
    },
    {
      "hash": "sha256-4loqakg4OHudAmPhC2qqNk5yivAJgeY4olQhpTDuIdM=",
      "url": "_framework/System.Net.Sockets.in1jyhlij3.wasm"
    },
    {
      "hash": "sha256-37mgTGMpzPm8MccRDW6zSigCf8aCYtmng8w3m6opE/Y=",
      "url": "_framework/System.Net.WebClient.pe57fwwtmc.wasm"
    },
    {
      "hash": "sha256-cI0IR9id1UGuk7V/GiCcwz4NTh6H4x5ZCjMWoOdUf5I=",
      "url": "_framework/System.Net.WebHeaderCollection.8q2vnfgdag.wasm"
    },
    {
      "hash": "sha256-hY5FTAGWLF1e594jinkACgApEoPmkwd4DlvtQnFrv7I=",
      "url": "_framework/System.Net.WebProxy.dy3uj3cuhy.wasm"
    },
    {
      "hash": "sha256-gU7BySBDk/czIunWAoDJBBn1lQEstVT2CLFWqGVdXBg=",
      "url": "_framework/System.Net.WebSockets.Client.5n8jkuhz18.wasm"
    },
    {
      "hash": "sha256-8hEFPzMud0UFQVWGQri3oLxzgxxPYWdymB7jf0vzF3k=",
      "url": "_framework/System.Net.WebSockets.eth3pjb0i0.wasm"
    },
    {
      "hash": "sha256-9qq9GGIui5WYuj05+rEWDETzM2PLIJrQ0e8eGDnsgd4=",
      "url": "_framework/System.Net.uvxuq9ftj8.wasm"
    },
    {
      "hash": "sha256-wR1QIPtgAB4/lGcKQgFudx5l4L1TCTTOIcAJxjagJoU=",
      "url": "_framework/System.Numerics.Vectors.xwm370m73u.wasm"
    },
    {
      "hash": "sha256-bPuY4jEgjX3yU5McFGiZOwlVGH/KLTKlzE5egxmkdtE=",
      "url": "_framework/System.Numerics.sa5zv0szr0.wasm"
    },
    {
      "hash": "sha256-+TUb+XSkf4I8OhmpoNR9TyRK+HIr3rRAdgA/hGUh4rk=",
      "url": "_framework/System.ObjectModel.55syvdebib.wasm"
    },
    {
      "hash": "sha256-iqXECPj8uFcb/7OzD0dDXV+C8VvMmS7RYZ6ZUnFdlTs=",
      "url": "_framework/System.Private.CoreLib.u3k7k03qne.wasm"
    },
    {
      "hash": "sha256-cxf7wW1ItVLs9wxdXgkCVuE9ixVZ/7F0GD3aJLGc5Y0=",
      "url": "_framework/System.Private.DataContractSerialization.h3lzbevrhq.wasm"
    },
    {
      "hash": "sha256-u8os5WkllHqDK95zgG7EL7Gcn5aNNmwVgt0HuritLgM=",
      "url": "_framework/System.Private.Uri.h9vk2avn0v.wasm"
    },
    {
      "hash": "sha256-0Zkg5yF1TaIbfyQVhVERiYqSyHwjjLkiyxuzf71HwHM=",
      "url": "_framework/System.Private.Xml.9m32bkuaq9.wasm"
    },
    {
      "hash": "sha256-49bEelPi/IOYMUy6ONqfW30KBK9PQeFtzie1HtJkEz4=",
      "url": "_framework/System.Private.Xml.Linq.x7s9isnak8.wasm"
    },
    {
      "hash": "sha256-d47g6JYxmJyoiBxLTpcVwvykP3iI1cG55cNoIOhrQPI=",
      "url": "_framework/System.Reflection.DispatchProxy.1mvitd31h1.wasm"
    },
    {
      "hash": "sha256-qhWoKLKLRFAAu8x/U9eNzZEjZKk2Qo+7T1bDwP0alZg=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.6hwdc9qxly.wasm"
    },
    {
      "hash": "sha256-LQW1zV195d2m2wOfYbSJ0DMYK4vyxjcY7GZvkfTQ08M=",
      "url": "_framework/System.Reflection.Emit.Lightweight.reku4tedat.wasm"
    },
    {
      "hash": "sha256-WiFnjtq0lMc+LqArnFe5Pf/Xc1+uPIp2O22ycbMtKh0=",
      "url": "_framework/System.Reflection.Emit.ejqw77rpzl.wasm"
    },
    {
      "hash": "sha256-6vkCMdZvArRCmUTWE/d8xZTJnT8/EG3IM1x6Ibpm+uA=",
      "url": "_framework/System.Reflection.Extensions.6pmkengf2g.wasm"
    },
    {
      "hash": "sha256-s48s0oTM6p3Cp1rRbepFrVrllW+oHLFbHr0tYswY1fw=",
      "url": "_framework/System.Reflection.Metadata.17tmzwz2au.wasm"
    },
    {
      "hash": "sha256-09+fcB0s+D8FmQr7mLAg8gl/gcPw7qz6z0sKHL/iQps=",
      "url": "_framework/System.Reflection.Primitives.b2osjpgeyo.wasm"
    },
    {
      "hash": "sha256-voyi3UjdlBq1uElH8sHEdXshHHrh9rq880LpLm5t9q4=",
      "url": "_framework/System.Reflection.TypeExtensions.elsa09wwcc.wasm"
    },
    {
      "hash": "sha256-YMbJmh96SPHMqeN13OGN7rFSgYknRzHfsSuE2Scycb8=",
      "url": "_framework/System.Reflection.wo2kjrze7x.wasm"
    },
    {
      "hash": "sha256-/Kpn9QoktmfrUJcoDIzXwjKv+yH2+lpfa9sxRWli4ew=",
      "url": "_framework/System.Resources.Reader.09wnmnw7h6.wasm"
    },
    {
      "hash": "sha256-f1qtSs4oIK7eVKXX2ZkgTj5GqfLYi3TXoND29mZ1Y/4=",
      "url": "_framework/System.Resources.ResourceManager.9uorrdaogh.wasm"
    },
    {
      "hash": "sha256-LHsRXI9207NVVm81YPLmiNikIYYiXzPSw45X8MueLaY=",
      "url": "_framework/System.Resources.Writer.4ao90ee7f8.wasm"
    },
    {
      "hash": "sha256-X4iXiK7XlfaL9/oRaMNEwOyFW5APbQ0jyE8f5cpeqoo=",
      "url": "_framework/System.Runtime.9idl43ts3r.wasm"
    },
    {
      "hash": "sha256-xnAgqgTwMzqhQSv0tUTOYBz0X3JxqXOCoH+vRZU4RE4=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.mtlbkuc7bx.wasm"
    },
    {
      "hash": "sha256-NUOuqO8WgcXpNt4/3SNHvGr+z2wb030WyafdjI7vsHM=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.ropftsemtf.wasm"
    },
    {
      "hash": "sha256-WPYOiQCm1/mKP5sZU8AZTdRAnv2AXLw8Xt2BolVzot4=",
      "url": "_framework/System.Runtime.Extensions.849myor78y.wasm"
    },
    {
      "hash": "sha256-YXzj9v7a0buVMm+DZ0DtkScZS/ZbUrHJOt3qcYtnYVY=",
      "url": "_framework/System.Runtime.Handles.fg5kz6lkg1.wasm"
    },
    {
      "hash": "sha256-THDhGf9BCrSJ9Dc4HuyDmNhbdBrcxGQkVTrjqgSlJ5Y=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.wts7elsoj1.wasm"
    },
    {
      "hash": "sha256-KOSatT2XMoxuYPGOcEkfLE2IpYnEDNxRKWjtbtNoEk0=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.wikdnhmugy.wasm"
    },
    {
      "hash": "sha256-MPwfthOtcSQtbc/cQkRvLBNai04LM6OrplBwd7QEVx0=",
      "url": "_framework/System.Runtime.InteropServices.k720ljpkms.wasm"
    },
    {
      "hash": "sha256-NOpY3AgcjrPBOsaSW1QkhhgP3Kvxnf9fssCYKj5jF+0=",
      "url": "_framework/System.Runtime.Intrinsics.o9fm7inv0s.wasm"
    },
    {
      "hash": "sha256-vxCtf5sDS2iRg3+5697ErKB9phlMN1qQW7yqx69NLjk=",
      "url": "_framework/System.Runtime.Loader.5z1xrbq3gs.wasm"
    },
    {
      "hash": "sha256-kLp+41MKw6HJWd6tTF6QTSUe/HfRkMrDyYqQkf3E4HU=",
      "url": "_framework/System.Runtime.Numerics.0w7idgmm8c.wasm"
    },
    {
      "hash": "sha256-VsWXsk6PwS0/Bt2eb09pk/bNJWpOnyi2hRbGKimcBVo=",
      "url": "_framework/System.Runtime.Serialization.6caw9o814c.wasm"
    },
    {
      "hash": "sha256-ZGVgADzjjZBikZmXDKy0yg0e0H4itJO4/XpT9AbdCN8=",
      "url": "_framework/System.Runtime.Serialization.Formatters.gphf6qnq65.wasm"
    },
    {
      "hash": "sha256-ivo1Fw+p2RfT8eThu1+WB7L1ndlVFRhbnOPx5jKNaVA=",
      "url": "_framework/System.Runtime.Serialization.Json.uy989eosch.wasm"
    },
    {
      "hash": "sha256-JfbkAYZDOkSt3lg0WyuE0t9CBWqlV2+Sz7IQBG7Yzbw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.3q7zsjzsco.wasm"
    },
    {
      "hash": "sha256-iyVbGnMfkGVjX7fB+votSNmvk5Cdg1c4lhZVX0gk4Ws=",
      "url": "_framework/System.Runtime.Serialization.Xml.fn44d6rik8.wasm"
    },
    {
      "hash": "sha256-ddrVHQAWJ00p0PHXfwp3OJb3O1BO2Fie+YaHJzMzPeQ=",
      "url": "_framework/System.Security.AccessControl.lsn0iceylj.wasm"
    },
    {
      "hash": "sha256-1dJ+cVj/rQQ+kV6HwAdtA5GviyB/KKLkyhyAW2IYjaI=",
      "url": "_framework/System.Security.Claims.tinfecfh1e.wasm"
    },
    {
      "hash": "sha256-+MW/+T6wYCj9GlFr9DjBKjWZLi0jPcZ1M/NlD6PSqPg=",
      "url": "_framework/System.Security.Cryptography.Algorithms.szchu0omsd.wasm"
    },
    {
      "hash": "sha256-fe2mjNvJaNpi4U0yJTxo/QpWJgpFOYP8Cap4hsB2om0=",
      "url": "_framework/System.Security.Cryptography.Cng.tg2su1vayp.wasm"
    },
    {
      "hash": "sha256-bTtmZvfyggr9LLY1sMefJbGCWFYxQ+7pUg1YN/CYBrI=",
      "url": "_framework/System.Security.Cryptography.Csp.vdqwngku20.wasm"
    },
    {
      "hash": "sha256-B7kX2rvGpqfY2RAyR3Xh3x5J1M4foDmfPbTwofzaLQA=",
      "url": "_framework/System.Security.Cryptography.Encoding.tnqstt8i3f.wasm"
    },
    {
      "hash": "sha256-c8HVbnFyhQg3Cm2GbnWLnSVuO1gbkSLMHdlP03TO++M=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.vd4tq7rihd.wasm"
    },
    {
      "hash": "sha256-JPf/vhIAEtp+t6FVYvFTh8SLDgsXK1r8XwI9MFISUro=",
      "url": "_framework/System.Security.Cryptography.Primitives.sio8tbcv7y.wasm"
    },
    {
      "hash": "sha256-ZZ8Ecr63PHOy0BzB2+0w4HRaa4yqeNOj2MuXyBjiM/k=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.vfqfhnkej8.wasm"
    },
    {
      "hash": "sha256-KZrmyjsMG35zXmaE6ja3bAgvlV2yQAhof7b7gEBnrZY=",
      "url": "_framework/System.Security.Cryptography.l5u6gnf096.wasm"
    },
    {
      "hash": "sha256-7Dg5E/Jv0cPLM/oqKmrhCZQuk8o0LWNa8eJQ7JCtGOY=",
      "url": "_framework/System.Security.Principal.8v7pzc6f0d.wasm"
    },
    {
      "hash": "sha256-9/sekOHja++s1vYaDtM6HT0lOJeJyoo32HFdiLurLfM=",
      "url": "_framework/System.Security.Principal.Windows.ldi42vnlz2.wasm"
    },
    {
      "hash": "sha256-IR9DwKehFTc4AA1gM55e136hedy52EntxeZI4S6j6TI=",
      "url": "_framework/System.Security.SecureString.xw0y2dxlhg.wasm"
    },
    {
      "hash": "sha256-03t1x8je5QIU19rEfnEsBqUbj2Azcg1E4phQkfXC2UA=",
      "url": "_framework/System.Security.fl5q9pzcow.wasm"
    },
    {
      "hash": "sha256-6c3PdGeNbXjQvdEOjnNhyB7hx6ti5dO5lOcgQB4ebWM=",
      "url": "_framework/System.ServiceModel.Web.nk3wk16ns8.wasm"
    },
    {
      "hash": "sha256-0A7zR9riAw51MjVpAtACWjHLfXfdJyF6KykKisSIUx0=",
      "url": "_framework/System.ServiceProcess.4n5pile68t.wasm"
    },
    {
      "hash": "sha256-B1yymCKqgbZ9zbCyB/W9ocbiV3wdl4+gRJItY2umDSc=",
      "url": "_framework/System.Text.Encoding.7kzst7stdn.wasm"
    },
    {
      "hash": "sha256-jrT08/NjUv6+v0QZvlXVgYQVnMoHa7s1GdZdaBXW5Y4=",
      "url": "_framework/System.Text.Encoding.CodePages.ykcj58k0je.wasm"
    },
    {
      "hash": "sha256-ay1hiCOn7mQBiUx1EMkcC92PfuWozE7fZnUzpriCU/s=",
      "url": "_framework/System.Text.Encoding.Extensions.nlydxjh19m.wasm"
    },
    {
      "hash": "sha256-VNMxVpfZKD7wg/4o2z+8xT4gLGCwu967evaVA2zsoMs=",
      "url": "_framework/System.Text.Encodings.Web.grd8pnwzq5.wasm"
    },
    {
      "hash": "sha256-NR8eOBenFgH0oaEXT8zDpgAEqtNlpnM4orufS8CHdtk=",
      "url": "_framework/System.Text.Json.j2r3lclw18.wasm"
    },
    {
      "hash": "sha256-FAZui2n1Y5pZx16yb867GHgo/Ml9aNjvdkZLyB1KphE=",
      "url": "_framework/System.Text.RegularExpressions.gtbtxpqvsh.wasm"
    },
    {
      "hash": "sha256-Zs1dyDHECsvmoSvywTXACBabgK0uR6YeOqdkpU24O2g=",
      "url": "_framework/System.Threading.Channels.6ly6a97nsg.wasm"
    },
    {
      "hash": "sha256-Yx1D0yUjr5Ibvl/nAHTJaa1b4rflinXkM9KFQG/SCPI=",
      "url": "_framework/System.Threading.Overlapped.vhe0cauobg.wasm"
    },
    {
      "hash": "sha256-GoERtTKb8W4nbZT93d+optrQ/Jv4f9pU7acTQqHdAAY=",
      "url": "_framework/System.Threading.Tasks.Dataflow.uf2vj8lolq.wasm"
    },
    {
      "hash": "sha256-tLB6J6lcWykITLdTrLINFi7VE5h/Bn2eTFp+3uegOfU=",
      "url": "_framework/System.Threading.Tasks.Extensions.ovsq4u2j97.wasm"
    },
    {
      "hash": "sha256-PahrtXZJtg7x92RDZD9pvhQ7F6YFhcsTSvT2dVnFIlk=",
      "url": "_framework/System.Threading.Tasks.Parallel.buo4hciu3w.wasm"
    },
    {
      "hash": "sha256-obzl5Tr7ZUGu67PhpP/RMSaAY32BgeQWfH/eS7FDjWE=",
      "url": "_framework/System.Threading.Tasks.fc2uoh6qo1.wasm"
    },
    {
      "hash": "sha256-Gtq5BMvRXZSd5+cE2kyk3DYdB0uo6/imn62TkihOZKE=",
      "url": "_framework/System.Threading.Thread.i99sw2awmh.wasm"
    },
    {
      "hash": "sha256-/jvTucP+IWJae0S/CvCbzD0GaCVLM760MT3wn72Lfxw=",
      "url": "_framework/System.Threading.ThreadPool.ecwhyvkgk4.wasm"
    },
    {
      "hash": "sha256-FfINM96F2KImaKIYqhW2w7r9/u/jsnbUSFa165DDIyk=",
      "url": "_framework/System.Threading.Timer.l8u4gk6tg9.wasm"
    },
    {
      "hash": "sha256-LQZlRm8cnSqcm1QEwGnlPNQEVCIMyV95fJsOlkHBmys=",
      "url": "_framework/System.Threading.nv6otxy934.wasm"
    },
    {
      "hash": "sha256-jGyUOQAnrafqUe5niexxQR2wstiW0gBGGFYckwQK/JE=",
      "url": "_framework/System.Transactions.Local.cqwzbi5tww.wasm"
    },
    {
      "hash": "sha256-uvgal4WJlrbNHkH3qlpImGCBBcsV7lDZPJvdvAnwyB0=",
      "url": "_framework/System.Transactions.eqportussb.wasm"
    },
    {
      "hash": "sha256-R3p8pi/HWtl9kfrDQXD4pEqpToJzP2gJ69gqQ/8QKJA=",
      "url": "_framework/System.ValueTuple.3p8lz2dxdg.wasm"
    },
    {
      "hash": "sha256-yfTTxrpMsBiv1gn4v6yvpQ9E0mLSmi7e2euKYUxgYsU=",
      "url": "_framework/System.Web.HttpUtility.jd5wcr9biz.wasm"
    },
    {
      "hash": "sha256-bLW+BZY37sNHkwv69/ELB+Zoq4iO2NLaUkPlMhV8SR4=",
      "url": "_framework/System.Web.w3ew2t5qa6.wasm"
    },
    {
      "hash": "sha256-K/zEg/9klhrZ41iV2xiuvTZBHYlsKOVsh7B9N/7Aes0=",
      "url": "_framework/System.Windows.tativ8o637.wasm"
    },
    {
      "hash": "sha256-5E+X6Q2jjx0HMS7fid3goSnVX07vecUwgtPRv1si72Q=",
      "url": "_framework/System.Xml.Linq.wpsaw4fs0c.wasm"
    },
    {
      "hash": "sha256-4yv0OjkHh4LeWTiszAl0XyizoJzQMAoSWQaDVI+oif0=",
      "url": "_framework/System.Xml.ReaderWriter.lis3h0bjpq.wasm"
    },
    {
      "hash": "sha256-sWgN6Xgjze65u1ycVgaDsiWJdNlZUx9+JTcL9WwDcyA=",
      "url": "_framework/System.Xml.Serialization.b9gojf6ll8.wasm"
    },
    {
      "hash": "sha256-k0ZdE8i4+oAvcp6jWVX3xoUYtN5RLfO81xuOWr54M6c=",
      "url": "_framework/System.Xml.XDocument.jcxbdnyj8b.wasm"
    },
    {
      "hash": "sha256-cWjP7jmVquElgreFLhiAm8vhCd04AHijbNygZ4Mirvs=",
      "url": "_framework/System.Xml.XPath.1c8x86y34z.wasm"
    },
    {
      "hash": "sha256-kbIw5/HD14mnsaE7eTZ8Xoq7e0PKtHerEoo4q4JkrJM=",
      "url": "_framework/System.Xml.XPath.XDocument.vwdo924nyz.wasm"
    },
    {
      "hash": "sha256-a/xFP8QQMenKlKQuMLH7plGmG3Fa/y52SdXyJewxvag=",
      "url": "_framework/System.Xml.XmlDocument.hh2c0bum76.wasm"
    },
    {
      "hash": "sha256-TU4cHD6oH8UiQaFcbxLNXMt8JZT/mQ34Y7ECuQf+qaI=",
      "url": "_framework/System.Xml.XmlSerializer.php9d66sr9.wasm"
    },
    {
      "hash": "sha256-x1ntQJC4IY+c2WAfQAc7iBKmWcPmwBgUFWymwEW0ZTE=",
      "url": "_framework/System.Xml.lt9uhmpnr1.wasm"
    },
    {
      "hash": "sha256-ws3zoKLV/3tSYvSoxCHWv6IElcq4VpyT0p12ik3rw8I=",
      "url": "_framework/System.quncyez9vs.wasm"
    },
    {
      "hash": "sha256-mQsTm1or+jsATmWkhFb299cL4Tn/WigajeiYmp8+kdU=",
      "url": "_framework/TinyMCE.Blazor.ll1a586db2.wasm"
    },
    {
      "hash": "sha256-7LCr4nX9JSGuwzMr8Rk8TGvC6ApzQNxCDiMV/0I9JlI=",
      "url": "_framework/WindowsBase.ovqw333kan.wasm"
    },
    {
      "hash": "sha256-bGpJuUzeCm7YH5ClaLjFRcW+z28P3kQyjk+7F6h1gCA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-uZ78dzkpKpqOOREKMu96HZuyG1XQJN8TJtajfR7vh7I=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-HFADmT26AarHu4tMjFaTPxINmQjBJGtdPN+CKjtNMFE=",
      "url": "_framework/dotnet.native.8bti36lthm.js"
    },
    {
      "hash": "sha256-F3/BArijJUydqmwcdWeW3LYyYHBRSu2+pyy8GL1jTV0=",
      "url": "_framework/dotnet.native.tr0cyonrwt.wasm"
    },
    {
      "hash": "sha256-ZmDmkgcXhChDWRHCx3XZMJe7cgx2e4YsJg8qr2YME8Y=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-jZgH0LixLeQKqaq33akQgDGhfE7vbXbHtvCId5HC0Yo=",
      "url": "_framework/mscorlib.l6md3pggqy.wasm"
    },
    {
      "hash": "sha256-DeeBl9s8G34N3IfYRQ+MoY807amodj8cvpuvUSNaWE4=",
      "url": "_framework/netstandard.lij9csiyuf.wasm"
    },
    {
      "hash": "sha256-tuKuj1+G5NR0tLQCxWM4XqOvvMMe5MHZVAiIfelbkCM=",
      "url": "appsettings.Development.json"
    },
    {
      "hash": "sha256-JbSFasYoIU28klxBbOaMMDjyqtKN6A0fej/CquygM6I=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-oPLUUCktOjqBg96/1AjGFtk3Re8rFYMR1Y+bH9DigTA=",
      "url": "css/Grid.css"
    },
    {
      "hash": "sha256-z/dP7ZETiwwdsRZ1wfVUy8Hkqx4U/LHehAmI22DHBdQ=",
      "url": "css/ProSolutionForms.css"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-cvmH35ojb+LTgQb9n285t8dajNsV/ikXk25Du0yQMmc=",
      "url": "css/callout.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jtrXJ0Xld3RtOj6l+JDF/WJR70B9bkHnvPLAO9Wn1MY=",
      "url": "images/Background01.jpeg"
    },
    {
      "hash": "sha256-GpMJsuUYWUnOkRTJDkoMDGjZyHGgjBLa2cV2LQJn61w=",
      "url": "images/Background01.webp"
    },
    {
      "hash": "sha256-WjoO/Bs0JMowkMFPlrMW0boUX0jzIsRlKLT3zXf4/X8=",
      "url": "images/SHCG-Logo-Coloured-RGB.png"
    },
    {
      "hash": "sha256-xpLOhzV9vSeuhNrlAkVxHwLj0aJnIgB9+Axvw5ysu2A=",
      "url": "index.html"
    },
    {
      "hash": "sha256-xYLWAU2siufbWIV2upK7vddW9HGbgMASejRXfLMq40M=",
      "url": "js/inputInterop.js"
    },
    {
      "hash": "sha256-Dj5LfMYUR7xpNkcTeQE4+r+Cgi+/6VfOJ8bj/4cgiAQ=",
      "url": "js/localStorageInterop.js"
    },
    {
      "hash": "sha256-Sp8wPxQcaM0pUmoA0FbH5fiwFc+g8iWkmbJh6WChxaU=",
      "url": "js/serviceWorkerInterop.js"
    },
    {
      "hash": "sha256-7PIdBYy03MoGXde56YDICBv49k8HBD+ELBAzJvoYVFQ=",
      "url": "js/tinymceInterop.js"
    },
    {
      "hash": "sha256-oNBgkKnw0Cr673JQ7K+QV2xd/YhvC0A1uNo2+p3dA5g=",
      "url": "js/toastInterop.js"
    },
    {
      "hash": "sha256-sAD2IsukcRgeSqm4Pk6jigadDgZ0zcgXFIsh7z3NcEs=",
      "url": "lib/bootstrap-icons/bootstrap-icons.svg"
    },
    {
      "hash": "sha256-S/JHzoCZGcKPnxz/Bo+ly5uwSEYz9txDLCuOmMHnjbw=",
      "url": "lib/bootstrap-icons/font/bootstrap-icons.css"
    },
    {
      "hash": "sha256-Pr9PQew0y1LOmg64R3M2TkO8FhiRtuJHMOxb+WBIRqY=",
      "url": "lib/bootstrap-icons/font/bootstrap-icons.json"
    },
    {
      "hash": "sha256-JA59a+dCN4iupWaFNdJSmTWIF7+yFkolVUNQUMMcExQ=",
      "url": "lib/bootstrap-icons/font/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-ux3pibg5cPb05U3hzZdMXLpVtzWC2l4bIlptDt8ClIM=",
      "url": "lib/bootstrap-icons/font/fonts/bootstrap-icons.woff"
    },
    {
      "hash": "sha256-R2rfQrQDJQmPz6izarPnaRhrtPbOaiSXU+LhqcIr+Z4=",
      "url": "lib/bootstrap-icons/font/fonts/bootstrap-icons.woff2"
    },
    {
      "hash": "sha256-oJ2Om04mNOsY3N71joYA+ki7niOEd7G6LcU2fBRwjg0=",
      "url": "lib/bootstrap-icons/icons/0-circle-fill.svg"
    },
    {
      "hash": "sha256-W/RpJrSx4LfSwbilWfXpEJRuH2IcjRV2cnJVfSZBdu0=",
      "url": "lib/bootstrap-icons/icons/0-circle.svg"
    },
    {
      "hash": "sha256-DNC0LK1dKKBmaROaZf41u9F7LoE3IWsCNtajIlahcsg=",
      "url": "lib/bootstrap-icons/icons/0-square-fill.svg"
    },
    {
      "hash": "sha256-DZkxk09GLctkfiKXbogYHmSSqn333ne6dwGJrc/A6fM=",
      "url": "lib/bootstrap-icons/icons/0-square.svg"
    },
    {
      "hash": "sha256-K1ocLxWEen65I23vQMgVkEkezYkt7F84u6mOu0AaAQo=",
      "url": "lib/bootstrap-icons/icons/1-circle-fill.svg"
    },
    {
      "hash": "sha256-cKWmRG+7Q8lFXzrjUMXoLfNkzXeQaq6tQZvqCwxCSx0=",
      "url": "lib/bootstrap-icons/icons/1-circle.svg"
    },
    {
      "hash": "sha256-rh/jru2f7MCVKJPKCnq0WKpaum85yd1Gnv4yMd63IVw=",
      "url": "lib/bootstrap-icons/icons/1-square-fill.svg"
    },
    {
      "hash": "sha256-QK1Tm9nhTNroxyd6qBs7iLXplZxnGkZ1Yw76bsKIYtI=",
      "url": "lib/bootstrap-icons/icons/1-square.svg"
    },
    {
      "hash": "sha256-MZT+uXdqbiILWvmTU41Pv6sHwoY8gW8vNXE+u0RtZyg=",
      "url": "lib/bootstrap-icons/icons/123.svg"
    },
    {
      "hash": "sha256-kU8CnlXFJsi5yBtbwYZeeeyB0RVg5DWCIsSBJ7W9ySU=",
      "url": "lib/bootstrap-icons/icons/2-circle-fill.svg"
    },
    {
      "hash": "sha256-XZEwfJ5OcTbXbYV1gJ4h23mL3ErKw96SmyqonaHyZxg=",
      "url": "lib/bootstrap-icons/icons/2-circle.svg"
    },
    {
      "hash": "sha256-z1dUG7BYAL4oDEnFrxB26KHXz58wPRKmlioZdGFL4ag=",
      "url": "lib/bootstrap-icons/icons/2-square-fill.svg"
    },
    {
      "hash": "sha256-zyR+l55NUKN6vyoBG9RSn3Tc2cORXqqUq79NojkbDMM=",
      "url": "lib/bootstrap-icons/icons/2-square.svg"
    },
    {
      "hash": "sha256-3lWMsCpe8Hv+VpoL9wlCpAZCKqY2O7hx+VvB3Nvv0ag=",
      "url": "lib/bootstrap-icons/icons/3-circle-fill.svg"
    },
    {
      "hash": "sha256-3gfcD0KQFpaKoA6CRC0pjMV7dynzZtS2olpuAFfRKr8=",
      "url": "lib/bootstrap-icons/icons/3-circle.svg"
    },
    {
      "hash": "sha256-Vpm9D+6FENvCTCZZHQg2fPaDNOSYLj+/aIY4S8weJtU=",
      "url": "lib/bootstrap-icons/icons/3-square-fill.svg"
    },
    {
      "hash": "sha256-KAY7KZ72DriQEAxE6eo8Ei+ojsx8kt0Sq3x46eYeeCY=",
      "url": "lib/bootstrap-icons/icons/3-square.svg"
    },
    {
      "hash": "sha256-DZHhfyHRelyZ0dO0WT/O7m8vjLmAKJ8N6Nfgf2eXCDY=",
      "url": "lib/bootstrap-icons/icons/4-circle-fill.svg"
    },
    {
      "hash": "sha256-bpdHXpcj4ZQHh86LoIH4UDXGbc/EZcmNti3xiWYtjVg=",
      "url": "lib/bootstrap-icons/icons/4-circle.svg"
    },
    {
      "hash": "sha256-ZbB7AbF394nFHyshREqcV7Ea4Gv+irFUNbVQ1LDcJsQ=",
      "url": "lib/bootstrap-icons/icons/4-square-fill.svg"
    },
    {
      "hash": "sha256-NYmn2pceJ2/IPS0IPNVlfCTUu5liQSnZNxuxXQ7Xzv8=",
      "url": "lib/bootstrap-icons/icons/4-square.svg"
    },
    {
      "hash": "sha256-oQacmlPYNfYZUkdCpXlgoft11X2Kr7FufILn3cTnDJA=",
      "url": "lib/bootstrap-icons/icons/5-circle-fill.svg"
    },
    {
      "hash": "sha256-BQACuFJxPEzCmHssCz8111+NfarzbMfdHS6wZ3Xar3A=",
      "url": "lib/bootstrap-icons/icons/5-circle.svg"
    },
    {
      "hash": "sha256-L74LX8LQYpctggXL6ONJd20h7ag05Fee4gTQKjqMh7o=",
      "url": "lib/bootstrap-icons/icons/5-square-fill.svg"
    },
    {
      "hash": "sha256-04S7M802tL+x+ehlyQQ03DsXEGokafW9aPUzZM5D0Is=",
      "url": "lib/bootstrap-icons/icons/5-square.svg"
    },
    {
      "hash": "sha256-rXDDmUVEfKtq8ScjQngEcJSVt9qBXP22K6W+lWhf5GE=",
      "url": "lib/bootstrap-icons/icons/6-circle-fill.svg"
    },
    {
      "hash": "sha256-aJQzFcrqkVcGmvSnYwYWXjT4WOjMItW4w3kvOh2iUb4=",
      "url": "lib/bootstrap-icons/icons/6-circle.svg"
    },
    {
      "hash": "sha256-7iA4Kr4G+wF7JKbOc4XsQBEEZUm6RoljPlu/sI00b+8=",
      "url": "lib/bootstrap-icons/icons/6-square-fill.svg"
    },
    {
      "hash": "sha256-oO1lwAzYJF0tH7bagfgfLJZZ7DPTOf8qxrhh7p0PP64=",
      "url": "lib/bootstrap-icons/icons/6-square.svg"
    },
    {
      "hash": "sha256-s+wYdjn/jci0OlE+REsnAT5Rxe9/mysIuNNkCWqtwTk=",
      "url": "lib/bootstrap-icons/icons/7-circle-fill.svg"
    },
    {
      "hash": "sha256-hImB6Oc7ayu/1/U68qO3NcY8NJNMD2f6IlmpgmqG10Y=",
      "url": "lib/bootstrap-icons/icons/7-circle.svg"
    },
    {
      "hash": "sha256-jeADYoYGzQh5q0MgHXErzwaaHB7xD592/jrSN4lUfzA=",
      "url": "lib/bootstrap-icons/icons/7-square-fill.svg"
    },
    {
      "hash": "sha256-cSXZmCAZK4/Ip7PfkAe//zuIN7O7i/y0cZ+TdzJaRhA=",
      "url": "lib/bootstrap-icons/icons/7-square.svg"
    },
    {
      "hash": "sha256-g3Z9BJdEtS/P0dgvnncvUObiEZ08kU8n+zcRMZdVRYI=",
      "url": "lib/bootstrap-icons/icons/8-circle-fill.svg"
    },
    {
      "hash": "sha256-hrKn5E+QGncbk5VgZ1uAMEpDL457OGDQPQSCLx4Z7dY=",
      "url": "lib/bootstrap-icons/icons/8-circle.svg"
    },
    {
      "hash": "sha256-jhjTkxbFjP1kFkP+uV9+K5l08rqPgXNDHqSkCN/qyME=",
      "url": "lib/bootstrap-icons/icons/8-square-fill.svg"
    },
    {
      "hash": "sha256-TAEszsq4WU4yFbWC5iF5Sm/jIw04P4atDvdNoMWZWE4=",
      "url": "lib/bootstrap-icons/icons/8-square.svg"
    },
    {
      "hash": "sha256-U09nHfJ2vlx3JraGdaEH40U1rF3cyvRkNwO2ucugUE4=",
      "url": "lib/bootstrap-icons/icons/9-circle-fill.svg"
    },
    {
      "hash": "sha256-acwEp+ghwGhAlw7W78OXiY/PmOn0bQUxS/ClMg1+pVw=",
      "url": "lib/bootstrap-icons/icons/9-circle.svg"
    },
    {
      "hash": "sha256-Nx3XlgLwWGfGRyGn8fMJHgsir6oEHzF7lKBtm6xPqKM=",
      "url": "lib/bootstrap-icons/icons/9-square-fill.svg"
    },
    {
      "hash": "sha256-KCcBlpPo35NFo+hmG6awRGbodd7PwBzqEY2oumHYXck=",
      "url": "lib/bootstrap-icons/icons/9-square.svg"
    },
    {
      "hash": "sha256-8pQ0Dg8syQExiSaKeyeN+AN3k4wOyFI7hrzo81Tmvqk=",
      "url": "lib/bootstrap-icons/icons/activity.svg"
    },
    {
      "hash": "sha256-1yD9MIRh0XkhluDKEmZbB3rW7sadXccWMQYMvCpJ3Ww=",
      "url": "lib/bootstrap-icons/icons/airplane-engines-fill.svg"
    },
    {
      "hash": "sha256-HlG9UyoEexNttO5W3sV1cdafAntfixu9PeEtisvjtEA=",
      "url": "lib/bootstrap-icons/icons/airplane-engines.svg"
    },
    {
      "hash": "sha256-IhYTb3vdVIpvfuWxU96+2MwZmMKRwUO6uWIneCBGdws=",
      "url": "lib/bootstrap-icons/icons/airplane-fill.svg"
    },
    {
      "hash": "sha256-GQdqjOMLi6LJH520sqlrFnKG3WagW3kT6+ZXKdc27lo=",
      "url": "lib/bootstrap-icons/icons/airplane.svg"
    },
    {
      "hash": "sha256-ydF/yFRSIS9ZtInIfTdpCsybstt50z9Ah6r2Sd+E+cg=",
      "url": "lib/bootstrap-icons/icons/alarm-fill.svg"
    },
    {
      "hash": "sha256-kU1QXv551yrziyfmNvPyZRN5VLCkkQE0jJJeyEG/iRU=",
      "url": "lib/bootstrap-icons/icons/alarm.svg"
    },
    {
      "hash": "sha256-WytVEiVddQEZLkNJcGTk2TkDmIidbA3MQmsoMRhLKek=",
      "url": "lib/bootstrap-icons/icons/alexa.svg"
    },
    {
      "hash": "sha256-Ryibk4NwXA9roUJPxibgl76HDX+tfP30zTiZ6c9KO74=",
      "url": "lib/bootstrap-icons/icons/align-bottom.svg"
    },
    {
      "hash": "sha256-1sC5X728G576fl3E3Ucmdfh+RQnOYxofvgj/9BV2yoE=",
      "url": "lib/bootstrap-icons/icons/align-center.svg"
    },
    {
      "hash": "sha256-vtwgtnFxzjBYAyw6ZtZdGE1Jcs4uEe9a44tZAgrC5xI=",
      "url": "lib/bootstrap-icons/icons/align-end.svg"
    },
    {
      "hash": "sha256-vRLY+PCg4x4srZUj9V6K4TRgbgwd3b9SGAn5if3OubU=",
      "url": "lib/bootstrap-icons/icons/align-middle.svg"
    },
    {
      "hash": "sha256-0p7qVy16rRV7XqSQNWuxJpE6O9t9fzQ+GjzHhsya81c=",
      "url": "lib/bootstrap-icons/icons/align-start.svg"
    },
    {
      "hash": "sha256-szsIz81JkSR9Dkb2FbZJ6vDUs0geRACVEx3CtQs9EYk=",
      "url": "lib/bootstrap-icons/icons/align-top.svg"
    },
    {
      "hash": "sha256-9QPjCZZiVq7050GW0AqUv64Hsc0Y3uQ06h+DbV7pSNw=",
      "url": "lib/bootstrap-icons/icons/alipay.svg"
    },
    {
      "hash": "sha256-1xTOZE4/Tf2XEQ5PsgiTqP6SxxjwzICoGl5bvXgJUG0=",
      "url": "lib/bootstrap-icons/icons/alphabet-uppercase.svg"
    },
    {
      "hash": "sha256-NHd5hfu4qD2o1xXbEInztfNl9+/vque8Gsujlg3W7qI=",
      "url": "lib/bootstrap-icons/icons/alphabet.svg"
    },
    {
      "hash": "sha256-5O3QVl0PcSoD17nvIa+zzxZ6VucovKvNarXkV8ld738=",
      "url": "lib/bootstrap-icons/icons/alt.svg"
    },
    {
      "hash": "sha256-P5lbxAkkR1pzV1KzhXvbQXvKpsQa3rJ9S9QN1cgMnb8=",
      "url": "lib/bootstrap-icons/icons/amazon.svg"
    },
    {
      "hash": "sha256-3DJCiw+DDPcAjLstSl5qhhXetRSKSgDkH7jzr7UWHcI=",
      "url": "lib/bootstrap-icons/icons/amd.svg"
    },
    {
      "hash": "sha256-SRjNibgwIVFCIrK+MGnm0tQAC5Qd0GCY67mL10APBBQ=",
      "url": "lib/bootstrap-icons/icons/android.svg"
    },
    {
      "hash": "sha256-f5GnDf37exlkDdl1pNKWsLNRhajjvSHgmVSgHgCq/aI=",
      "url": "lib/bootstrap-icons/icons/android2.svg"
    },
    {
      "hash": "sha256-xZ2kR9lTIpja6Va6TchCh3d7zLz3irWB6dE0ufqN1VA=",
      "url": "lib/bootstrap-icons/icons/app-indicator.svg"
    },
    {
      "hash": "sha256-v+7NGkpjm0SKqt1uQk2YgJN4ObMbYzT1Daj0Z51F+o8=",
      "url": "lib/bootstrap-icons/icons/app.svg"
    },
    {
      "hash": "sha256-UImPa/cqZ6NgIYY4m9EZXpvmugGGqnh/miE0iRbdxgY=",
      "url": "lib/bootstrap-icons/icons/apple.svg"
    },
    {
      "hash": "sha256-ofgFU00BcUubKnmPssEREeoUelQS8FKZknlN8mnyqUI=",
      "url": "lib/bootstrap-icons/icons/archive-fill.svg"
    },
    {
      "hash": "sha256-rlgUUXQup5xuPMMxLHg/B5MiKAQ+32jG8imL8aUsp/M=",
      "url": "lib/bootstrap-icons/icons/archive.svg"
    },
    {
      "hash": "sha256-HTLpXVlIBhrIkERf1F9PAiVYb9ShajIyrI/fcPj7pME=",
      "url": "lib/bootstrap-icons/icons/arrow-90deg-down.svg"
    },
    {
      "hash": "sha256-XoKU09TYetxeC+xgOEvoCeVdYOMkcZqanAI49h8SrBI=",
      "url": "lib/bootstrap-icons/icons/arrow-90deg-left.svg"
    },
    {
      "hash": "sha256-IoKN38CFXBJLXt+6kEqLryDYUsvxEXNWbL5H3ihld4c=",
      "url": "lib/bootstrap-icons/icons/arrow-90deg-right.svg"
    },
    {
      "hash": "sha256-3644/CrFX4h7lSAWQE77eKueRcNCr1uIt+GsshNJ+I4=",
      "url": "lib/bootstrap-icons/icons/arrow-90deg-up.svg"
    },
    {
      "hash": "sha256-g0iNNElJmlmIdjv0ksjQQ/uReHbrZ+ku4p9+PQlUWcI=",
      "url": "lib/bootstrap-icons/icons/arrow-bar-down.svg"
    },
    {
      "hash": "sha256-kKpb5G0sorD0BHuH5NW0y8LbKjLuGB2QDJieLgTLLus=",
      "url": "lib/bootstrap-icons/icons/arrow-bar-left.svg"
    },
    {
      "hash": "sha256-sa1/bSTu3+DbxWPzsBWrzFBovPpk/tUYkp3/+3Qd6L0=",
      "url": "lib/bootstrap-icons/icons/arrow-bar-right.svg"
    },
    {
      "hash": "sha256-B4k/4AHiIt3W/Thj2T0/qv04CZCHMHne3x7e5PrArD0=",
      "url": "lib/bootstrap-icons/icons/arrow-bar-up.svg"
    },
    {
      "hash": "sha256-D9Tz5JnRNBGfWTYwecnYDo/eM6VnX8jY2kV+/d8twwY=",
      "url": "lib/bootstrap-icons/icons/arrow-clockwise.svg"
    },
    {
      "hash": "sha256-Anm6GUlpvoLHu/8di/I7/xr18/OxVHVBowoUPf0GEQA=",
      "url": "lib/bootstrap-icons/icons/arrow-counterclockwise.svg"
    },
    {
      "hash": "sha256-xupyHLADG925QVAHZbapsD9e0yRkZqjKLwU55GUbms8=",
      "url": "lib/bootstrap-icons/icons/arrow-down-circle-fill.svg"
    },
    {
      "hash": "sha256-h14KmuMvpRNTuKub06p40AMYV9bqpKYiB5248/2QKAk=",
      "url": "lib/bootstrap-icons/icons/arrow-down-circle.svg"
    },
    {
      "hash": "sha256-DJ8lwOlFJwZCsd2JkiJd4DIyx9YdOGBEAahUZCgQrsQ=",
      "url": "lib/bootstrap-icons/icons/arrow-down-left-circle-fill.svg"
    },
    {
      "hash": "sha256-yXG9LhD6u8H9JvCKbLYswQE+e40VgneTRqqUOsguNXc=",
      "url": "lib/bootstrap-icons/icons/arrow-down-left-circle.svg"
    },
    {
      "hash": "sha256-c8MLDMM/m5mT7c96FUi4SGgkGA6vCz8i0CkFCmvh2cI=",
      "url": "lib/bootstrap-icons/icons/arrow-down-left-square-fill.svg"
    },
    {
      "hash": "sha256-aPUCFr8BLn4PMT516h0ado70fRfr9OxZ/CJB6dIGbyA=",
      "url": "lib/bootstrap-icons/icons/arrow-down-left-square.svg"
    },
    {
      "hash": "sha256-PwUCCzlv9L4EiOWOdLvIT7qfsjcAaHw/ByUlgOrPXRU=",
      "url": "lib/bootstrap-icons/icons/arrow-down-left.svg"
    },
    {
      "hash": "sha256-htu8jHCvCB/0MxrDjMHxooNE59aFKwAzqUhRBftg4Cw=",
      "url": "lib/bootstrap-icons/icons/arrow-down-right-circle-fill.svg"
    },
    {
      "hash": "sha256-F6FL+IvWplp+ZpiHoGus4rXE1oRomnNgUXz6al09uXo=",
      "url": "lib/bootstrap-icons/icons/arrow-down-right-circle.svg"
    },
    {
      "hash": "sha256-f19w26OzC8mmmHo6m+q0Ll2ChcuKOSO30/ERJo5IJLY=",
      "url": "lib/bootstrap-icons/icons/arrow-down-right-square-fill.svg"
    },
    {
      "hash": "sha256-rqUCnCPt+G8F6keFm78OC6UbKP0BYUYKwPdUe0dGJR0=",
      "url": "lib/bootstrap-icons/icons/arrow-down-right-square.svg"
    },
    {
      "hash": "sha256-4o1yNSS+d3HWmkjQDxo3cRUh+sTivfpkDflmNfAsc78=",
      "url": "lib/bootstrap-icons/icons/arrow-down-right.svg"
    },
    {
      "hash": "sha256-yS7PAKyJnKxjXI2MYnX1YIIU8tQSfB2/2pbyUZ+JWb4=",
      "url": "lib/bootstrap-icons/icons/arrow-down-short.svg"
    },
    {
      "hash": "sha256-8I1tiKT17YDHyVUiGwWqGNHLpdSku0VF3pdSvr0DqUg=",
      "url": "lib/bootstrap-icons/icons/arrow-down-square-fill.svg"
    },
    {
      "hash": "sha256-Fzzw+lu1zKWvQpfWhYEeiHpKzfwk97MfaWhv98ShRmI=",
      "url": "lib/bootstrap-icons/icons/arrow-down-square.svg"
    },
    {
      "hash": "sha256-KD+LHS1et162x/9ETpDFF2VY2nBWRsUWx3GwER+toOI=",
      "url": "lib/bootstrap-icons/icons/arrow-down-up.svg"
    },
    {
      "hash": "sha256-YB6DCiMeEITsPR/j02ScL3PxRhImwyCVpQZLYr1are0=",
      "url": "lib/bootstrap-icons/icons/arrow-down.svg"
    },
    {
      "hash": "sha256-B196+RiGRnozddeRmHaAxRBvtBwy2+TwbAU5fM/H5lQ=",
      "url": "lib/bootstrap-icons/icons/arrow-left-circle-fill.svg"
    },
    {
      "hash": "sha256-EnW0bNH6Qp6KL590Gf5ReGJCrsOxhPISDe27cCZtuK8=",
      "url": "lib/bootstrap-icons/icons/arrow-left-circle.svg"
    },
    {
      "hash": "sha256-JObtT2WbHRYiV8GuY5ak2KuA/ogXKWFV7UTCyqpqXp0=",
      "url": "lib/bootstrap-icons/icons/arrow-left-right.svg"
    },
    {
      "hash": "sha256-Q24HBjnUQvVcF44+2tPAnnkrC4gIhfRVAwkJ/n6T+kM=",
      "url": "lib/bootstrap-icons/icons/arrow-left-short.svg"
    },
    {
      "hash": "sha256-rkjEJj94QaJyy/JJhhQVtaMypUW07z3yGv0d24+RqSU=",
      "url": "lib/bootstrap-icons/icons/arrow-left-square-fill.svg"
    },
    {
      "hash": "sha256-VxrXM/gYOxhFWaZ3E7vy/kAai4TG3IjGdLmqdyvF8/w=",
      "url": "lib/bootstrap-icons/icons/arrow-left-square.svg"
    },
    {
      "hash": "sha256-7ORdFsHeWMR6T5VNLO8nOeSn6vuOiJbrsoYNDo1j0Ws=",
      "url": "lib/bootstrap-icons/icons/arrow-left.svg"
    },
    {
      "hash": "sha256-l1+cpnAKBpNvSbMuXiDHBgczjTpLoQMjqNJxB/X3aHk=",
      "url": "lib/bootstrap-icons/icons/arrow-repeat.svg"
    },
    {
      "hash": "sha256-VZx/M+OpnQFBLKTnkY4nB9sqA2cAer+xn1CtObUh/VM=",
      "url": "lib/bootstrap-icons/icons/arrow-return-left.svg"
    },
    {
      "hash": "sha256-XY+w0r32aIuYxHkatBdr4N5izOTPKDBcyY3dV8tv0LU=",
      "url": "lib/bootstrap-icons/icons/arrow-return-right.svg"
    },
    {
      "hash": "sha256-rc5e5TJMJkxz3nSvvhats1yEtWq98LjQFW6wA/GaX48=",
      "url": "lib/bootstrap-icons/icons/arrow-right-circle-fill.svg"
    },
    {
      "hash": "sha256-euwcu/dEm33qgOLfKVkmprSCz+yFZ4kU9KyE1zrrdlM=",
      "url": "lib/bootstrap-icons/icons/arrow-right-circle.svg"
    },
    {
      "hash": "sha256-IVKEBEMqY2LrBCu8jcle1rpknoEDS68hqnZjhzvk/1w=",
      "url": "lib/bootstrap-icons/icons/arrow-right-short.svg"
    },
    {
      "hash": "sha256-7q3uChjBWvVF49sD0qW7rui0M+Lm7UFZLl8pmL5fxuI=",
      "url": "lib/bootstrap-icons/icons/arrow-right-square-fill.svg"
    },
    {
      "hash": "sha256-YlNd9oXsvBbTOcYD1lZPjlmEWxbuSCGRUs6X37JUZ84=",
      "url": "lib/bootstrap-icons/icons/arrow-right-square.svg"
    },
    {
      "hash": "sha256-kcD2jGmok22fYxK78eqZEhgMFJH9waQNSDPAuLp/dUo=",
      "url": "lib/bootstrap-icons/icons/arrow-right.svg"
    },
    {
      "hash": "sha256-mQZKnd2aa3pvdhnNgmV9UMp3/yrjbVOqA6g8r0Xpp7o=",
      "url": "lib/bootstrap-icons/icons/arrow-through-heart-fill.svg"
    },
    {
      "hash": "sha256-7f74KvMjs7ZWc56Inuto2616kP3fLTreAJF8jh/8WP8=",
      "url": "lib/bootstrap-icons/icons/arrow-through-heart.svg"
    },
    {
      "hash": "sha256-FDB6kkCxbs3L79oWb/ywacSEl+6b0UghGhtvTQHc1ic=",
      "url": "lib/bootstrap-icons/icons/arrow-up-circle-fill.svg"
    },
    {
      "hash": "sha256-+H/pgtYsKtnVgnt7NgLsXBfIdwvpkrrvXFpgkHy65sw=",
      "url": "lib/bootstrap-icons/icons/arrow-up-circle.svg"
    },
    {
      "hash": "sha256-TW/+BDrLon9jgT9vPBdNnygtAexeyEEtdGVbhresB4U=",
      "url": "lib/bootstrap-icons/icons/arrow-up-left-circle-fill.svg"
    },
    {
      "hash": "sha256-VPoSLNL01bAz1alWZt/fBtQPGQ0pQhSlS0Ua5oD78G4=",
      "url": "lib/bootstrap-icons/icons/arrow-up-left-circle.svg"
    },
    {
      "hash": "sha256-5ITpU6/K3KTDECkZplIXNqVpgjLOKdSVEof/L2s5lZE=",
      "url": "lib/bootstrap-icons/icons/arrow-up-left-square-fill.svg"
    },
    {
      "hash": "sha256-WyPVE48fcrgbAghyvhNhQQfQ79x6wujmTjBFMSGJDLU=",
      "url": "lib/bootstrap-icons/icons/arrow-up-left-square.svg"
    },
    {
      "hash": "sha256-qU2IyV7X+WGIU10rLqBdSfj3Cm6lqJ34oPiI9g8wvKc=",
      "url": "lib/bootstrap-icons/icons/arrow-up-left.svg"
    },
    {
      "hash": "sha256-08IWjY5cYFOVxk8SxoZcYvgjVq3LXwvr8Rbt+LEYbTo=",
      "url": "lib/bootstrap-icons/icons/arrow-up-right-circle-fill.svg"
    },
    {
      "hash": "sha256-yDDMuBcPbnd6j7CcV32U00KU/SaYj6ACAxzpxgsfFMQ=",
      "url": "lib/bootstrap-icons/icons/arrow-up-right-circle.svg"
    },
    {
      "hash": "sha256-GVdZxGui97xpiTa7RVfcXCdfnZ8X9fNem1rkHLY7l68=",
      "url": "lib/bootstrap-icons/icons/arrow-up-right-square-fill.svg"
    },
    {
      "hash": "sha256-d0XmpuxCcqS28rH5V8R4PLkjpDRfoG9DbFosVgnjvtY=",
      "url": "lib/bootstrap-icons/icons/arrow-up-right-square.svg"
    },
    {
      "hash": "sha256-rg/Brp7VCTDrK7xThXhXC/eGIYRGueacdVKHBSbHKKs=",
      "url": "lib/bootstrap-icons/icons/arrow-up-right.svg"
    },
    {
      "hash": "sha256-+8h9E6WZHmmLvM0LQHE9EWS+aGEP7rKZ5xVv1wHScac=",
      "url": "lib/bootstrap-icons/icons/arrow-up-short.svg"
    },
    {
      "hash": "sha256-SSUa+UmIdb2fw2qKLJucK2/loUPQrbw6EfBbizM4E9U=",
      "url": "lib/bootstrap-icons/icons/arrow-up-square-fill.svg"
    },
    {
      "hash": "sha256-07IXinwRlF49qwGF2Th313gabKRyXapnBwXZ5J9oDls=",
      "url": "lib/bootstrap-icons/icons/arrow-up-square.svg"
    },
    {
      "hash": "sha256-0qDo7kmUGXrWhqilK1zk3eiO3X7eBHd6s9Wiei9OSI0=",
      "url": "lib/bootstrap-icons/icons/arrow-up.svg"
    },
    {
      "hash": "sha256-1mFsAvGN1UOW9iwZXMt1GsmqNYNE4OmzyyYPv8NAfGw=",
      "url": "lib/bootstrap-icons/icons/arrows-angle-contract.svg"
    },
    {
      "hash": "sha256-L7m/MAHrjfgrLHxUlxod2Afv650/wGwOylIFFfbBmDo=",
      "url": "lib/bootstrap-icons/icons/arrows-angle-expand.svg"
    },
    {
      "hash": "sha256-oXGw1H5/J3C5eTRVQAc//Ifb9e1aqB2E14qWBpWZ+jQ=",
      "url": "lib/bootstrap-icons/icons/arrows-collapse-vertical.svg"
    },
    {
      "hash": "sha256-pb6loQK0xJTr0MBkRrlRhb68HLFv/HnF4VBF0lHN8lg=",
      "url": "lib/bootstrap-icons/icons/arrows-collapse.svg"
    },
    {
      "hash": "sha256-eYgiKzrOqScNRlVIBj7JkQD+0P8qVuIV2uSaPx49GlA=",
      "url": "lib/bootstrap-icons/icons/arrows-expand-vertical.svg"
    },
    {
      "hash": "sha256-oDkQRSpDdaUy7T+FaaF3Q421rarE51fu/D9qkZVIoa8=",
      "url": "lib/bootstrap-icons/icons/arrows-expand.svg"
    },
    {
      "hash": "sha256-kDOhqNQf+Q3M+nOJu1qA+dupb9yYREmN04ivWSaO2xU=",
      "url": "lib/bootstrap-icons/icons/arrows-fullscreen.svg"
    },
    {
      "hash": "sha256-eYdF6l5B56SaYWfoq0C6k0Vrncjnb04C8oU5Let2Srg=",
      "url": "lib/bootstrap-icons/icons/arrows-move.svg"
    },
    {
      "hash": "sha256-vhHMPtbX6ER0AkgcPPgXpMHxmhmQAaNsh+AHpMSVB4M=",
      "url": "lib/bootstrap-icons/icons/arrows-vertical.svg"
    },
    {
      "hash": "sha256-Xu0F27CvmAJxEOKH9vcrof7qRCTP21oUlOFtZTau+uc=",
      "url": "lib/bootstrap-icons/icons/arrows.svg"
    },
    {
      "hash": "sha256-QA4z3qmDYkzytnruteDw9jXgcLqfPxwj4rcQbcEEtuw=",
      "url": "lib/bootstrap-icons/icons/aspect-ratio-fill.svg"
    },
    {
      "hash": "sha256-s4jPFTfVgW5iLKG4Cu/nFcBXKdwHQwODen6ai3N/SyI=",
      "url": "lib/bootstrap-icons/icons/aspect-ratio.svg"
    },
    {
      "hash": "sha256-8D+TcB2vRP0AegZs5e5L+vsgVjoANb4uEVrwaS2rGrU=",
      "url": "lib/bootstrap-icons/icons/asterisk.svg"
    },
    {
      "hash": "sha256-Ol6fXNvlcWJ0CBguq/zm272C5BRwxkizMoPmTvSDJbU=",
      "url": "lib/bootstrap-icons/icons/at.svg"
    },
    {
      "hash": "sha256-cekflHh2phPIG/d/XuBcPJm6/HNWyTFjuWyyNjgUY+E=",
      "url": "lib/bootstrap-icons/icons/award-fill.svg"
    },
    {
      "hash": "sha256-qWbVLnHpNS6RuRmYMQaiQhJ9b4Fd7JhOV8Yjhhojb48=",
      "url": "lib/bootstrap-icons/icons/award.svg"
    },
    {
      "hash": "sha256-3tYA+6c+/ueSLf0CDAFOlJk8eoH5hJvjaFcSra9CG2k=",
      "url": "lib/bootstrap-icons/icons/back.svg"
    },
    {
      "hash": "sha256-avJsevmd4w3wYXc5SRTBpvl4z80r0XcIt4sot8ovISs=",
      "url": "lib/bootstrap-icons/icons/backpack-fill.svg"
    },
    {
      "hash": "sha256-ZLadIOyY+RSnaVQ1V2QIP7bSLqg9vjrAnPPrCTckLEY=",
      "url": "lib/bootstrap-icons/icons/backpack.svg"
    },
    {
      "hash": "sha256-wo4f3B0DGaocV8xb3LRvdT4F6PxzMCREHxNFVHFXjYI=",
      "url": "lib/bootstrap-icons/icons/backpack2-fill.svg"
    },
    {
      "hash": "sha256-BYkgtlpBgGVSpmZ5o+in5425RCXjFNB3gpjh9N1m5Cc=",
      "url": "lib/bootstrap-icons/icons/backpack2.svg"
    },
    {
      "hash": "sha256-57sp9aOL2LjRp0LRC7YWIvLS+iRjSV0usPAehgMReOs=",
      "url": "lib/bootstrap-icons/icons/backpack3-fill.svg"
    },
    {
      "hash": "sha256-dGyXVE9MhxzCzcdnV0uMTFZf7pGtyQnIvkJyLdIPjH4=",
      "url": "lib/bootstrap-icons/icons/backpack3.svg"
    },
    {
      "hash": "sha256-YgHdlRe18gB0c2d1uk8Ek3eP5EXgyLa73vMU9QmgM9E=",
      "url": "lib/bootstrap-icons/icons/backpack4-fill.svg"
    },
    {
      "hash": "sha256-FRKFyZki9ALgHNeRWVcOtrqiUbCTJ1ZTgHATYcMzTC8=",
      "url": "lib/bootstrap-icons/icons/backpack4.svg"
    },
    {
      "hash": "sha256-nEP0Bw9lGaODy0AoEIL3f3ZwWTtTIFKHYBc/Pyj9tP4=",
      "url": "lib/bootstrap-icons/icons/backspace-fill.svg"
    },
    {
      "hash": "sha256-sR91uiftPlBCILsZUcH5dqfr72hLdnYNnWFo9YR1/+4=",
      "url": "lib/bootstrap-icons/icons/backspace-reverse-fill.svg"
    },
    {
      "hash": "sha256-E8I0wOx+kqStnPQ6lTG4DvJsJ0fGu7lyza3B/YZik3g=",
      "url": "lib/bootstrap-icons/icons/backspace-reverse.svg"
    },
    {
      "hash": "sha256-XIgLgESTm/0X+aeU/GOtOBfTMCZ9AN9cY7IuG2xoTaU=",
      "url": "lib/bootstrap-icons/icons/backspace.svg"
    },
    {
      "hash": "sha256-0Ju34VRw8hnJr/4n85EITHRWGVb9xGMqhqX8RnPk42k=",
      "url": "lib/bootstrap-icons/icons/badge-3d-fill.svg"
    },
    {
      "hash": "sha256-tIsk2gQx1W7wb7+4S6yWMsBteKViPQps9y8pWU2EJ/k=",
      "url": "lib/bootstrap-icons/icons/badge-3d.svg"
    },
    {
      "hash": "sha256-webL5GwGA5fwOhgh7feIerxsgZlEDmKZRSoayG4Mzdw=",
      "url": "lib/bootstrap-icons/icons/badge-4k-fill.svg"
    },
    {
      "hash": "sha256-r8J9QWeXAT2YtkyGKREK7sHWwke1cpNl9lWuhMOknZU=",
      "url": "lib/bootstrap-icons/icons/badge-4k.svg"
    },
    {
      "hash": "sha256-6tlun5tejKSH3ZfpTlgdkKIkX/SMPj/ORTRC56rvZ04=",
      "url": "lib/bootstrap-icons/icons/badge-8k-fill.svg"
    },
    {
      "hash": "sha256-59/336nbLcJJ0TM64Eme8iUM9+w2/4G+O47LopPY/U0=",
      "url": "lib/bootstrap-icons/icons/badge-8k.svg"
    },
    {
      "hash": "sha256-vinf40g/8WroNy4Y56AhffW7BNzvT+DsR9B9CJwdthg=",
      "url": "lib/bootstrap-icons/icons/badge-ad-fill.svg"
    },
    {
      "hash": "sha256-lOYTYuroWdvpUCCbaSxvRU/0H0lck4wvUo5ygFLrPfc=",
      "url": "lib/bootstrap-icons/icons/badge-ad.svg"
    },
    {
      "hash": "sha256-va26wyZgR8VNapffBI0uIZmzDnz1jdrSdbhpj8Net4M=",
      "url": "lib/bootstrap-icons/icons/badge-ar-fill.svg"
    },
    {
      "hash": "sha256-pi8d9D6HVQHXDeExtLSCzqGPnIVlDmowP1mevSaUPhg=",
      "url": "lib/bootstrap-icons/icons/badge-ar.svg"
    },
    {
      "hash": "sha256-1NKglWwKrzQ9yjjcAx4FWZrdYS4sZbXG5gjOWNMBomk=",
      "url": "lib/bootstrap-icons/icons/badge-cc-fill.svg"
    },
    {
      "hash": "sha256-RWm2AugsXOhmQLSvqEAHURDJC7x43in2mp92/QrylH8=",
      "url": "lib/bootstrap-icons/icons/badge-cc.svg"
    },
    {
      "hash": "sha256-xrcvOONUrc9BWS5FshriFg8chiEAeOz29Xw7Gb4yPgA=",
      "url": "lib/bootstrap-icons/icons/badge-hd-fill.svg"
    },
    {
      "hash": "sha256-JctKBQuApCMiP4f+6XySbct/l/OH0iQp1AfU7s6t7hs=",
      "url": "lib/bootstrap-icons/icons/badge-hd.svg"
    },
    {
      "hash": "sha256-93UBO7YKDZzWfq1iaLO0UDq+flMPjS1X9pfmxEA8iYk=",
      "url": "lib/bootstrap-icons/icons/badge-sd-fill.svg"
    },
    {
      "hash": "sha256-upIchGpqxUuH7PDLuZ5d3SDULKfXk7sui+z68c0oukE=",
      "url": "lib/bootstrap-icons/icons/badge-sd.svg"
    },
    {
      "hash": "sha256-lh0AE3PKFRFcIZa+F3risR+dAtLf4DsbSNneGOPAi00=",
      "url": "lib/bootstrap-icons/icons/badge-tm-fill.svg"
    },
    {
      "hash": "sha256-2wdoFC2dbqrLIy5EWFKVgCeI5BLgKtJtFteTBeHwTl4=",
      "url": "lib/bootstrap-icons/icons/badge-tm.svg"
    },
    {
      "hash": "sha256-zZzURSi6GbkvvVDuAo2o/VX8rwUN1KLcRhDTjKB7b14=",
      "url": "lib/bootstrap-icons/icons/badge-vo-fill.svg"
    },
    {
      "hash": "sha256-0uhcH/d8zKnoBREqfMx/Yplq2fKllQePphwqWZf5pXg=",
      "url": "lib/bootstrap-icons/icons/badge-vo.svg"
    },
    {
      "hash": "sha256-BnoDyZf+bH0+NMcqXViY7nWkwCpUMEgU7UXyP4DXFNg=",
      "url": "lib/bootstrap-icons/icons/badge-vr-fill.svg"
    },
    {
      "hash": "sha256-nwKonhONILERzY7y3obmB7UM/t5ajUFXF96cCK+0Vyo=",
      "url": "lib/bootstrap-icons/icons/badge-vr.svg"
    },
    {
      "hash": "sha256-tY3DqE+YKetVYR41ZkQtWtk7tFpBvkVpvm/r3cVMRp4=",
      "url": "lib/bootstrap-icons/icons/badge-wc-fill.svg"
    },
    {
      "hash": "sha256-1p7peI/Pp6gySFlergzAKTbr7iDgqGaR4KsfbImsjYQ=",
      "url": "lib/bootstrap-icons/icons/badge-wc.svg"
    },
    {
      "hash": "sha256-2F59e9GzJFipH5BJMqAsn5UPE4VE5qZIxkbWWcUyfO8=",
      "url": "lib/bootstrap-icons/icons/bag-check-fill.svg"
    },
    {
      "hash": "sha256-Ndft79pEjjeZoRhaQ21H4DrxTgotH+j1pEN4c/thIa8=",
      "url": "lib/bootstrap-icons/icons/bag-check.svg"
    },
    {
      "hash": "sha256-TkbnlvlveUaLh+4Xc009KfPSvdg1XHLx7bvIv3i0Fqc=",
      "url": "lib/bootstrap-icons/icons/bag-dash-fill.svg"
    },
    {
      "hash": "sha256-kDwukOH9sjJx24TZjla6OQ0lurfatWtmr/L3IA4UUfo=",
      "url": "lib/bootstrap-icons/icons/bag-dash.svg"
    },
    {
      "hash": "sha256-IFLuFR+XnicG54NU7SXo6gazBx/uuQ/HQzsOgYm3X7s=",
      "url": "lib/bootstrap-icons/icons/bag-fill.svg"
    },
    {
      "hash": "sha256-nx1pD7FbmmaEhSxDX4lUK5txVzShco8uMqhPuIUcOVA=",
      "url": "lib/bootstrap-icons/icons/bag-heart-fill.svg"
    },
    {
      "hash": "sha256-NsRJYHRH91xhG7R/OjmXvyTK3DzJhBczvCreD8dT/es=",
      "url": "lib/bootstrap-icons/icons/bag-heart.svg"
    },
    {
      "hash": "sha256-JAdT0VSAaoVcsQjfObDADvdq+iar4x1Vi1nfZHBEqfk=",
      "url": "lib/bootstrap-icons/icons/bag-plus-fill.svg"
    },
    {
      "hash": "sha256-A/QzZ3gVwIA7RgjP0hlkzKtki375veincBvUiEg7TjQ=",
      "url": "lib/bootstrap-icons/icons/bag-plus.svg"
    },
    {
      "hash": "sha256-l+B/VWu4pobz/WhsB48ys8cOXb3F4bbvonq599aHXcM=",
      "url": "lib/bootstrap-icons/icons/bag-x-fill.svg"
    },
    {
      "hash": "sha256-z1ohMd2sPISn1itgGZP9nvQXrWKidIeACLUHwPSApGA=",
      "url": "lib/bootstrap-icons/icons/bag-x.svg"
    },
    {
      "hash": "sha256-0pVUxhr1X/gzNd4snaJ6i3UOzVWHiUEhHBr3DpUvqaM=",
      "url": "lib/bootstrap-icons/icons/bag.svg"
    },
    {
      "hash": "sha256-fLdPiLyCSRg4lK+kuYAEYsS112mUDm6S5yATx2/wEfk=",
      "url": "lib/bootstrap-icons/icons/balloon-fill.svg"
    },
    {
      "hash": "sha256-f4hHjo3J5aTaN2Q5g4BiScNv4ycAqG8A56Cx0q4Ucp4=",
      "url": "lib/bootstrap-icons/icons/balloon-heart-fill.svg"
    },
    {
      "hash": "sha256-rRlzoGx3O67GsNTbyRz7YJMThxZq8FlivIx0qwLvEQk=",
      "url": "lib/bootstrap-icons/icons/balloon-heart.svg"
    },
    {
      "hash": "sha256-jb5oI0vxM4gCdrquVz82F8F5KSbU0qt5p4GywbHYPlE=",
      "url": "lib/bootstrap-icons/icons/balloon.svg"
    },
    {
      "hash": "sha256-f8SHAxSVTyuvwZHMfMcsWXh0PliwkRiWiQxTA1IxdEY=",
      "url": "lib/bootstrap-icons/icons/ban-fill.svg"
    },
    {
      "hash": "sha256-tbge/7qHygpMq/ocIYAkX0405q9BFHzklc8YFN3dP+w=",
      "url": "lib/bootstrap-icons/icons/ban.svg"
    },
    {
      "hash": "sha256-owXR0FCIshxl07QNOBuHtjPeBaVBhYA7N0ZnMtmKSeI=",
      "url": "lib/bootstrap-icons/icons/bandaid-fill.svg"
    },
    {
      "hash": "sha256-5mXZnhescl9uf+XoqEG8TarUB272IWmENaHuzldCcQ0=",
      "url": "lib/bootstrap-icons/icons/bandaid.svg"
    },
    {
      "hash": "sha256-qLNZKZ94UH41OHxyFNQljCSzV+F3iblS7anwPCarveM=",
      "url": "lib/bootstrap-icons/icons/bank.svg"
    },
    {
      "hash": "sha256-gNwujYeQPgYsZKUPCmiSNCtPupPFUeIDDrdhw7Oh0tQ=",
      "url": "lib/bootstrap-icons/icons/bank2.svg"
    },
    {
      "hash": "sha256-+Q07uwyjjyvp391/ywS07UNyngE+nEG22ENsAlRxZgI=",
      "url": "lib/bootstrap-icons/icons/bar-chart-fill.svg"
    },
    {
      "hash": "sha256-r/T2aPqOQ/nTzpbP1CYLE850MV7o4wb049m+BjlLXKg=",
      "url": "lib/bootstrap-icons/icons/bar-chart-line-fill.svg"
    },
    {
      "hash": "sha256-90H8LhMc8Gwxw1tC979ypsOSxMIR9zcBeJmNHqVPgIM=",
      "url": "lib/bootstrap-icons/icons/bar-chart-line.svg"
    },
    {
      "hash": "sha256-fq81hKOE86S621Sh3Ky7Dlim37+ZUAy4fL2c2++n/Q0=",
      "url": "lib/bootstrap-icons/icons/bar-chart-steps.svg"
    },
    {
      "hash": "sha256-f4dLanK4Yd+AGgBOqSZSte5xPD4qHFxmKJCVoqDTqY8=",
      "url": "lib/bootstrap-icons/icons/bar-chart.svg"
    },
    {
      "hash": "sha256-CYFupFYFZiM+rOWpE8Om+OPOsfBv7mg6uXQnKo8Ts0E=",
      "url": "lib/bootstrap-icons/icons/basket-fill.svg"
    },
    {
      "hash": "sha256-U9fB8ldaVSezYJbmsBCuf9aDqg8pLo9o/jyGUf/U2lw=",
      "url": "lib/bootstrap-icons/icons/basket.svg"
    },
    {
      "hash": "sha256-J9TURlaaYjZS0l9GGuwhycPsMrKNOvktuaEGoiA6+TM=",
      "url": "lib/bootstrap-icons/icons/basket2-fill.svg"
    },
    {
      "hash": "sha256-XW6gEcfj77G8KoccTpYKY9rihlqZPNVGbJCuh2ar+/0=",
      "url": "lib/bootstrap-icons/icons/basket2.svg"
    },
    {
      "hash": "sha256-BL3R1HAuCwiQ06qhL9++VCNkBhsv/KcrIJKpgs9AwjQ=",
      "url": "lib/bootstrap-icons/icons/basket3-fill.svg"
    },
    {
      "hash": "sha256-CWP18fBLM4MZGi4W7Mi0CodvFEGaWikO6SfwbH7Chxs=",
      "url": "lib/bootstrap-icons/icons/basket3.svg"
    },
    {
      "hash": "sha256-leR63cgPtfCzZhQv1ENeN0iG5HMtuVo2EP3YpbHda+s=",
      "url": "lib/bootstrap-icons/icons/battery-charging.svg"
    },
    {
      "hash": "sha256-D5YHg8IQNedMOwsS+5AgEYqEdnPBdSjd6mzGN5f+wDI=",
      "url": "lib/bootstrap-icons/icons/battery-full.svg"
    },
    {
      "hash": "sha256-yYCqmDEXWOhgVilax0Gi8r5DUnL5HizAi2WSecAaKgI=",
      "url": "lib/bootstrap-icons/icons/battery-half.svg"
    },
    {
      "hash": "sha256-AgCy36tiF/xpgnxfil31T/hY4hjazzYtlTSzzyAoc2w=",
      "url": "lib/bootstrap-icons/icons/battery.svg"
    },
    {
      "hash": "sha256-ndTHe0XGtphdmnX/gTrshRh6JCqe5bNVHm7Q2lBRybU=",
      "url": "lib/bootstrap-icons/icons/behance.svg"
    },
    {
      "hash": "sha256-OfH0Dy3L1crN/jV9NNqkvoCZZvIHICHz9CKUEvxtuII=",
      "url": "lib/bootstrap-icons/icons/bell-fill.svg"
    },
    {
      "hash": "sha256-v9hwyPxHQkBxkVhnUZ7Weoq60e+4eSzRkN1gSgxcJsE=",
      "url": "lib/bootstrap-icons/icons/bell-slash-fill.svg"
    },
    {
      "hash": "sha256-nbXjSe+qOOmfhbJdKtKsQxcEYwKuWovkV/1jNJnWuFU=",
      "url": "lib/bootstrap-icons/icons/bell-slash.svg"
    },
    {
      "hash": "sha256-6tY7XnF3vzpFnthR+yvk9cRRwi0gweKbYoHTZVQUdqk=",
      "url": "lib/bootstrap-icons/icons/bell.svg"
    },
    {
      "hash": "sha256-L2riBzQWOb0CaiF6UJvGp57oGYHYpUXKWBYRLvoDdQw=",
      "url": "lib/bootstrap-icons/icons/bezier.svg"
    },
    {
      "hash": "sha256-tWQzIGMnQsBFqVxtDzIDpYTWF0nwNX5vbVrXZyXSLJ4=",
      "url": "lib/bootstrap-icons/icons/bezier2.svg"
    },
    {
      "hash": "sha256-XzZLlwO2m2w6fJcn6kFXVbELzqs/YeDIPn19gY2wxIs=",
      "url": "lib/bootstrap-icons/icons/bicycle.svg"
    },
    {
      "hash": "sha256-fHdsdGJd53SumU44r8/Tdb5I18Rrie+FT3brK4WW6QU=",
      "url": "lib/bootstrap-icons/icons/bing.svg"
    },
    {
      "hash": "sha256-ahPcpg5zZDqMcdNOPiYk7UGyyDI5Q/69npOFrMKraIY=",
      "url": "lib/bootstrap-icons/icons/binoculars-fill.svg"
    },
    {
      "hash": "sha256-aufQduQIWDGk3HKOOoFcXhAulYuK7OZRx7BH6f/PZkI=",
      "url": "lib/bootstrap-icons/icons/binoculars.svg"
    },
    {
      "hash": "sha256-qhe9YlDADDHoW5Jdp7dtFCGRHvjzAcRFZEUeMeLdznM=",
      "url": "lib/bootstrap-icons/icons/blockquote-left.svg"
    },
    {
      "hash": "sha256-QdhM9xudFRc58xNLWg5amKJBciJ/iNHOCyGNYmUnGBc=",
      "url": "lib/bootstrap-icons/icons/blockquote-right.svg"
    },
    {
      "hash": "sha256-E34oTjmGCAP7iYMU+OGt/M+oOUp/nAPVrdQJUaNez4g=",
      "url": "lib/bootstrap-icons/icons/bluetooth.svg"
    },
    {
      "hash": "sha256-G5mnfjFWL32V3Fe+b0ltsxMWWKbXUA3Wd+M/oQoPIZs=",
      "url": "lib/bootstrap-icons/icons/body-text.svg"
    },
    {
      "hash": "sha256-A62agRUF1Gz5ySGKWezpk6qhVdvlV0Eztlv9WD+GS5U=",
      "url": "lib/bootstrap-icons/icons/book-fill.svg"
    },
    {
      "hash": "sha256-8XTYt8/2jgZGz90QHPEJKYP4zl61uCltRW9gjw5NB5A=",
      "url": "lib/bootstrap-icons/icons/book-half.svg"
    },
    {
      "hash": "sha256-S96s3ajPIzPKfx3sBRxWeJoDqWMDBOtTZuKJnuCQEGk=",
      "url": "lib/bootstrap-icons/icons/book.svg"
    },
    {
      "hash": "sha256-FNDwc3xxkx2WAlqFbkmb8MJSYeDVIzCQPHxvKArEjPU=",
      "url": "lib/bootstrap-icons/icons/bookmark-check-fill.svg"
    },
    {
      "hash": "sha256-5IWD8HmOAnz6dwa22/lr1UCCgXQ5N3ky01UZICcD3rk=",
      "url": "lib/bootstrap-icons/icons/bookmark-check.svg"
    },
    {
      "hash": "sha256-4+eD5eNBa6qUjN48JTDTW3VHC3qZos5qQlm1Rev7d8E=",
      "url": "lib/bootstrap-icons/icons/bookmark-dash-fill.svg"
    },
    {
      "hash": "sha256-4pmgLIaWbxNVgB4vFxvWTa71/n+yieCwohHjLhucO+4=",
      "url": "lib/bootstrap-icons/icons/bookmark-dash.svg"
    },
    {
      "hash": "sha256-sOqukcXCXyhHK1AXudOZvepnYPk+VOIT7mTjDyX570w=",
      "url": "lib/bootstrap-icons/icons/bookmark-fill.svg"
    },
    {
      "hash": "sha256-pJ2upLzecpvfj8vS8t1xbqYzplChxbtsOGJWW4a9YdY=",
      "url": "lib/bootstrap-icons/icons/bookmark-heart-fill.svg"
    },
    {
      "hash": "sha256-xgazT+oNlqganA2bI5I5aS6Qmkxzgska7WdbCoR5Jqo=",
      "url": "lib/bootstrap-icons/icons/bookmark-heart.svg"
    },
    {
      "hash": "sha256-y8hyQsUhSYAkTypIj28kvmgf8st+mpxCVoETjyI6emM=",
      "url": "lib/bootstrap-icons/icons/bookmark-plus-fill.svg"
    },
    {
      "hash": "sha256-YG5zjbnf2lLZGCIjkfEh0cmXdWY4/N1n5uzNkBsMkAU=",
      "url": "lib/bootstrap-icons/icons/bookmark-plus.svg"
    },
    {
      "hash": "sha256-zaz7oMPfnA9I3Yxm8xTZusD9JFtiwSsoZKV753nMA/w=",
      "url": "lib/bootstrap-icons/icons/bookmark-star-fill.svg"
    },
    {
      "hash": "sha256-4CvN+yWVqD/rWIUWKavB5Wgg0nxRVyDTALz5dS1MY80=",
      "url": "lib/bootstrap-icons/icons/bookmark-star.svg"
    },
    {
      "hash": "sha256-3kPdF6rFks25eKNAg3iI7g7ekFucAt7K9/lgWRr+NVY=",
      "url": "lib/bootstrap-icons/icons/bookmark-x-fill.svg"
    },
    {
      "hash": "sha256-eXqVdH68YZk7anIXHvetDrZ9vp96UcFcg8m+qBchlfU=",
      "url": "lib/bootstrap-icons/icons/bookmark-x.svg"
    },
    {
      "hash": "sha256-tKOShS4YJbu07HzmHNkuoC6War2DdydMU/NKSAe+Ykg=",
      "url": "lib/bootstrap-icons/icons/bookmark.svg"
    },
    {
      "hash": "sha256-Pxm4RfLoHFjbcHw6CcXoK5K1rqgRRyWmm+0zRG251Zk=",
      "url": "lib/bootstrap-icons/icons/bookmarks-fill.svg"
    },
    {
      "hash": "sha256-PuZ41xqqvidDoU3ImiDNzKN1kDqyW/KVgBNgCBjo+gk=",
      "url": "lib/bootstrap-icons/icons/bookmarks.svg"
    },
    {
      "hash": "sha256-weiV0QVMs0Pipt0ay+DK1NOZuzSO5uejDryxE8WYrV8=",
      "url": "lib/bootstrap-icons/icons/bookshelf.svg"
    },
    {
      "hash": "sha256-dAO4eUARyWAAlB4bf234Ll76LQFjNmg8+XEZ9Cf0UgM=",
      "url": "lib/bootstrap-icons/icons/boombox-fill.svg"
    },
    {
      "hash": "sha256-Sqoutcz6V+cgyowj0qD2jDpLU9qaI6GZAbTbu/qZBww=",
      "url": "lib/bootstrap-icons/icons/boombox.svg"
    },
    {
      "hash": "sha256-sr+dGV8kJhz2z8hgAfug0MEL2GlvzQGkeBnhgg0fNJE=",
      "url": "lib/bootstrap-icons/icons/bootstrap-fill.svg"
    },
    {
      "hash": "sha256-9gUBbH9q/9UNuygTAnKi/RtHLk3Z8RqBZ0qJ/QQ/AUU=",
      "url": "lib/bootstrap-icons/icons/bootstrap-reboot.svg"
    },
    {
      "hash": "sha256-Km83Z5vurkrnYNC0kJe71LAPWJZx6+EeGGL1rEALfm0=",
      "url": "lib/bootstrap-icons/icons/bootstrap.svg"
    },
    {
      "hash": "sha256-NNppnQO5QROvcMv8lo28+x/jWcN4sdAurH1KC9vnZJA=",
      "url": "lib/bootstrap-icons/icons/border-all.svg"
    },
    {
      "hash": "sha256-Pu/os0wRjENs7LNvwe7BlYoHycBNQE3yv3ZBwOx8LZY=",
      "url": "lib/bootstrap-icons/icons/border-bottom.svg"
    },
    {
      "hash": "sha256-PD0K58v+Y/BlvxYCD8aU/Fbcjdi6uA2GWrzDWHmK2w0=",
      "url": "lib/bootstrap-icons/icons/border-center.svg"
    },
    {
      "hash": "sha256-PubTLTjs3sj4W3sGyETDfa/hh3SAA/JnVSXkGRDnXO0=",
      "url": "lib/bootstrap-icons/icons/border-inner.svg"
    },
    {
      "hash": "sha256-MOD1+pUJ8XxmQpspjdYcBwl239H9aR0wqAAFXuc/Va4=",
      "url": "lib/bootstrap-icons/icons/border-left.svg"
    },
    {
      "hash": "sha256-qV/YMCg3wTXhUbJaSxGYuCd967jkU6HvfFewpA6F4kE=",
      "url": "lib/bootstrap-icons/icons/border-middle.svg"
    },
    {
      "hash": "sha256-eYKP6BWfLB27meMtne4vtqZjA4XpuiK1hjM54K1KafI=",
      "url": "lib/bootstrap-icons/icons/border-outer.svg"
    },
    {
      "hash": "sha256-RseeJUnhEr0MyxXgVHyKYJZKkxlLiuDD+uUte8RasAQ=",
      "url": "lib/bootstrap-icons/icons/border-right.svg"
    },
    {
      "hash": "sha256-lbYFBi/Yvpqzwlq5RKDAyjpAVAUXxC9HhuZn5qnlMdE=",
      "url": "lib/bootstrap-icons/icons/border-style.svg"
    },
    {
      "hash": "sha256-EtmMvjampC9uQcXeixGlU6TbOOCVAlP+ipCf+0hX2+U=",
      "url": "lib/bootstrap-icons/icons/border-top.svg"
    },
    {
      "hash": "sha256-MJJBmLd4Le8tojmRkcCHnuINf/gRRtlqCvRQsBssmAM=",
      "url": "lib/bootstrap-icons/icons/border-width.svg"
    },
    {
      "hash": "sha256-2lkNT+/eL0dOrGg8eOSomtWMBkv15XfqHbDF374UsIE=",
      "url": "lib/bootstrap-icons/icons/border.svg"
    },
    {
      "hash": "sha256-gYmVa9PcC3v0j3ipI5XwZNjA2M0qEDCqwoRmUwK3rcM=",
      "url": "lib/bootstrap-icons/icons/bounding-box-circles.svg"
    },
    {
      "hash": "sha256-pFi7EamZ3bZLb7zffI8aufzPs3TlPF9Gx7nACxI1N/8=",
      "url": "lib/bootstrap-icons/icons/bounding-box.svg"
    },
    {
      "hash": "sha256-7b8BLzXLkr9IYFrZ7gu/t4db/uuCDb895jVIASJCLrA=",
      "url": "lib/bootstrap-icons/icons/box-arrow-down-left.svg"
    },
    {
      "hash": "sha256-2utQBQiVakESzRZ92bel6uhtfdXBkmBQT8Kh91r36nE=",
      "url": "lib/bootstrap-icons/icons/box-arrow-down-right.svg"
    },
    {
      "hash": "sha256-ae2YYCn/lMNRitL7NFxMn9rdjP9JEC5q51wHZ4kU8Uc=",
      "url": "lib/bootstrap-icons/icons/box-arrow-down.svg"
    },
    {
      "hash": "sha256-rIF42TyRbGLQ+LKlowZhYNiJrTVd1tZnsQVJfIDjA1Y=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-down-left.svg"
    },
    {
      "hash": "sha256-WKdkUes3qlAUvx8cL5ASqigNO/5A0kTGIUxdwcoqkuE=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-down-right.svg"
    },
    {
      "hash": "sha256-wt8fgDJankyn3HupgKmzvPxvhDImXTBg4ZITL5msYQc=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-down.svg"
    },
    {
      "hash": "sha256-pWaVAfgYTPiEuh0KTdW4n/U/O3X1M8Dw5FIhBn8K4I4=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-left.svg"
    },
    {
      "hash": "sha256-QcB4VP+i3pi6Sc+r+0Pg3tp6zFzV77gFhN06TCu14h0=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-right.svg"
    },
    {
      "hash": "sha256-Gi4JjWFezA18BIUk9SphWcU7tdoC6cWaac838aGi5Zc=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-up-left.svg"
    },
    {
      "hash": "sha256-eej0Z/8N9cgEbKT9O288XYkz/jPKeTyf7ZP72V7oElE=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-up-right.svg"
    },
    {
      "hash": "sha256-knkmoL2BjX34xjOdJHiCnIvKAgLIYhgYxfWeOfasBF0=",
      "url": "lib/bootstrap-icons/icons/box-arrow-in-up.svg"
    },
    {
      "hash": "sha256-Zdd1EEmQmGJF2ZMFp2ADi7rG1NB5EkxtNl25G3Tiqvs=",
      "url": "lib/bootstrap-icons/icons/box-arrow-left.svg"
    },
    {
      "hash": "sha256-ykhrpg3w7qZwk2p/AW3Nk+L3uCvj6NprCEVKvnVmhLs=",
      "url": "lib/bootstrap-icons/icons/box-arrow-right.svg"
    },
    {
      "hash": "sha256-on8znMFABm+LoaQpYk22dJGmoV3wQltbCfQ1w+DV2JQ=",
      "url": "lib/bootstrap-icons/icons/box-arrow-up-left.svg"
    },
    {
      "hash": "sha256-+T2qjFzoeOYCRflKnZuUjPKgJmtDp37qL356PmsM6kc=",
      "url": "lib/bootstrap-icons/icons/box-arrow-up-right.svg"
    },
    {
      "hash": "sha256-8NJbwfRmwDkh1ZZMfv/vSR/nwPAaDBAogOYA9knC+X4=",
      "url": "lib/bootstrap-icons/icons/box-arrow-up.svg"
    },
    {
      "hash": "sha256-+M3mL56Q2PuCwUXxXs3pzTBAgIv3rsPZpOkhwtaGlqs=",
      "url": "lib/bootstrap-icons/icons/box-fill.svg"
    },
    {
      "hash": "sha256-VI9XBV39czfgSbMBOPxmupuNZnnwuuzMhaoSjqfKI7Y=",
      "url": "lib/bootstrap-icons/icons/box-seam-fill.svg"
    },
    {
      "hash": "sha256-7xqaB5otrNar7/8g/pYmjvIi14wxFfQwl2jf6EP4iWU=",
      "url": "lib/bootstrap-icons/icons/box-seam.svg"
    },
    {
      "hash": "sha256-6hXNt8Fib2n2rmkejfagXpio4uwMwvWkcrP6AiGsRUU=",
      "url": "lib/bootstrap-icons/icons/box.svg"
    },
    {
      "hash": "sha256-mz1W0nqlMdXz2i/gfWnB8F3o6MDRBXED1JDrH07sTUw=",
      "url": "lib/bootstrap-icons/icons/box2-fill.svg"
    },
    {
      "hash": "sha256-3h9NU2o8M7FbIjF95TK0a6YpMCeNjXyxwpt+mlHrLR0=",
      "url": "lib/bootstrap-icons/icons/box2-heart-fill.svg"
    },
    {
      "hash": "sha256-TRTzP/VLhCVBEnufJsVl80Ikv00y9tlCqAhPfJbICqI=",
      "url": "lib/bootstrap-icons/icons/box2-heart.svg"
    },
    {
      "hash": "sha256-MD8qEAkxCUg5uBkqq685VtbNi4nKKcnuSHbBJbSYf0c=",
      "url": "lib/bootstrap-icons/icons/box2.svg"
    },
    {
      "hash": "sha256-/iLJ4IpSCJ5nnefxhPPi9ZCI6IpZf/G1RkKuoGhJSMI=",
      "url": "lib/bootstrap-icons/icons/boxes.svg"
    },
    {
      "hash": "sha256-epX5JOqpuY6HV9jQgjLUGrpq20HJ4WZjZPzxDpXTeZM=",
      "url": "lib/bootstrap-icons/icons/braces-asterisk.svg"
    },
    {
      "hash": "sha256-jiBFehU0k3w67TruCXw8H/la0fmUHF5E0w4unmivOdw=",
      "url": "lib/bootstrap-icons/icons/braces.svg"
    },
    {
      "hash": "sha256-6ggU/4jHRxMx8qbJ199rA1y6KWnbkg6aypOSron50mk=",
      "url": "lib/bootstrap-icons/icons/bricks.svg"
    },
    {
      "hash": "sha256-NQTVvPuJP7lB6ldvpXwxsqhigpN5AfwR7MzC4YCPnnY=",
      "url": "lib/bootstrap-icons/icons/briefcase-fill.svg"
    },
    {
      "hash": "sha256-DghBMxMAHGMOa10XA76otPKNoPNqjL0Y0cVifRkjyf0=",
      "url": "lib/bootstrap-icons/icons/briefcase.svg"
    },
    {
      "hash": "sha256-gXA/U+wtoF/mqt+gYjNRh2WxmSY1YokFKp9krgHt8ZE=",
      "url": "lib/bootstrap-icons/icons/brightness-alt-high-fill.svg"
    },
    {
      "hash": "sha256-SQ8/baw/meW6YQhO6p5TY4Ka7i46f5UXeGvtlc7XvFU=",
      "url": "lib/bootstrap-icons/icons/brightness-alt-high.svg"
    },
    {
      "hash": "sha256-3fNv7HjCyK82nbIytkOLyZOqtTGYkyryDXWUETO9+ak=",
      "url": "lib/bootstrap-icons/icons/brightness-alt-low-fill.svg"
    },
    {
      "hash": "sha256-1Kteij64WGdFv2XSmCxke7gL6UgjcgENJOQrP0+/x5A=",
      "url": "lib/bootstrap-icons/icons/brightness-alt-low.svg"
    },
    {
      "hash": "sha256-inVmIDz0UqDLMGnpROOR69pZRuaagpYiZed/1wjqmi8=",
      "url": "lib/bootstrap-icons/icons/brightness-high-fill.svg"
    },
    {
      "hash": "sha256-2/alLw1P2ewGztrmxpdYIsLP/NVdxaW5xF1DIXSU2qQ=",
      "url": "lib/bootstrap-icons/icons/brightness-high.svg"
    },
    {
      "hash": "sha256-Us4RJlvscnLdsAydqL6dmzA2BelSA/a5UTSld4YJfw8=",
      "url": "lib/bootstrap-icons/icons/brightness-low-fill.svg"
    },
    {
      "hash": "sha256-vaY2/u1LnREmktzZvCpJiQIjK1FoN6KmVzlgerlroKw=",
      "url": "lib/bootstrap-icons/icons/brightness-low.svg"
    },
    {
      "hash": "sha256-dnbj9rJmB7YVviCBoOY5OH3/ptsXrBB8aKyFasIWqFU=",
      "url": "lib/bootstrap-icons/icons/brilliance.svg"
    },
    {
      "hash": "sha256-JHAJvjqwwgYchsLPSvtzlWq5JqWksXewtFUmHSHaHxc=",
      "url": "lib/bootstrap-icons/icons/broadcast-pin.svg"
    },
    {
      "hash": "sha256-ELvvsXVUlxKc1cHqV75X64uH+aCLOBuzF+DWdkBfLW4=",
      "url": "lib/bootstrap-icons/icons/broadcast.svg"
    },
    {
      "hash": "sha256-EeJi1+cwV/BxLsMvuqGcN5g6Sjh76E8TfkAte+iG2EA=",
      "url": "lib/bootstrap-icons/icons/browser-chrome.svg"
    },
    {
      "hash": "sha256-0dlm6V0SAWr5xneEz3vmv80y0Kz31nDEMp4bAJ3d/Os=",
      "url": "lib/bootstrap-icons/icons/browser-edge.svg"
    },
    {
      "hash": "sha256-XNbPY1wCCSciYKvHY8Ucf6NUgjXGVa7UQhXRcuwJMlk=",
      "url": "lib/bootstrap-icons/icons/browser-firefox.svg"
    },
    {
      "hash": "sha256-5eUpAf5o3EnuLMky0Fm2EZ5sTD8DvvIp47v0PuFlcKc=",
      "url": "lib/bootstrap-icons/icons/browser-safari.svg"
    },
    {
      "hash": "sha256-ZRUPAi328ebyHJ20MLiALooQjdpRL6DJwBc9ZAmLYHQ=",
      "url": "lib/bootstrap-icons/icons/brush-fill.svg"
    },
    {
      "hash": "sha256-oSTKuwBBrJg1v6vS4F5QF9WBE6p8ZlpYi8owkLOSu3c=",
      "url": "lib/bootstrap-icons/icons/brush.svg"
    },
    {
      "hash": "sha256-QE9zyFt9w941h1eWy0a61Gp50db3U4OiKBu7lSGc8Ws=",
      "url": "lib/bootstrap-icons/icons/bucket-fill.svg"
    },
    {
      "hash": "sha256-pAry4+gG8yd2Jj5t72ShrSHC1FeA8yvKUI0Ob9vBOWE=",
      "url": "lib/bootstrap-icons/icons/bucket.svg"
    },
    {
      "hash": "sha256-gqtjERwlQSqlbXIML6rNTotYN/ODQH+GV65WF3F/bjY=",
      "url": "lib/bootstrap-icons/icons/bug-fill.svg"
    },
    {
      "hash": "sha256-HZzUHKy2j20QYMAayLHVPRrwd1kFr4/AHTh3LtBzGQo=",
      "url": "lib/bootstrap-icons/icons/bug.svg"
    },
    {
      "hash": "sha256-YL40cbq810F9dKV10oCpCW95Gmxn83d4Ko2vm+gu0rw=",
      "url": "lib/bootstrap-icons/icons/building-add.svg"
    },
    {
      "hash": "sha256-RagynQK/sUTNILq4fbKnYUsWsnXUcWVdw6PJv6AE5iM=",
      "url": "lib/bootstrap-icons/icons/building-check.svg"
    },
    {
      "hash": "sha256-9SIV7uHeEByXyv3sgZr2V6533FScp8XvMkLscHKwZ7k=",
      "url": "lib/bootstrap-icons/icons/building-dash.svg"
    },
    {
      "hash": "sha256-JqaMsG3bNL9L6qVzbxR6cTlkEz0aK6qdIRuPovtdJkY=",
      "url": "lib/bootstrap-icons/icons/building-down.svg"
    },
    {
      "hash": "sha256-zWc0h8sEMFLs0RfWQfOGGgoDGbf4kPvNYIby9iKu8YQ=",
      "url": "lib/bootstrap-icons/icons/building-exclamation.svg"
    },
    {
      "hash": "sha256-9M6g+fVMnMLoWFIT2vUNV4Tpli2jzL6hYW+QxptHlKA=",
      "url": "lib/bootstrap-icons/icons/building-fill-add.svg"
    },
    {
      "hash": "sha256-XWX55QlL2WSlWm8rrHj/ByLzkriT54pYguvZ/8A7FAs=",
      "url": "lib/bootstrap-icons/icons/building-fill-check.svg"
    },
    {
      "hash": "sha256-uzitisIxiXwHcoODZw/wbBlZbJA+B70yKX5u3h/Tvvg=",
      "url": "lib/bootstrap-icons/icons/building-fill-dash.svg"
    },
    {
      "hash": "sha256-/74ZOnrvj4Z4KkG6CG6lkxUBclDDuUSXVSgucT9+mkc=",
      "url": "lib/bootstrap-icons/icons/building-fill-down.svg"
    },
    {
      "hash": "sha256-toPBVZkrrvxWY+i1YMm/Nt6dmgifsI3GF5e/M9KZ38U=",
      "url": "lib/bootstrap-icons/icons/building-fill-exclamation.svg"
    },
    {
      "hash": "sha256-z54J8EfQA+B+9ZPQQk3g55lLBEP7kYPAwMwdRNFi+1A=",
      "url": "lib/bootstrap-icons/icons/building-fill-gear.svg"
    },
    {
      "hash": "sha256-Tfd9qscAq5oGiwmY4+GiEAuZaqnDMG3iHS0RXHVKMVQ=",
      "url": "lib/bootstrap-icons/icons/building-fill-lock.svg"
    },
    {
      "hash": "sha256-bFfa4aAELvugwWfUjk65lbav/tyO8UEppYZW5pN57Dg=",
      "url": "lib/bootstrap-icons/icons/building-fill-slash.svg"
    },
    {
      "hash": "sha256-TLJXW8yZhgibTqwwMWpG9XDNo5GR+kkjSTVcXStJvzk=",
      "url": "lib/bootstrap-icons/icons/building-fill-up.svg"
    },
    {
      "hash": "sha256-lO2s4fZWSJsPzKS985XQszVcoZdlWgBq3paDAdbZ2hs=",
      "url": "lib/bootstrap-icons/icons/building-fill-x.svg"
    },
    {
      "hash": "sha256-YysKQ05sAqDWuLPY9RGfRu5RaJRuryPb8c/ZJJYk2qU=",
      "url": "lib/bootstrap-icons/icons/building-fill.svg"
    },
    {
      "hash": "sha256-e+VgkroZsG/WNacN25mdciVUJiG0EzKoJ53reYQdLxU=",
      "url": "lib/bootstrap-icons/icons/building-gear.svg"
    },
    {
      "hash": "sha256-nvR76XvL/Y6HBut61g5L5bpn6QWFG3oNaZ+ZycYudgo=",
      "url": "lib/bootstrap-icons/icons/building-lock.svg"
    },
    {
      "hash": "sha256-BfCVLMRgFACxwlceCPl2u0Veo+TgExelTn5TFgzw2aI=",
      "url": "lib/bootstrap-icons/icons/building-slash.svg"
    },
    {
      "hash": "sha256-vVTossMtJ2oaj8j00JDjoHW7K0id6SkeVj90KRGzeD0=",
      "url": "lib/bootstrap-icons/icons/building-up.svg"
    },
    {
      "hash": "sha256-Ps6HJkXVAD8SMRY5fgq04u9wBYNTYFqfeBVBMaiQOHc=",
      "url": "lib/bootstrap-icons/icons/building-x.svg"
    },
    {
      "hash": "sha256-8MyNoEAsDnt553KAdwVyvUzYGz0w+a77gyqXrewXIZI=",
      "url": "lib/bootstrap-icons/icons/building.svg"
    },
    {
      "hash": "sha256-1kG9GqyZKV13N5zoZwF/OOObteVAKzyaXQ/WtPv8zAM=",
      "url": "lib/bootstrap-icons/icons/buildings-fill.svg"
    },
    {
      "hash": "sha256-NNkGGBrPQ3JeUKwshcqlfJBD9swKJqmR+vr9NnMBAy4=",
      "url": "lib/bootstrap-icons/icons/buildings.svg"
    },
    {
      "hash": "sha256-qGVZLWyTbBTPHndPX5O5rxfvd/iIeArNZY4zfOZUHbw=",
      "url": "lib/bootstrap-icons/icons/bullseye.svg"
    },
    {
      "hash": "sha256-N0F1hz8uB3PgH771VRP1aLtdoIDYHOAjg4yfklCJ3kA=",
      "url": "lib/bootstrap-icons/icons/bus-front-fill.svg"
    },
    {
      "hash": "sha256-qOTIgAE04qK3QFgbYwzXsbpJSGmt0n5oVqVinMQC/hI=",
      "url": "lib/bootstrap-icons/icons/bus-front.svg"
    },
    {
      "hash": "sha256-FG2wiL725mjQq4xAYs5hpRYciPGlP8ydHi9EiKdNLqk=",
      "url": "lib/bootstrap-icons/icons/c-circle-fill.svg"
    },
    {
      "hash": "sha256-S6F31UvCNqVHQjLh63MFd+httaxhuoiJ/e+5RREWz98=",
      "url": "lib/bootstrap-icons/icons/c-circle.svg"
    },
    {
      "hash": "sha256-DjtXtbK5H4Ma60LqAI0S+updzFrMOCEtY6ZIBNmeyYk=",
      "url": "lib/bootstrap-icons/icons/c-square-fill.svg"
    },
    {
      "hash": "sha256-uDNP4mNldE0EMLBjf/VhbAuzKeo4UJ7mOfzHndroAXE=",
      "url": "lib/bootstrap-icons/icons/c-square.svg"
    },
    {
      "hash": "sha256-8XpL8XapR7ZAFO2pEcH0LgmmK6IAD9zwd9ynLjtdBvI=",
      "url": "lib/bootstrap-icons/icons/cake-fill.svg"
    },
    {
      "hash": "sha256-5le0qCVpKTpFl4ob47ftv3UsqXcZEJm74kVGAqZYwDw=",
      "url": "lib/bootstrap-icons/icons/cake.svg"
    },
    {
      "hash": "sha256-WodeC+SD2IEcL/woxzibq4NkypXRpguro6QcRXHJTXI=",
      "url": "lib/bootstrap-icons/icons/cake2-fill.svg"
    },
    {
      "hash": "sha256-ltJ9IxHuZOVCXfUTESgQJOJtqdi4/2JDaTB75AgkJs4=",
      "url": "lib/bootstrap-icons/icons/cake2.svg"
    },
    {
      "hash": "sha256-HpSSlhVfP5yvF4pbkW50dftS56VfNoYBVds1EQ1dgVw=",
      "url": "lib/bootstrap-icons/icons/calculator-fill.svg"
    },
    {
      "hash": "sha256-+bp1XCTHYQ2clT+URuMSIPxB25xMlzRBtr21OQZi77M=",
      "url": "lib/bootstrap-icons/icons/calculator.svg"
    },
    {
      "hash": "sha256-NzHMdVlCQ6eBAPrynjh/JDyjNHXFlp0/H3BvvtldsiU=",
      "url": "lib/bootstrap-icons/icons/calendar-check-fill.svg"
    },
    {
      "hash": "sha256-nMOSg/cQqemoSr+dMjRtH0/8fsCzgwk3wOhcftQMlo0=",
      "url": "lib/bootstrap-icons/icons/calendar-check.svg"
    },
    {
      "hash": "sha256-BY/seucF4RpYwSYWP6hAqMK32Ndxu88+Bm/7Ng6mM00=",
      "url": "lib/bootstrap-icons/icons/calendar-date-fill.svg"
    },
    {
      "hash": "sha256-w2zsqIWcIGC78OGeipAjxANxEcv1mNs6FT8ZJ8F5L5o=",
      "url": "lib/bootstrap-icons/icons/calendar-date.svg"
    },
    {
      "hash": "sha256-7LKGUNh1Am+A9lmcpbr+TdtCcqTqFM2khyCfbZfXls4=",
      "url": "lib/bootstrap-icons/icons/calendar-day-fill.svg"
    },
    {
      "hash": "sha256-nKr11K7dlEalExmOkIVspUrZvJW7NCVaReZE8OTDRfA=",
      "url": "lib/bootstrap-icons/icons/calendar-day.svg"
    },
    {
      "hash": "sha256-6d23b0/WLpmJCQVcMgyIX7e5SDjfoaVNm6JIctwIBa4=",
      "url": "lib/bootstrap-icons/icons/calendar-event-fill.svg"
    },
    {
      "hash": "sha256-3SRd/Ji+fn0KwxQWdh0mMlMKZN6iqLApob3ocn9UT/o=",
      "url": "lib/bootstrap-icons/icons/calendar-event.svg"
    },
    {
      "hash": "sha256-DC6V7I6k0axI85KbPGZOGUxWsGdJI/yin2w5GmxYuBk=",
      "url": "lib/bootstrap-icons/icons/calendar-fill.svg"
    },
    {
      "hash": "sha256-R7ZT8KclkaXFv4sabvJp0T33lrkJ5gKPfpEEnHWt0U8=",
      "url": "lib/bootstrap-icons/icons/calendar-heart-fill.svg"
    },
    {
      "hash": "sha256-CEnYL0vpedMy4uC1kZ4Pk7k5/7hPotz6Qh1mGhOTJGY=",
      "url": "lib/bootstrap-icons/icons/calendar-heart.svg"
    },
    {
      "hash": "sha256-1cn9SwgZveherJZ1ffE+/h/8W2pA1TIQhAjX7OS0oiQ=",
      "url": "lib/bootstrap-icons/icons/calendar-minus-fill.svg"
    },
    {
      "hash": "sha256-aA09R29HtonUdaiwjm08uPpHAhDBsiwel2+kNcFydRc=",
      "url": "lib/bootstrap-icons/icons/calendar-minus.svg"
    },
    {
      "hash": "sha256-jxIqAIF40LrXimgiDRagxnUiijyeUXgCioEYFt/6UEM=",
      "url": "lib/bootstrap-icons/icons/calendar-month-fill.svg"
    },
    {
      "hash": "sha256-ezN9mdzZDRrjCLb/SdlTlUSeOyZoWE2aBXbop/E4aXA=",
      "url": "lib/bootstrap-icons/icons/calendar-month.svg"
    },
    {
      "hash": "sha256-LGgn3kGNDnIEf4VZFFfcXM3xpvnLdUfwBELTT1pTl78=",
      "url": "lib/bootstrap-icons/icons/calendar-plus-fill.svg"
    },
    {
      "hash": "sha256-XfhHkAr0zLU9bKkvSs6skRAewdVhcCJz8A+9yVuu8Bc=",
      "url": "lib/bootstrap-icons/icons/calendar-plus.svg"
    },
    {
      "hash": "sha256-X9QF7DJzRdJks1C4d3X9PuBOFttXqs+k9qUEFnHVsqE=",
      "url": "lib/bootstrap-icons/icons/calendar-range-fill.svg"
    },
    {
      "hash": "sha256-JpNsSkNO+INIf86lVO/mAL4LlTKFd3c9pdfwmheOnVY=",
      "url": "lib/bootstrap-icons/icons/calendar-range.svg"
    },
    {
      "hash": "sha256-UIojJA5AOeNr3goZq8E5qWZaMafGUZevC7cekqE4S9s=",
      "url": "lib/bootstrap-icons/icons/calendar-week-fill.svg"
    },
    {
      "hash": "sha256-ywN0v6f98YTpYOKo2QFNUqWilLn9xRF+g9Zh+j6gDqs=",
      "url": "lib/bootstrap-icons/icons/calendar-week.svg"
    },
    {
      "hash": "sha256-x8MgLDkHmncp46Nr79p0DEUhfpEYSFBW4AlWY6YBqBA=",
      "url": "lib/bootstrap-icons/icons/calendar-x-fill.svg"
    },
    {
      "hash": "sha256-2tVpSSa2SbgPdbAUB6p40AUW4Gt8ZfaNo/9o32OE6es=",
      "url": "lib/bootstrap-icons/icons/calendar-x.svg"
    },
    {
      "hash": "sha256-Gc1k1ZwGuHVFg2n09UYnWSKdIYgA4Bq2iu9U0UZEMjU=",
      "url": "lib/bootstrap-icons/icons/calendar.svg"
    },
    {
      "hash": "sha256-q1gVdHeSpQTOYLA3VqW+m49rguv4L3biO6sEBUwQpg8=",
      "url": "lib/bootstrap-icons/icons/calendar2-check-fill.svg"
    },
    {
      "hash": "sha256-3MDflwCjjBC0UxdsAyeanpAT3301noWL3SRGK8iZ0rY=",
      "url": "lib/bootstrap-icons/icons/calendar2-check.svg"
    },
    {
      "hash": "sha256-zFxJWYFxoLSH5NtNW+eDyqD6zmSIHEZjDmUrBqSzu+U=",
      "url": "lib/bootstrap-icons/icons/calendar2-date-fill.svg"
    },
    {
      "hash": "sha256-Wt307S6RLSOBcDJkvC53+LuBDihFmnnJSP5anciCMD4=",
      "url": "lib/bootstrap-icons/icons/calendar2-date.svg"
    },
    {
      "hash": "sha256-jtQwecDKRZfV1wDUZNK6Fw7kMDn6wVnJwUJpAy7o35I=",
      "url": "lib/bootstrap-icons/icons/calendar2-day-fill.svg"
    },
    {
      "hash": "sha256-0llM9ZmmUPN1R5H7wg2qw3h9mtv1bAxmbBSkG7m3si8=",
      "url": "lib/bootstrap-icons/icons/calendar2-day.svg"
    },
    {
      "hash": "sha256-APr9vqyHOaLUrKgQZsxH9tv/fFrOCmg2I+r/F5yiroc=",
      "url": "lib/bootstrap-icons/icons/calendar2-event-fill.svg"
    },
    {
      "hash": "sha256-2tfGA2O6/Or8ZnRCrEu95zrUecD3IHDXVD9yi5A4jU8=",
      "url": "lib/bootstrap-icons/icons/calendar2-event.svg"
    },
    {
      "hash": "sha256-Z7k5+7ZhLl+SM5vtIQQaw+MaEeD8OmG2+SsX4L0kNhU=",
      "url": "lib/bootstrap-icons/icons/calendar2-fill.svg"
    },
    {
      "hash": "sha256-5SwUPG9v5dHaJsu2cw9Ivp9o/50Id7KJ7A1DSIO6ViY=",
      "url": "lib/bootstrap-icons/icons/calendar2-heart-fill.svg"
    },
    {
      "hash": "sha256-lbVNzc0QZt8c+aJawlvdKZ5IZQkJnkEHkvRdolqYnHE=",
      "url": "lib/bootstrap-icons/icons/calendar2-heart.svg"
    },
    {
      "hash": "sha256-QsLKy7L7RFiZX1gKw+q29qQ8Hrm/yHWgrmp8295qZYA=",
      "url": "lib/bootstrap-icons/icons/calendar2-minus-fill.svg"
    },
    {
      "hash": "sha256-kHG8eKM8JxznOHM4AjQMeennIeLCrZt41/U648jo/xk=",
      "url": "lib/bootstrap-icons/icons/calendar2-minus.svg"
    },
    {
      "hash": "sha256-OpgxCXTktRybCm7WrDWISkTc3zN2AIPo7uN4El7TxfY=",
      "url": "lib/bootstrap-icons/icons/calendar2-month-fill.svg"
    },
    {
      "hash": "sha256-lCw3sgbVUN4nt9pEfZd3jgWDC/AalZg4UnnUlS1nbNc=",
      "url": "lib/bootstrap-icons/icons/calendar2-month.svg"
    },
    {
      "hash": "sha256-owQTy+wjPPhOBVxfekiJHYc1tR2T9cmPXxxZS0Gv53Q=",
      "url": "lib/bootstrap-icons/icons/calendar2-plus-fill.svg"
    },
    {
      "hash": "sha256-khEW0ALISSJZJQv3c2B1tXT8uVUguuYzzK8WB/qht7c=",
      "url": "lib/bootstrap-icons/icons/calendar2-plus.svg"
    },
    {
      "hash": "sha256-yoQ3PDokyrqlvzGsLTNXzH/yO952DefKsg/RXogtYJk=",
      "url": "lib/bootstrap-icons/icons/calendar2-range-fill.svg"
    },
    {
      "hash": "sha256-+brIxSgEbbklgWx5vO5oX+bwqRsHU59Ew1KSWVw5Nrc=",
      "url": "lib/bootstrap-icons/icons/calendar2-range.svg"
    },
    {
      "hash": "sha256-YeAIcyNifCjHAk76QyDJKRlEslhYebWoa8YgMIcOY+A=",
      "url": "lib/bootstrap-icons/icons/calendar2-week-fill.svg"
    },
    {
      "hash": "sha256-69lYdVUqoapdh8Y4oIBBFT4SsKtwqZzt5ZTDHU3cM7Y=",
      "url": "lib/bootstrap-icons/icons/calendar2-week.svg"
    },
    {
      "hash": "sha256-jKVx65EYjsv6SQkkPZERaE+verWsU+jAmq0uq3OeRmc=",
      "url": "lib/bootstrap-icons/icons/calendar2-x-fill.svg"
    },
    {
      "hash": "sha256-p6gVdw3mDAd4NR8I0b8X3+RhMKM50zYr7lrHVKFLbOA=",
      "url": "lib/bootstrap-icons/icons/calendar2-x.svg"
    },
    {
      "hash": "sha256-0NjX/eXAS1PSMQHUcoAmQNtgpUnnFC//qeIl1KtS9sU=",
      "url": "lib/bootstrap-icons/icons/calendar2.svg"
    },
    {
      "hash": "sha256-Dw851bP4/kmLSO4kbh9mhsn42ZVpEURNaYowj6Jju9I=",
      "url": "lib/bootstrap-icons/icons/calendar3-event-fill.svg"
    },
    {
      "hash": "sha256-DNx3uNjS9MraGhCEL+v0sKn9pxPmU1ZT0KKRQHktga8=",
      "url": "lib/bootstrap-icons/icons/calendar3-event.svg"
    },
    {
      "hash": "sha256-XzX3OyOM6yHyvS1kX5uepWo2lml9Y9hCKhL5PXR/x84=",
      "url": "lib/bootstrap-icons/icons/calendar3-fill.svg"
    },
    {
      "hash": "sha256-Q4QmPc8orKmMlaLDyDGGiJrmxHQaGCbWiDeZOKR1uyQ=",
      "url": "lib/bootstrap-icons/icons/calendar3-range-fill.svg"
    },
    {
      "hash": "sha256-aNQFh/UqohqHSOxtmgdwN456Tw2hJey9vNxiNwXpHmw=",
      "url": "lib/bootstrap-icons/icons/calendar3-range.svg"
    },
    {
      "hash": "sha256-pRw4SMpseeMR/kZBSySmIp3Pyh6PRDWnbxSLj+O/GYo=",
      "url": "lib/bootstrap-icons/icons/calendar3-week-fill.svg"
    },
    {
      "hash": "sha256-+O2XCFjAtKbKkedlT0st9mE0m9K4CA4IP+jhV+K8f8Q=",
      "url": "lib/bootstrap-icons/icons/calendar3-week.svg"
    },
    {
      "hash": "sha256-fof+HUp0rw0/DFMK8Rj78/YevsaT6yihZu342gMOBsg=",
      "url": "lib/bootstrap-icons/icons/calendar3.svg"
    },
    {
      "hash": "sha256-XNU7cj3JPVkUIS1bMRBtvtwFDvjR6AODzW7TP7BL3Sc=",
      "url": "lib/bootstrap-icons/icons/calendar4-event.svg"
    },
    {
      "hash": "sha256-kHEZvm3eM59oZFXgBY8AdfmzmsHO/sLFq9mbQa4LsdI=",
      "url": "lib/bootstrap-icons/icons/calendar4-range.svg"
    },
    {
      "hash": "sha256-lcaiEL5mcwSyIhq9qF9fx6SvyRhRTx9F6qgfvGpwxqs=",
      "url": "lib/bootstrap-icons/icons/calendar4-week.svg"
    },
    {
      "hash": "sha256-2VBJXQd6sa+geCNQO8pB2EIC1v3IW14LdIgFpjsMc0c=",
      "url": "lib/bootstrap-icons/icons/calendar4.svg"
    },
    {
      "hash": "sha256-6BNop0ZNEpn07gmeuLt/sSlRYM3SmjAk7kFYHCkVsiA=",
      "url": "lib/bootstrap-icons/icons/camera-fill.svg"
    },
    {
      "hash": "sha256-8COUwP9JJGjYVSDT/Bwl3imLj4yG8MWPJtXRO7uPR4Q=",
      "url": "lib/bootstrap-icons/icons/camera-reels-fill.svg"
    },
    {
      "hash": "sha256-nhfTWf485J/9j+9wXTzIZ2sTigFrNTdvX6+tfa2LjME=",
      "url": "lib/bootstrap-icons/icons/camera-reels.svg"
    },
    {
      "hash": "sha256-yTu9/J7CaLp2GpIL5h0J8wxiZja6Wbz34X8W8sCJ8dI=",
      "url": "lib/bootstrap-icons/icons/camera-video-fill.svg"
    },
    {
      "hash": "sha256-8fscglC9uOk8ouDwUk2TWvqfpBuUf8CBieoMltvWciM=",
      "url": "lib/bootstrap-icons/icons/camera-video-off-fill.svg"
    },
    {
      "hash": "sha256-U4r2KSAZMB3JJwyege0vAy8m9ScpfI4CaWWm6iPtMuc=",
      "url": "lib/bootstrap-icons/icons/camera-video-off.svg"
    },
    {
      "hash": "sha256-VmDm3qE+i71SvZOtrqfBPuhc00vqYOds+epEWlU1VPc=",
      "url": "lib/bootstrap-icons/icons/camera-video.svg"
    },
    {
      "hash": "sha256-9QxAOfROrN0+HWHCvSg4J2+x14hmI6h7Idjs79o3doA=",
      "url": "lib/bootstrap-icons/icons/camera.svg"
    },
    {
      "hash": "sha256-MCwPsS+G8wFmW2g9eON2MMux+vs9u/k9zzT2ng9Okzk=",
      "url": "lib/bootstrap-icons/icons/camera2.svg"
    },
    {
      "hash": "sha256-RRU98L8RnYFqIVlvGZFh7Pf+ooiEs1WtkbSApsI58oI=",
      "url": "lib/bootstrap-icons/icons/capslock-fill.svg"
    },
    {
      "hash": "sha256-CFe9kXryNiEGqJYDR1yVXFm1gm6wOUlaifKpEkOvIa0=",
      "url": "lib/bootstrap-icons/icons/capslock.svg"
    },
    {
      "hash": "sha256-bsdg2cCtwlp4vJ5mjNHBi/RlNbZJAmmLb65lmQ3G5MY=",
      "url": "lib/bootstrap-icons/icons/capsule-pill.svg"
    },
    {
      "hash": "sha256-+fuZR5pNvS8yFT3WPhfaGZbjPt107r4lwa39PjiTqzQ=",
      "url": "lib/bootstrap-icons/icons/capsule.svg"
    },
    {
      "hash": "sha256-+heFWt9CfHu4mAn2BcfkIbx9MBJ6cRwvrq+d0AZChPQ=",
      "url": "lib/bootstrap-icons/icons/car-front-fill.svg"
    },
    {
      "hash": "sha256-QxYaNZLdMGNXonCmu3RcjiBP1IvRQ9TqQN8vnNSJPN4=",
      "url": "lib/bootstrap-icons/icons/car-front.svg"
    },
    {
      "hash": "sha256-6m3Wb7OYBGjEopp7jPKSx/1gOmzQ+IDbs+GnaaYiWBY=",
      "url": "lib/bootstrap-icons/icons/card-checklist.svg"
    },
    {
      "hash": "sha256-it+nT8F03dxKjN38TB5DDQuNuJS/6mhNysz9s1rXgqY=",
      "url": "lib/bootstrap-icons/icons/card-heading.svg"
    },
    {
      "hash": "sha256-aOEpLp+PD7M0SFpwBRqPhINd99DiDS2nyY9FyAhflkY=",
      "url": "lib/bootstrap-icons/icons/card-image.svg"
    },
    {
      "hash": "sha256-hOTbUOcFvJlD/tvP/jL9wbFj7R38SS9TurlPGmqSJmU=",
      "url": "lib/bootstrap-icons/icons/card-list.svg"
    },
    {
      "hash": "sha256-jTkljYwjRuqHKun/ARBn9ThClpBq+eNvBeYm445iv6o=",
      "url": "lib/bootstrap-icons/icons/card-text.svg"
    },
    {
      "hash": "sha256-dshI6Cd4tit63z1UwClLZYa5i3lcSuDtqdB+0ejs7nw=",
      "url": "lib/bootstrap-icons/icons/caret-down-fill.svg"
    },
    {
      "hash": "sha256-u/xdMXXi+vfW1VmDJbb7h6hhiveeupacRu0mJ6n7ESs=",
      "url": "lib/bootstrap-icons/icons/caret-down-square-fill.svg"
    },
    {
      "hash": "sha256-Zn48BmQtN+BZnwYOGTznOVzvDabmkjsnFHDHmEyXRg4=",
      "url": "lib/bootstrap-icons/icons/caret-down-square.svg"
    },
    {
      "hash": "sha256-2uYVeSJTYrgUBltGj4bwrodtY62DHCGf3XGiyS0sI88=",
      "url": "lib/bootstrap-icons/icons/caret-down.svg"
    },
    {
      "hash": "sha256-qOigEAX/pW2QLJgt8l5EHuycpAS7x0fuqC8ct6H4hHU=",
      "url": "lib/bootstrap-icons/icons/caret-left-fill.svg"
    },
    {
      "hash": "sha256-KHK+dcWwZFtZX6VTG7wkn+G2FtMJcVd/ctUx6vJ4Iuk=",
      "url": "lib/bootstrap-icons/icons/caret-left-square-fill.svg"
    },
    {
      "hash": "sha256-OF6YXUhIXpD/37TYrU+qkXdEGXdSS7lz5MTTimJZ12w=",
      "url": "lib/bootstrap-icons/icons/caret-left-square.svg"
    },
    {
      "hash": "sha256-1p1RtCixJ+esTMvS6Zi50jXhAPpo4Ksbi2AjbSxZh5g=",
      "url": "lib/bootstrap-icons/icons/caret-left.svg"
    },
    {
      "hash": "sha256-ij2SRDN4fpVdVx3ZKHR2kAPLD51MdUu6I82tDJtvQoc=",
      "url": "lib/bootstrap-icons/icons/caret-right-fill.svg"
    },
    {
      "hash": "sha256-7PP7WJfhSQ4ZRlOq2bLUcrHwhKrT44bhT6la7sxMPeg=",
      "url": "lib/bootstrap-icons/icons/caret-right-square-fill.svg"
    },
    {
      "hash": "sha256-Vyi3BhW8RAT9L3KR6Z2AxIvqIOmdKXsnAtF0CTsd4IQ=",
      "url": "lib/bootstrap-icons/icons/caret-right-square.svg"
    },
    {
      "hash": "sha256-Bn3rcW17KZt6jR5/ak52Di64j+mHKfjOGRWTnCoDDlw=",
      "url": "lib/bootstrap-icons/icons/caret-right.svg"
    },
    {
      "hash": "sha256-BMKotcv6NJH4CEvdaQtmz77uSL99DzBaLWbgYR6/hx4=",
      "url": "lib/bootstrap-icons/icons/caret-up-fill.svg"
    },
    {
      "hash": "sha256-x8Lz+/K67ZTAIQvdWBUFcJqsHKKveez1VJ4YoIgMa5I=",
      "url": "lib/bootstrap-icons/icons/caret-up-square-fill.svg"
    },
    {
      "hash": "sha256-FzPQOEl7/16H7bmDehOXlZagQxkJ7sgSHjwMjD79zfU=",
      "url": "lib/bootstrap-icons/icons/caret-up-square.svg"
    },
    {
      "hash": "sha256-us3TrGO9khFCocOhA0b8D3bcKDItJgwkE4FyEZ8cZmk=",
      "url": "lib/bootstrap-icons/icons/caret-up.svg"
    },
    {
      "hash": "sha256-eafoePY4EJ3Z2Kd3GjFtCSsPZyPvdyy1hDbqAb4h1N8=",
      "url": "lib/bootstrap-icons/icons/cart-check-fill.svg"
    },
    {
      "hash": "sha256-s/qUqzGyqTrf5sJDfZ+L8sz58q/Jzd5yO2CPckwdzp4=",
      "url": "lib/bootstrap-icons/icons/cart-check.svg"
    },
    {
      "hash": "sha256-tNHvkfanhUWn+sbmZJECUMiY8KT6iFe7qb63RPhZbXQ=",
      "url": "lib/bootstrap-icons/icons/cart-dash-fill.svg"
    },
    {
      "hash": "sha256-/qBuvXZOltatPj8rlapX3xMcteVDyQgN6S8koXo0lME=",
      "url": "lib/bootstrap-icons/icons/cart-dash.svg"
    },
    {
      "hash": "sha256-uHrQQOhQVUVzPv56q5KvAnvoEcH9vxknL4dTAT9KRhU=",
      "url": "lib/bootstrap-icons/icons/cart-fill.svg"
    },
    {
      "hash": "sha256-Fw7Hdy50COKcefKP9FyaSGTdrSuBMaIA4gwvyjSil2o=",
      "url": "lib/bootstrap-icons/icons/cart-plus-fill.svg"
    },
    {
      "hash": "sha256-Me7tFSYJykxqORrG8L5PCqGaLigwTA0165vGJKgR/RI=",
      "url": "lib/bootstrap-icons/icons/cart-plus.svg"
    },
    {
      "hash": "sha256-r2P+LvTScYX803zmbxJE+o5/GDCLfpP37DHRtNQdzzQ=",
      "url": "lib/bootstrap-icons/icons/cart-x-fill.svg"
    },
    {
      "hash": "sha256-T0mr5mVLHFdi7xrfupUme+dKRgO97YpDiv0ZIJufec0=",
      "url": "lib/bootstrap-icons/icons/cart-x.svg"
    },
    {
      "hash": "sha256-6YZDqvzqvGm7yWn3y9ntY6mO0mnbn3mdB/XGEk7RJXY=",
      "url": "lib/bootstrap-icons/icons/cart.svg"
    },
    {
      "hash": "sha256-AJ6ET7dcbSy+LJrPNNSvd+poiOp9lM/bieuRulwR0FM=",
      "url": "lib/bootstrap-icons/icons/cart2.svg"
    },
    {
      "hash": "sha256-u9OjbeVzOag40u/4Gno/GStwzP5v2dyB3R/eytZZ54I=",
      "url": "lib/bootstrap-icons/icons/cart3.svg"
    },
    {
      "hash": "sha256-msfurxOsS1ZhH9bKsix8CYyx6E33xLcjni4vxk3aSsU=",
      "url": "lib/bootstrap-icons/icons/cart4.svg"
    },
    {
      "hash": "sha256-35ykTOVZsxBGl79I/Yr26Tvuz0lFyeJjn6xeR8QdnoQ=",
      "url": "lib/bootstrap-icons/icons/cash-coin.svg"
    },
    {
      "hash": "sha256-5I7MaMxCaFzXZnp77HU4NiYhUwMOqSuauBRVE81xado=",
      "url": "lib/bootstrap-icons/icons/cash-stack.svg"
    },
    {
      "hash": "sha256-Cnl8EygF8IvUrKVbKEC0nRUISYTmHtx2gLyhkT0z91I=",
      "url": "lib/bootstrap-icons/icons/cash.svg"
    },
    {
      "hash": "sha256-viz5VZH7tFqpDI8jMPoNCsxLKDJVu0jebWr5526SS9s=",
      "url": "lib/bootstrap-icons/icons/cassette-fill.svg"
    },
    {
      "hash": "sha256-2IXDOuhH5dXgOACwOvD6oAuqrM4igLUcSgsZM0LJ0cc=",
      "url": "lib/bootstrap-icons/icons/cassette.svg"
    },
    {
      "hash": "sha256-GT480+qaTerJiwR6odY1pnwluxWV/2scwv+ZV4RqOsc=",
      "url": "lib/bootstrap-icons/icons/cast.svg"
    },
    {
      "hash": "sha256-WcVupxrS/qo0tEtrbmbuJY9n3s2TbTPrBvbcet00+E0=",
      "url": "lib/bootstrap-icons/icons/cc-circle-fill.svg"
    },
    {
      "hash": "sha256-dmuqXo6A6rockdZ9CH5Bci8VXqupYRiU0Q31+QCX6AM=",
      "url": "lib/bootstrap-icons/icons/cc-circle.svg"
    },
    {
      "hash": "sha256-6Q3Nij+YYLqw4mcmF385KftulMicRXViij9iLJeFSLY=",
      "url": "lib/bootstrap-icons/icons/cc-square-fill.svg"
    },
    {
      "hash": "sha256-Q09ADi5Xwx7aPBFoEPmyBjkpJkh0bWwxqtBfXp5JuJo=",
      "url": "lib/bootstrap-icons/icons/cc-square.svg"
    },
    {
      "hash": "sha256-p7ty4J0LzlGI4bH/jnLXZFhJFTMvxABWVnebG5jGCsM=",
      "url": "lib/bootstrap-icons/icons/chat-dots-fill.svg"
    },
    {
      "hash": "sha256-kiBT26gEtBfnU0GTZZnkuioGNh68CwG9qk+mo/TGwS4=",
      "url": "lib/bootstrap-icons/icons/chat-dots.svg"
    },
    {
      "hash": "sha256-dIQNf2x8V6n6mffW7GzDsWOPMqh/nfVZjwXiOozC8is=",
      "url": "lib/bootstrap-icons/icons/chat-fill.svg"
    },
    {
      "hash": "sha256-+dk0SLsCIpF8yGHsr6jsmAaoqFZpuMCcBWREUZzNQfo=",
      "url": "lib/bootstrap-icons/icons/chat-heart-fill.svg"
    },
    {
      "hash": "sha256-r7JI5jGEX+1KydFFX0LwJnoulyN/wx+uEUsibzDDxIY=",
      "url": "lib/bootstrap-icons/icons/chat-heart.svg"
    },
    {
      "hash": "sha256-2xRGGjN/t4eJPaINqukxPyS69d2Ljq4XyVHIy9XqPvg=",
      "url": "lib/bootstrap-icons/icons/chat-left-dots-fill.svg"
    },
    {
      "hash": "sha256-5hJfspGT0PJzNKNJ7+ukDVi6T5nGZUBx8demEkSv/U8=",
      "url": "lib/bootstrap-icons/icons/chat-left-dots.svg"
    },
    {
      "hash": "sha256-4VWOk86bI4PzvaLOXaGr3QCeGCKLOaQzgELdkPYhAX0=",
      "url": "lib/bootstrap-icons/icons/chat-left-fill.svg"
    },
    {
      "hash": "sha256-5vvAy9aUfkO0vb+KczwdyIQTtNnqLdIFYTyquudDJvM=",
      "url": "lib/bootstrap-icons/icons/chat-left-heart-fill.svg"
    },
    {
      "hash": "sha256-tAs6hMZcPEK0IR1xD3YoD3P2en1PdmFcwi/BmO7ZZ7s=",
      "url": "lib/bootstrap-icons/icons/chat-left-heart.svg"
    },
    {
      "hash": "sha256-GyCTBGnqN/NZZo1otJVKNgh4d8Ymb5ZGzH74WyquDC0=",
      "url": "lib/bootstrap-icons/icons/chat-left-quote-fill.svg"
    },
    {
      "hash": "sha256-dYFx4hAYipQY9GZbwV3vPIicgSrm+WdbMcQW/ZObtv0=",
      "url": "lib/bootstrap-icons/icons/chat-left-quote.svg"
    },
    {
      "hash": "sha256-Pi6MYhXTrpNchzMsuFdJ7tqwxGx3tDdsGuet3/eXktA=",
      "url": "lib/bootstrap-icons/icons/chat-left-text-fill.svg"
    },
    {
      "hash": "sha256-gQJdTKJ+wFpDs7kMIJhA8d1go6NbXhvn96h+cCwa8aI=",
      "url": "lib/bootstrap-icons/icons/chat-left-text.svg"
    },
    {
      "hash": "sha256-jRQFFVpF4K9Qj6o/E89RbO1e4Sek9v7JjYPotwAGBV4=",
      "url": "lib/bootstrap-icons/icons/chat-left.svg"
    },
    {
      "hash": "sha256-hl6LtjOlN3/LRFUvkjEdC42ux1nMJzXfn1PVPUCSxgc=",
      "url": "lib/bootstrap-icons/icons/chat-quote-fill.svg"
    },
    {
      "hash": "sha256-z9guzrF24NqmmIKEED88D/KUEjCevG+6/Xyk5hDQBnQ=",
      "url": "lib/bootstrap-icons/icons/chat-quote.svg"
    },
    {
      "hash": "sha256-urYwJiprzS9G5o5G2LVugFklv0DIVw6GaZbMtw4ib+k=",
      "url": "lib/bootstrap-icons/icons/chat-right-dots-fill.svg"
    },
    {
      "hash": "sha256-PdK0CusgZ992iqhY35myOmdEImQK08OshHgVLYhv18U=",
      "url": "lib/bootstrap-icons/icons/chat-right-dots.svg"
    },
    {
      "hash": "sha256-WWnTdXicvO84jlA85u86lBc/orhfQR0PKrNniVezx3U=",
      "url": "lib/bootstrap-icons/icons/chat-right-fill.svg"
    },
    {
      "hash": "sha256-A7qpFyv5eiytCJRgtj8DeqVbI/yROHolLTZJQGav89Q=",
      "url": "lib/bootstrap-icons/icons/chat-right-heart-fill.svg"
    },
    {
      "hash": "sha256-drxPbe69icqi8enNEaeg9qDJfmrKzVHi3GzSGpnAnRQ=",
      "url": "lib/bootstrap-icons/icons/chat-right-heart.svg"
    },
    {
      "hash": "sha256-iAjzNsIvGTCHzb0DeSXItLUpQLeYbp/mZnoWh+KHM0E=",
      "url": "lib/bootstrap-icons/icons/chat-right-quote-fill.svg"
    },
    {
      "hash": "sha256-Q52KbYXHnNoMc/YfAr4P4PeJhD+/oOgIj4PpOAdb6CA=",
      "url": "lib/bootstrap-icons/icons/chat-right-quote.svg"
    },
    {
      "hash": "sha256-74/2JaarkgN3tYoOhvJKmqrz+yrXJm5cwtpDt0CILHI=",
      "url": "lib/bootstrap-icons/icons/chat-right-text-fill.svg"
    },
    {
      "hash": "sha256-Y9Hrzb+rqwmHD9ZyFkZd+6+xgw6z2DneEQXHpcrdlD8=",
      "url": "lib/bootstrap-icons/icons/chat-right-text.svg"
    },
    {
      "hash": "sha256-pO9SIH7TLHmCJPQWjhE4rkYo3eF1dO440n4Tnh8LRCc=",
      "url": "lib/bootstrap-icons/icons/chat-right.svg"
    },
    {
      "hash": "sha256-eKJqg3UuxwZkZQ2ZATFX/i5z+oUxcS7bWe0LVo2XPpc=",
      "url": "lib/bootstrap-icons/icons/chat-square-dots-fill.svg"
    },
    {
      "hash": "sha256-M0l+cEpCvRi7ZP6SQBl1HLfP8X2C6HPwZCDfra7xL90=",
      "url": "lib/bootstrap-icons/icons/chat-square-dots.svg"
    },
    {
      "hash": "sha256-NWRPnt4IQvE8qUyY1qqRZZoZk90PiKH2HG266oPyucc=",
      "url": "lib/bootstrap-icons/icons/chat-square-fill.svg"
    },
    {
      "hash": "sha256-GtORkYOtM4wFcIPM89n8mu4Y5azopNmCjiNbB1xJ4q8=",
      "url": "lib/bootstrap-icons/icons/chat-square-heart-fill.svg"
    },
    {
      "hash": "sha256-bE37F3Wk3nsrElGqmhwc2LaQb3tuBVNayt4E67RfHxM=",
      "url": "lib/bootstrap-icons/icons/chat-square-heart.svg"
    },
    {
      "hash": "sha256-3PeAl0rdeV2PJygfdpeLanI7InK/pktWYcyiZh43wDo=",
      "url": "lib/bootstrap-icons/icons/chat-square-quote-fill.svg"
    },
    {
      "hash": "sha256-hI4oGENaCjWdjyAzrHXI/7utd8eXwvGDijwsehm4JNg=",
      "url": "lib/bootstrap-icons/icons/chat-square-quote.svg"
    },
    {
      "hash": "sha256-ExtpDaA2GcuRUnQ7dZKGlaEmtmbolWoxyl/x7PHk/xs=",
      "url": "lib/bootstrap-icons/icons/chat-square-text-fill.svg"
    },
    {
      "hash": "sha256-jApBAAB6w5hog0Ufi5NZa8jgl06xDl6UNK0rhfELLHI=",
      "url": "lib/bootstrap-icons/icons/chat-square-text.svg"
    },
    {
      "hash": "sha256-qZVx9ig+F18ednREBOPDG6JorKtGxCCSlhv0eacrhYI=",
      "url": "lib/bootstrap-icons/icons/chat-square.svg"
    },
    {
      "hash": "sha256-vHwUSznesWAiBhqCjar68309b5nberD02XZI/+j8uSg=",
      "url": "lib/bootstrap-icons/icons/chat-text-fill.svg"
    },
    {
      "hash": "sha256-2O33OnIiLM7Z81D3pdAvD3CmChBwP3Hi/ECPYp7BAUo=",
      "url": "lib/bootstrap-icons/icons/chat-text.svg"
    },
    {
      "hash": "sha256-XxyJJeGSRJyiW0bzNXOBcGuhyJMLzUWU31kqtBV8R54=",
      "url": "lib/bootstrap-icons/icons/chat.svg"
    },
    {
      "hash": "sha256-XOpZJgaX3y1nEZ1xpvMyKbwtxLjrwgx0AMdsUypFGPE=",
      "url": "lib/bootstrap-icons/icons/check-all.svg"
    },
    {
      "hash": "sha256-y0M5jGa41wAXekGJx+TjYdI7oWVHgkE6rnY5ftg4CDs=",
      "url": "lib/bootstrap-icons/icons/check-circle-fill.svg"
    },
    {
      "hash": "sha256-cUQFSzBFp1cT74aK68h0wP+slJO4VD8N+kxBeH6WeZI=",
      "url": "lib/bootstrap-icons/icons/check-circle.svg"
    },
    {
      "hash": "sha256-6pcz/yQk+WrnjS53fm7QgDGFE7RE4s7MZFh6wvLZNFk=",
      "url": "lib/bootstrap-icons/icons/check-lg.svg"
    },
    {
      "hash": "sha256-MqFWjIpa+ffMkMiqORk+D+DSD/N8fLxlvtH6j8M61lE=",
      "url": "lib/bootstrap-icons/icons/check-square-fill.svg"
    },
    {
      "hash": "sha256-D4VdezdP6RCoHawiEf7Ylpl1kF7wGUQssuYGUh8l5iw=",
      "url": "lib/bootstrap-icons/icons/check-square.svg"
    },
    {
      "hash": "sha256-eO5LxuyZrJu2wsoXKV0k+QyNVZIvASMd42/6grIqBGY=",
      "url": "lib/bootstrap-icons/icons/check.svg"
    },
    {
      "hash": "sha256-kS99+v6FLlbCmg7G88xshwVG8kYr3lm0ARI8RZZrYwA=",
      "url": "lib/bootstrap-icons/icons/check2-all.svg"
    },
    {
      "hash": "sha256-yhcKJJEUna55Z0USYQJ0clRwGQYyku4Yy9zfxHJIseQ=",
      "url": "lib/bootstrap-icons/icons/check2-circle.svg"
    },
    {
      "hash": "sha256-063W8akpjGzXrJCkX9lahbqPARqPdHZupKEdaY5LIQI=",
      "url": "lib/bootstrap-icons/icons/check2-square.svg"
    },
    {
      "hash": "sha256-ziM8SdG4JO9Qb8IdgnsJKB/aVIuedzqpmDbTN0nogtc=",
      "url": "lib/bootstrap-icons/icons/check2.svg"
    },
    {
      "hash": "sha256-bBUesnAPjNq/a+AbZrPbQ/tA+r4BN+Gay3PNjHcRxXM=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-contract.svg"
    },
    {
      "hash": "sha256-KPbg9EkEx3isVOHFdeJQPSDQi9AGQEqmYx4ZDBaAthw=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-down.svg"
    },
    {
      "hash": "sha256-8lW7jmUoBGfokKyZazsS9xOefxl6NnXvVgbDgMIVoA4=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-expand.svg"
    },
    {
      "hash": "sha256-ABzvGDBEcplDogbTacNdbZ9J1jBeT4jOcZlAqhiOC0k=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-left.svg"
    },
    {
      "hash": "sha256-RNPYdEQ4dwLtbb9y7Ai2FDk+Cp6pxhSg4EVq9B/Ts90=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-right.svg"
    },
    {
      "hash": "sha256-65fOBVFUkSnLbjkqc1lEYJwZiIDF6YOae0zoaT0jTDg=",
      "url": "lib/bootstrap-icons/icons/chevron-bar-up.svg"
    },
    {
      "hash": "sha256-GWxeR9m5iOBfMm1gAL3Sr0C2xmAZPCmFyMGAPnnCHoA=",
      "url": "lib/bootstrap-icons/icons/chevron-compact-down.svg"
    },
    {
      "hash": "sha256-o7+vSHEjHd0IAsb2rf8l5V8kLKxfri/0xzKnWzoxyq4=",
      "url": "lib/bootstrap-icons/icons/chevron-compact-left.svg"
    },
    {
      "hash": "sha256-vs65m9Co86n6+BMlHgIJIUoj4c8scX1A2PznW4fN7mA=",
      "url": "lib/bootstrap-icons/icons/chevron-compact-right.svg"
    },
    {
      "hash": "sha256-wbh2Hiqg1NAaohvslAvpzuUEPlL/mRC7hMBBF1URRS4=",
      "url": "lib/bootstrap-icons/icons/chevron-compact-up.svg"
    },
    {
      "hash": "sha256-H0TkYdLWQw8eOyBT52kkTgvUmmpNDnxiWeRXQWAgQkQ=",
      "url": "lib/bootstrap-icons/icons/chevron-contract.svg"
    },
    {
      "hash": "sha256-LBtoF3q/ED5HEWkvqd+xk411QmWH41lQVT6a9VtqEuo=",
      "url": "lib/bootstrap-icons/icons/chevron-double-down.svg"
    },
    {
      "hash": "sha256-v72O1DCFgtjNPNvxVltedckuHWf01gW/D6I9ahgEQbI=",
      "url": "lib/bootstrap-icons/icons/chevron-double-left.svg"
    },
    {
      "hash": "sha256-vHlYE8jXtld/3/fTIoGdW53mq/MtzdWJqsRxnWJe1bs=",
      "url": "lib/bootstrap-icons/icons/chevron-double-right.svg"
    },
    {
      "hash": "sha256-Fdp73oUJ1v2QZUOC5pDlWdiyzuYlGW6vZNN//wPTBFk=",
      "url": "lib/bootstrap-icons/icons/chevron-double-up.svg"
    },
    {
      "hash": "sha256-iT4rdnU98oRN8o+IwQcIu6io7WpiveszDqt+U6rzIls=",
      "url": "lib/bootstrap-icons/icons/chevron-down.svg"
    },
    {
      "hash": "sha256-ygDYxYqMTHdQruo9pR0NAjaNVPi7yq91gPpBi28QIUA=",
      "url": "lib/bootstrap-icons/icons/chevron-expand.svg"
    },
    {
      "hash": "sha256-GpD15D0pTYtsanyuUBhDADtzMX7sF+Nd6L5exi4hIjY=",
      "url": "lib/bootstrap-icons/icons/chevron-left.svg"
    },
    {
      "hash": "sha256-QJMNPBz51574wjoT0XqoPgXpkNj+N/hO8PsjEOZ0nXk=",
      "url": "lib/bootstrap-icons/icons/chevron-right.svg"
    },
    {
      "hash": "sha256-CPSysNwyJJc0LlvFh2MvxrPpjRWGQU4usfxPdlrAYqk=",
      "url": "lib/bootstrap-icons/icons/chevron-up.svg"
    },
    {
      "hash": "sha256-haFgRIm9N4c16HdxhLC7D3CV3C4L7aEeWQOli5v+9uo=",
      "url": "lib/bootstrap-icons/icons/circle-fill.svg"
    },
    {
      "hash": "sha256-zWrfXz2c2BVHQM62rtnA2lFbQTmgKt4EaHPWKOALl9M=",
      "url": "lib/bootstrap-icons/icons/circle-half.svg"
    },
    {
      "hash": "sha256-Qjq9lceNyMljTi7m/3hx2LEeeAUKZRQraPWas8UvQdY=",
      "url": "lib/bootstrap-icons/icons/circle-square.svg"
    },
    {
      "hash": "sha256-G8rNO+IX0QaAHAv/6egdwrupItqXY9lR+OYwFjlHqcA=",
      "url": "lib/bootstrap-icons/icons/circle.svg"
    },
    {
      "hash": "sha256-62W99teBIvLCzhR/wZ3G81Kdr2PGKTlfhYb7GJ1xolg=",
      "url": "lib/bootstrap-icons/icons/clipboard-check-fill.svg"
    },
    {
      "hash": "sha256-fwJ2UC+jBwumBBmD+YlfiQukwEyatirtB0MjZ0hXrHI=",
      "url": "lib/bootstrap-icons/icons/clipboard-check.svg"
    },
    {
      "hash": "sha256-yvSWXPr9IazW/958DPO4YUH5Ibv/TqRkCvxHH95PZHM=",
      "url": "lib/bootstrap-icons/icons/clipboard-data-fill.svg"
    },
    {
      "hash": "sha256-WuRulEhCEpUmjpiIF2NqbzOikSmI5SUKm2xL4Y9/suc=",
      "url": "lib/bootstrap-icons/icons/clipboard-data.svg"
    },
    {
      "hash": "sha256-iBUpAH1SoMIORNSKuhJWYVfsgFpYrBeNgkDSZkYvOa4=",
      "url": "lib/bootstrap-icons/icons/clipboard-fill.svg"
    },
    {
      "hash": "sha256-+HK27FGkurxkktWr3Mk4vsCUlIDTBFi6POuioj26wgY=",
      "url": "lib/bootstrap-icons/icons/clipboard-heart-fill.svg"
    },
    {
      "hash": "sha256-48NbHx6pN4Cca4Y47AHLyvD6stexnah8aC977z5Q0AI=",
      "url": "lib/bootstrap-icons/icons/clipboard-heart.svg"
    },
    {
      "hash": "sha256-UOaJGhothRmbggUK2DohPJeK6B646xjbtbiLPPP4UCA=",
      "url": "lib/bootstrap-icons/icons/clipboard-minus-fill.svg"
    },
    {
      "hash": "sha256-+/Z2dr29drKCh+YuAxoIJ9I4Gv2sQY+GPUQdG6pOk+A=",
      "url": "lib/bootstrap-icons/icons/clipboard-minus.svg"
    },
    {
      "hash": "sha256-Dd17DM96S34Y0xXpbmusgRT7WQ0P2jCCXfGFSZZxi+k=",
      "url": "lib/bootstrap-icons/icons/clipboard-plus-fill.svg"
    },
    {
      "hash": "sha256-qi3cp+xviic8DnZj0N7bBaIVaQA0btDserrzJWko1s8=",
      "url": "lib/bootstrap-icons/icons/clipboard-plus.svg"
    },
    {
      "hash": "sha256-J3uI88ZIeSpvUU46l8hvMuMefY/3ye6pOiwx/oFQenM=",
      "url": "lib/bootstrap-icons/icons/clipboard-pulse.svg"
    },
    {
      "hash": "sha256-rOz2TTY0k04Gc4Eu9/RaD9aIGANZA0Mxu+QuvPGCf+4=",
      "url": "lib/bootstrap-icons/icons/clipboard-x-fill.svg"
    },
    {
      "hash": "sha256-hNmZwP5lWxt88WNe+LeWeQyFdaBeVJeaGg+m7xHha4M=",
      "url": "lib/bootstrap-icons/icons/clipboard-x.svg"
    },
    {
      "hash": "sha256-XR+fyRymrcSKL6njLh9gJTuiqJv1S+obuBhTyW0kctM=",
      "url": "lib/bootstrap-icons/icons/clipboard.svg"
    },
    {
      "hash": "sha256-5JzQKiN4rTLSLw8Yql7ogEwRVjREkcU59vbIIBUaAk8=",
      "url": "lib/bootstrap-icons/icons/clipboard2-check-fill.svg"
    },
    {
      "hash": "sha256-QHZPn5ehQAkmAHZ67zQzpwKdNRPWVFX2DxaDCkRnU5M=",
      "url": "lib/bootstrap-icons/icons/clipboard2-check.svg"
    },
    {
      "hash": "sha256-6H08mpGW46sD1aDIS2Sea/Rl9WY6U+THDe538/mmDvc=",
      "url": "lib/bootstrap-icons/icons/clipboard2-data-fill.svg"
    },
    {
      "hash": "sha256-sefRG3IJDcqW1GbFx4ei4A6GuvKmfuCkqGNUUVLnhBI=",
      "url": "lib/bootstrap-icons/icons/clipboard2-data.svg"
    },
    {
      "hash": "sha256-pTL6TsILrIqPnj6aOZqDYCfKOkUROhJCWo+ojwQn3ds=",
      "url": "lib/bootstrap-icons/icons/clipboard2-fill.svg"
    },
    {
      "hash": "sha256-aAlAj48g7r6zw0vZo16FRu7PVJY53+lsbkUqI+GUXVU=",
      "url": "lib/bootstrap-icons/icons/clipboard2-heart-fill.svg"
    },
    {
      "hash": "sha256-YBzyAxAj5AToZEFH/ycc51ggDYapaxRtzT1zjATpUvU=",
      "url": "lib/bootstrap-icons/icons/clipboard2-heart.svg"
    },
    {
      "hash": "sha256-V05eWwMDNQvkJZ4oq/L+HnBPSQJTLBxhKPFAp4eFuAE=",
      "url": "lib/bootstrap-icons/icons/clipboard2-minus-fill.svg"
    },
    {
      "hash": "sha256-ofhrpLNGSftDNmR6+lShV+gfTJGf5eEGmINkjNiQfro=",
      "url": "lib/bootstrap-icons/icons/clipboard2-minus.svg"
    },
    {
      "hash": "sha256-yJ75DOVSZlC5ax68SfrKvmB0BTXWy7lQXpDSlz2Ehe0=",
      "url": "lib/bootstrap-icons/icons/clipboard2-plus-fill.svg"
    },
    {
      "hash": "sha256-mQmi7bQd0NrPRWfEQUtFgargEbvjdzUlOin3yvXK6F0=",
      "url": "lib/bootstrap-icons/icons/clipboard2-plus.svg"
    },
    {
      "hash": "sha256-c4fNzkXRwmsfTdSqvC7h5eiYVfehoZFaXqxsjd8Mylo=",
      "url": "lib/bootstrap-icons/icons/clipboard2-pulse-fill.svg"
    },
    {
      "hash": "sha256-HNSRweI1SynOfWffWDdr8RFQm9wlhOm4ykkSPRkaYQY=",
      "url": "lib/bootstrap-icons/icons/clipboard2-pulse.svg"
    },
    {
      "hash": "sha256-S55rE1tT6x18Ft8XH7ZJB3XNQef1kTT7bYSin3wm6a4=",
      "url": "lib/bootstrap-icons/icons/clipboard2-x-fill.svg"
    },
    {
      "hash": "sha256-dTbBZiyjB0Cw2vvEhAefRBS1mmVj8vf6fHhap5TK19Q=",
      "url": "lib/bootstrap-icons/icons/clipboard2-x.svg"
    },
    {
      "hash": "sha256-USXtD2YdO+pzWZKXLn7uHPzXkOkBLR1ds3Yv3CgCI/A=",
      "url": "lib/bootstrap-icons/icons/clipboard2.svg"
    },
    {
      "hash": "sha256-RZIlhA4RP5W4QnwH8K+Dg6CNlB7XFEBiiX8+F1m+ZdQ=",
      "url": "lib/bootstrap-icons/icons/clock-fill.svg"
    },
    {
      "hash": "sha256-+qUQ1qzCVs4zKS4U+1WKUbfwPlM7zZHDdnVkejsF+c4=",
      "url": "lib/bootstrap-icons/icons/clock-history.svg"
    },
    {
      "hash": "sha256-lFdBkyDfoyNYRP9sEF/pO75OamT3TvrkDRtnc09AFMQ=",
      "url": "lib/bootstrap-icons/icons/clock.svg"
    },
    {
      "hash": "sha256-Vzml0nP9idCJ9PeCu4JQb2VNX0hMZElSl/YHPYg5csM=",
      "url": "lib/bootstrap-icons/icons/cloud-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-GHkZEgUuQEWOJdNtu4d+V6NevWKOWneg5Lxyo3okpIU=",
      "url": "lib/bootstrap-icons/icons/cloud-arrow-down.svg"
    },
    {
      "hash": "sha256-WgO1KVrTVcjCsmYbIfHnHW8u0sfASIbizdOBhnxtPlw=",
      "url": "lib/bootstrap-icons/icons/cloud-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-LGrEeuKn4DPL8m5pi9d7LLG6vYfgmXCTtiU0rz27JRs=",
      "url": "lib/bootstrap-icons/icons/cloud-arrow-up.svg"
    },
    {
      "hash": "sha256-zVfcoUTOM+B54vfy+G4JOG3EEz5rLpsbQX+jZsIRQxk=",
      "url": "lib/bootstrap-icons/icons/cloud-check-fill.svg"
    },
    {
      "hash": "sha256-/Ga5O3MSeuD4TfQunUg06GYJRWtVqTv5G85kJGyWnTk=",
      "url": "lib/bootstrap-icons/icons/cloud-check.svg"
    },
    {
      "hash": "sha256-QR8B5et1RNfaZ9+BWY/mxVusr0106T0zZCYg8n9/SUY=",
      "url": "lib/bootstrap-icons/icons/cloud-download-fill.svg"
    },
    {
      "hash": "sha256-fIknxYz6LOX9Db/o0hcGS9z8rCuXZ6GJdFWgH1VMIiM=",
      "url": "lib/bootstrap-icons/icons/cloud-download.svg"
    },
    {
      "hash": "sha256-oMkZ3NLuhhFM1MT1f6cY5mhGKo7/O4ZHcm5lma7O5SE=",
      "url": "lib/bootstrap-icons/icons/cloud-drizzle-fill.svg"
    },
    {
      "hash": "sha256-VYnuJl6xU4PXB2fWoIq5vDQEPqKPvAeuvwLCCqkSOBo=",
      "url": "lib/bootstrap-icons/icons/cloud-drizzle.svg"
    },
    {
      "hash": "sha256-pMWwAczYVlml7m0Ei2csLyvjPt0C+ACulzWNai6aYKs=",
      "url": "lib/bootstrap-icons/icons/cloud-fill.svg"
    },
    {
      "hash": "sha256-RtngvQ2EKXma4UnbegVQqfTryl50jxC+5JpDhwgL8Co=",
      "url": "lib/bootstrap-icons/icons/cloud-fog-fill.svg"
    },
    {
      "hash": "sha256-qsivQia7DBcWrqU5VsbFlE/FCUiMumccWamwmmLHZZ4=",
      "url": "lib/bootstrap-icons/icons/cloud-fog.svg"
    },
    {
      "hash": "sha256-yW99LlvGFueKKytrVGTj+NlNYX1OFWyr6m3Z/PwWC0Q=",
      "url": "lib/bootstrap-icons/icons/cloud-fog2-fill.svg"
    },
    {
      "hash": "sha256-W8GOVFx518Pygi0vOB1i/I4GM/HeB+M5267Bg5RvjUE=",
      "url": "lib/bootstrap-icons/icons/cloud-fog2.svg"
    },
    {
      "hash": "sha256-XLOZLhLhf19dG058YIf4obco8yG9Ym98bXPfJri5i30=",
      "url": "lib/bootstrap-icons/icons/cloud-hail-fill.svg"
    },
    {
      "hash": "sha256-IPo54HXHaOaNtBucJlAhSJKmBk6KegWXfmsEOmSOc7w=",
      "url": "lib/bootstrap-icons/icons/cloud-hail.svg"
    },
    {
      "hash": "sha256-7P2eGE2K7fK0VuCcg/0xub/G6M9JyHQ3EqO/4ruVtzI=",
      "url": "lib/bootstrap-icons/icons/cloud-haze-fill.svg"
    },
    {
      "hash": "sha256-a5ES9XKXlGnZVi5pRdf+v3M4KGZNhRfeQpZiJgQeraU=",
      "url": "lib/bootstrap-icons/icons/cloud-haze.svg"
    },
    {
      "hash": "sha256-d00K2WyPoZ2hig7AK1t4+uBtH0Ywl0n8QEnWTb8zZmk=",
      "url": "lib/bootstrap-icons/icons/cloud-haze2-fill.svg"
    },
    {
      "hash": "sha256-CimnQ0cqVgP3cEBtRmRFbjylKYsNVSAKbnLsXfSa2iI=",
      "url": "lib/bootstrap-icons/icons/cloud-haze2.svg"
    },
    {
      "hash": "sha256-8tS7GBDx3xjoU+nmbetvrPJMghiaFSs4q9GHXBppoPI=",
      "url": "lib/bootstrap-icons/icons/cloud-lightning-fill.svg"
    },
    {
      "hash": "sha256-GqiBWCCBhltluDuNX3DyqYHdJjTo/gkpNyE7N1pXtEA=",
      "url": "lib/bootstrap-icons/icons/cloud-lightning-rain-fill.svg"
    },
    {
      "hash": "sha256-w9Q+rNViy0QiGSvwIDvCj2Jxg7yVxHqwxcczI1lw5C0=",
      "url": "lib/bootstrap-icons/icons/cloud-lightning-rain.svg"
    },
    {
      "hash": "sha256-yV2OjIsSijrurrfaRGyCud9Tcg9jaPJdqVNN0fcMCxU=",
      "url": "lib/bootstrap-icons/icons/cloud-lightning.svg"
    },
    {
      "hash": "sha256-Be35d01mAXp88RQ5jnaIuItQZn1DSIUVUf4Sm42ITiY=",
      "url": "lib/bootstrap-icons/icons/cloud-minus-fill.svg"
    },
    {
      "hash": "sha256-ZJ7Ew2k8kgpSwtS+RpchVggNJ+UkM2XIDaw1npOiZ3s=",
      "url": "lib/bootstrap-icons/icons/cloud-minus.svg"
    },
    {
      "hash": "sha256-BziuFv5kRF2r8Fh5SGAgUWVV9xGvd6gv20XhsKoil3A=",
      "url": "lib/bootstrap-icons/icons/cloud-moon-fill.svg"
    },
    {
      "hash": "sha256-iwAd/5IWBXt1Jb+y1GkZV58iEOUaSRU91tnuKd46QjY=",
      "url": "lib/bootstrap-icons/icons/cloud-moon.svg"
    },
    {
      "hash": "sha256-UmWhob1fSKQmujhX86ZvtTyQEOBdYBJ3BlLC+Spl4mI=",
      "url": "lib/bootstrap-icons/icons/cloud-plus-fill.svg"
    },
    {
      "hash": "sha256-Tc3aS9mI0ajm3DA0bsmGpug6VLYiEQO6iM9F0EHkk6M=",
      "url": "lib/bootstrap-icons/icons/cloud-plus.svg"
    },
    {
      "hash": "sha256-JuYYlYNm6ZcHWhhPSv19pgBPFAtwrVTiETgTlYAJQ0I=",
      "url": "lib/bootstrap-icons/icons/cloud-rain-fill.svg"
    },
    {
      "hash": "sha256-CGk3Gdbi9goG8YVJUdiL5KaxEO5R/3ahVKo5qMKXTCk=",
      "url": "lib/bootstrap-icons/icons/cloud-rain-heavy-fill.svg"
    },
    {
      "hash": "sha256-suTeP41nPAlajuFJAzmM64TNInJ6visVDzO6BVw2qU0=",
      "url": "lib/bootstrap-icons/icons/cloud-rain-heavy.svg"
    },
    {
      "hash": "sha256-xxf5MT7b/kKpAz/IcP2M5kMwCv8+C37+RXkh4sTAnVg=",
      "url": "lib/bootstrap-icons/icons/cloud-rain.svg"
    },
    {
      "hash": "sha256-SOtkeaADAwON92bTtiODh+4zFwGMI/j8TgtYNCvpmVI=",
      "url": "lib/bootstrap-icons/icons/cloud-slash-fill.svg"
    },
    {
      "hash": "sha256-7fOSev0rEyrlmRq9FlmE4m9Ogsac0jnsNgZtCD85JdI=",
      "url": "lib/bootstrap-icons/icons/cloud-slash.svg"
    },
    {
      "hash": "sha256-5RVmjBi+pz98bl79N2L+8bzkBAbPgo5b6o7vBnY4dQ0=",
      "url": "lib/bootstrap-icons/icons/cloud-sleet-fill.svg"
    },
    {
      "hash": "sha256-ymjnL8r2Z2HC4eJOp/3AYdDf6QA+FRIG9YY6oUIUkPM=",
      "url": "lib/bootstrap-icons/icons/cloud-sleet.svg"
    },
    {
      "hash": "sha256-CdBiIc2G4jXHvtp+1fMOztQDFiWV3pfKuUdQauUk4i0=",
      "url": "lib/bootstrap-icons/icons/cloud-snow-fill.svg"
    },
    {
      "hash": "sha256-mHd78Tf9pm2FwJDtjD0hNBsacvafkVHsMFTbVo1AI/o=",
      "url": "lib/bootstrap-icons/icons/cloud-snow.svg"
    },
    {
      "hash": "sha256-8F77vgAS+7t+0CpVFxT6BPOxkZnRBlL219Di6Vgxe74=",
      "url": "lib/bootstrap-icons/icons/cloud-sun-fill.svg"
    },
    {
      "hash": "sha256-GRkGS0jvFthAqJdqBS64iHHYPHpv2gVb5/D0nvGhLSw=",
      "url": "lib/bootstrap-icons/icons/cloud-sun.svg"
    },
    {
      "hash": "sha256-U9syhDRIEab6685hOlTRyD7YJBo80SVNZpGev36o+f0=",
      "url": "lib/bootstrap-icons/icons/cloud-upload-fill.svg"
    },
    {
      "hash": "sha256-se9Kg6hkjvzBGRKwRDh9izrK1sH2jEKNUS5VlA9aA1M=",
      "url": "lib/bootstrap-icons/icons/cloud-upload.svg"
    },
    {
      "hash": "sha256-UHd2Dj8PxC6pmVeZalYXovN2yGB/mBMOiti1rTf26UE=",
      "url": "lib/bootstrap-icons/icons/cloud.svg"
    },
    {
      "hash": "sha256-/Wx7rLI65RMPMCQj09Q3rUz3K0IuXhQOBnKY25R0drE=",
      "url": "lib/bootstrap-icons/icons/clouds-fill.svg"
    },
    {
      "hash": "sha256-BQ8RsQxHG6ber8jCgd/gzvhBeUjM2sOKUYG/4Q/z0ao=",
      "url": "lib/bootstrap-icons/icons/clouds.svg"
    },
    {
      "hash": "sha256-GycqPCgcU1KV1MoCFAFRCtl3WDOrRnLPV0nrOSxepM4=",
      "url": "lib/bootstrap-icons/icons/cloudy-fill.svg"
    },
    {
      "hash": "sha256-gaMDXzy/5BHcb8fRiMf3zuhGTl1wf+SSydPYqebZfGc=",
      "url": "lib/bootstrap-icons/icons/cloudy.svg"
    },
    {
      "hash": "sha256-400+Z38rHEO8pddtHy4Q4S75hM11E0cMaFA4zMNf+jg=",
      "url": "lib/bootstrap-icons/icons/code-slash.svg"
    },
    {
      "hash": "sha256-yZx4e5oNi9/QpYvi1BBwcIjz6fx6MIP2uZItqduQZcY=",
      "url": "lib/bootstrap-icons/icons/code-square.svg"
    },
    {
      "hash": "sha256-tdK1Up3PeIZ7MEIhM68AejEujQNhPOptCJQfp2FBvjg=",
      "url": "lib/bootstrap-icons/icons/code.svg"
    },
    {
      "hash": "sha256-dUvHRv8bh5W8/sg0zJt7oyLMTG8CvqWzEMj5Wh6iHXw=",
      "url": "lib/bootstrap-icons/icons/coin.svg"
    },
    {
      "hash": "sha256-0VBrQKYjiamqOPeitclfzQaP0apIwF9Ga8XU2qZoHEw=",
      "url": "lib/bootstrap-icons/icons/collection-fill.svg"
    },
    {
      "hash": "sha256-HqoQ8AaH6hANtmtZ6rCP9pHwpjbJPYc4IKiwTDp1p8g=",
      "url": "lib/bootstrap-icons/icons/collection-play-fill.svg"
    },
    {
      "hash": "sha256-jO7UasrUpo5EZRmWZY4A5cvAeopwYvaUZJxpNALdKw8=",
      "url": "lib/bootstrap-icons/icons/collection-play.svg"
    },
    {
      "hash": "sha256-lLVcq346J87CqFWq8JkGJ1vtu/PyHexusyi+50pzXSw=",
      "url": "lib/bootstrap-icons/icons/collection.svg"
    },
    {
      "hash": "sha256-ILFOjSPlcjwV/HFOKO1kYo3CZI8INV0kkk1+53OvUMM=",
      "url": "lib/bootstrap-icons/icons/columns-gap.svg"
    },
    {
      "hash": "sha256-6gA0mN6dSMvKNBSCHBXbAN4+yIj9XWsnmo8V0ENKOoU=",
      "url": "lib/bootstrap-icons/icons/columns.svg"
    },
    {
      "hash": "sha256-AfJmko5U5TW5eZUiuyZHYcaqg1Itu/U8LeuWe7MlsjA=",
      "url": "lib/bootstrap-icons/icons/command.svg"
    },
    {
      "hash": "sha256-ilR6+yS1ElrImwEnPQ26gp8QsFhHWLcPMfpabGfde3w=",
      "url": "lib/bootstrap-icons/icons/compass-fill.svg"
    },
    {
      "hash": "sha256-yFzBAZq+a8HRvDr7mvRijIoNoJeg30EPxMjtzAxziU8=",
      "url": "lib/bootstrap-icons/icons/compass.svg"
    },
    {
      "hash": "sha256-5hyjcG+SmaK+C7h/KBZE1NSqjKOelKYVorxtOBmOYZo=",
      "url": "lib/bootstrap-icons/icons/cone-striped.svg"
    },
    {
      "hash": "sha256-gyrvbNKSQWlZ6XhXDT0Oj7pUbwbvX1Qtuqg1xZZLgIE=",
      "url": "lib/bootstrap-icons/icons/cone.svg"
    },
    {
      "hash": "sha256-js4H+/W15rJ7/cm+EpuDDPJWg3B1BL5tHooxozTTEDQ=",
      "url": "lib/bootstrap-icons/icons/controller.svg"
    },
    {
      "hash": "sha256-gzQjKghAXHLCmTUhrWfwdhE1qU24RmadxKKk/ISxi/E=",
      "url": "lib/bootstrap-icons/icons/cookie.svg"
    },
    {
      "hash": "sha256-fAfhlZs0ZVqUyr4da+H7qFajpuAGCW981ZNddOvFQQ0=",
      "url": "lib/bootstrap-icons/icons/copy.svg"
    },
    {
      "hash": "sha256-C2p0nlwK+uYy74TEh10+FQFc58GW15q8EAtvMHvE4Aw=",
      "url": "lib/bootstrap-icons/icons/cpu-fill.svg"
    },
    {
      "hash": "sha256-0WlOpF+qq34o1UFy9NmzMCA73ifBeG3VF1BBfVjcrjc=",
      "url": "lib/bootstrap-icons/icons/cpu.svg"
    },
    {
      "hash": "sha256-2+w8XTFy/Zg0nBRPEEJaCzgjTmbq9pkJIgCCAw3OjFQ=",
      "url": "lib/bootstrap-icons/icons/credit-card-2-back-fill.svg"
    },
    {
      "hash": "sha256-quo8FrWlzQ1DoMNmNg7G7F8UUqU2BSwQJM4xDiGuyNo=",
      "url": "lib/bootstrap-icons/icons/credit-card-2-back.svg"
    },
    {
      "hash": "sha256-JI0+001CJdexqGJk/t80bwbRRbSOt0tytTZWB8dqoQ8=",
      "url": "lib/bootstrap-icons/icons/credit-card-2-front-fill.svg"
    },
    {
      "hash": "sha256-dzCgJQLmKW7NVD0C+r3hC9WusPTSsH6N/zPysSZoFO4=",
      "url": "lib/bootstrap-icons/icons/credit-card-2-front.svg"
    },
    {
      "hash": "sha256-tld0bVThPieytfq8ieG6NoDzMX1Wf3k8eyuXjsglqDo=",
      "url": "lib/bootstrap-icons/icons/credit-card-fill.svg"
    },
    {
      "hash": "sha256-I50MSBbO//+HfTaXTdoeweFPLzJGIKRdrMkJZuk3IR8=",
      "url": "lib/bootstrap-icons/icons/credit-card.svg"
    },
    {
      "hash": "sha256-YU3gJMCGJK5nHm2u32jRlqMdMkO0RnuyLkSVoNXu60k=",
      "url": "lib/bootstrap-icons/icons/crop.svg"
    },
    {
      "hash": "sha256-tbWbzGC1nsdHJ3vi7U8vBa8gQ03MewKzp2PB9an3kCM=",
      "url": "lib/bootstrap-icons/icons/crosshair.svg"
    },
    {
      "hash": "sha256-7BZh7pNQHUz67G9aBsICsDuv+09uCllk+fe2BaZzZ50=",
      "url": "lib/bootstrap-icons/icons/crosshair2.svg"
    },
    {
      "hash": "sha256-g139LrRfmw+J4S6TiTWORJSiNTLc/E2AF2Y0G2OoVa0=",
      "url": "lib/bootstrap-icons/icons/cup-fill.svg"
    },
    {
      "hash": "sha256-U5WBlzsZt1XfdL5kZQPaQPrk1Gzd1VvzhjEPQQZP7K4=",
      "url": "lib/bootstrap-icons/icons/cup-hot-fill.svg"
    },
    {
      "hash": "sha256-7y+VpppP25ERMnirOAItTSerzwsPXM8UV5S0pmcM8Hg=",
      "url": "lib/bootstrap-icons/icons/cup-hot.svg"
    },
    {
      "hash": "sha256-5xT8m8tCAwuiLj+N8t1RCFL3LOqs2jphMoYyzFHKv2I=",
      "url": "lib/bootstrap-icons/icons/cup-straw.svg"
    },
    {
      "hash": "sha256-DMjNZbfKCjX0J5dMURnC/VUnKjFgPjOaHcGa+8V4t3c=",
      "url": "lib/bootstrap-icons/icons/cup.svg"
    },
    {
      "hash": "sha256-we3x8ETs0C6iVOmsHpbZUw63qmjExpuxC1yVrBOtrBg=",
      "url": "lib/bootstrap-icons/icons/currency-bitcoin.svg"
    },
    {
      "hash": "sha256-OB9Ol8dB0q6x3DMwUkhQi+IYXM2iOYNV2U8z0MjatQ4=",
      "url": "lib/bootstrap-icons/icons/currency-dollar.svg"
    },
    {
      "hash": "sha256-2wZvHsiia6CBq7Z39Ixp39nZQhPEDkx4SKVURoG0DbQ=",
      "url": "lib/bootstrap-icons/icons/currency-euro.svg"
    },
    {
      "hash": "sha256-uLj9HAtLT6dgiwLZrQAYXeZzDXvcqg3NS+q+OfBzWWM=",
      "url": "lib/bootstrap-icons/icons/currency-exchange.svg"
    },
    {
      "hash": "sha256-Yk9f1i5uEQkoYxd7dNXEdJSJW5QiLUGRToGk4mE+jl8=",
      "url": "lib/bootstrap-icons/icons/currency-pound.svg"
    },
    {
      "hash": "sha256-GV95nX8HUSWn4WNdrwWfq+BxwCq86zSY/0RQPltpJFg=",
      "url": "lib/bootstrap-icons/icons/currency-rupee.svg"
    },
    {
      "hash": "sha256-E4CXFA2hrH5wbavW+LdRCnEl33gLDs2isWWCEi0fGyw=",
      "url": "lib/bootstrap-icons/icons/currency-yen.svg"
    },
    {
      "hash": "sha256-1wOoCb0JApNRWVt2PjYQyrLvuRHbJinikz0/6RW8mQI=",
      "url": "lib/bootstrap-icons/icons/cursor-fill.svg"
    },
    {
      "hash": "sha256-n5X8l5glFZEClknKjFzJWUGY2JPWDD40OKpIfrSikBA=",
      "url": "lib/bootstrap-icons/icons/cursor-text.svg"
    },
    {
      "hash": "sha256-YVQwOuG1U4G/oolhY2GF6TlwWHHr4XG0WL2SwW+OOeg=",
      "url": "lib/bootstrap-icons/icons/cursor.svg"
    },
    {
      "hash": "sha256-AYwkYmh9d2DAS9mo0cOKzwz02wFdwZwow2+LTi3vbvo=",
      "url": "lib/bootstrap-icons/icons/dash-circle-dotted.svg"
    },
    {
      "hash": "sha256-05dsUzfhv4pPvw162vp9WxbzkXanhyNHfVCYVTdg9zs=",
      "url": "lib/bootstrap-icons/icons/dash-circle-fill.svg"
    },
    {
      "hash": "sha256-Fbh/DDc1U5k7kEW99nINKPW0/1vSUyI5wcpX06+TpDg=",
      "url": "lib/bootstrap-icons/icons/dash-circle.svg"
    },
    {
      "hash": "sha256-o6DA/y1DRQUs4PaHYu+buLQpZSvaLO1lrW6QgsTXF/Y=",
      "url": "lib/bootstrap-icons/icons/dash-lg.svg"
    },
    {
      "hash": "sha256-OwBc+IfcqGlzo5ldhqHG48MXgJH1t7JotiXnjyQWzjE=",
      "url": "lib/bootstrap-icons/icons/dash-square-dotted.svg"
    },
    {
      "hash": "sha256-+GsHh2WH+mScmQ/AG3w+81vcajrg7To8Go176rzCdPU=",
      "url": "lib/bootstrap-icons/icons/dash-square-fill.svg"
    },
    {
      "hash": "sha256-+fs//qZQA5Kuzyc5B1fK3azxtNNidinyOOo6Fpd/HKc=",
      "url": "lib/bootstrap-icons/icons/dash-square.svg"
    },
    {
      "hash": "sha256-lmylLT0/Vi/i+A9uzxKZoLXqV9XR3EhXfdL0c3XpTgI=",
      "url": "lib/bootstrap-icons/icons/dash.svg"
    },
    {
      "hash": "sha256-gBOv3Z6WK9XH8O96TUHdC9EXX88HOrVl9c5NfWWTZkk=",
      "url": "lib/bootstrap-icons/icons/database-add.svg"
    },
    {
      "hash": "sha256-26TtnPkGx9MMZHwW4jLl+aVf1Zl2hNvHaZMg1LcuHvo=",
      "url": "lib/bootstrap-icons/icons/database-check.svg"
    },
    {
      "hash": "sha256-oBCLR4uQ4wRKG7RyWZatQPzm1rexN/0s1PcXZdQ/fBc=",
      "url": "lib/bootstrap-icons/icons/database-dash.svg"
    },
    {
      "hash": "sha256-g3xyYGsFKEWrt7O/ffNys6yflXZZS+IkRdaCqsHfWC0=",
      "url": "lib/bootstrap-icons/icons/database-down.svg"
    },
    {
      "hash": "sha256-umlfbYceoY5YLbUUVTCnwNZcvDi2nEsaq5pzsiMd5Gc=",
      "url": "lib/bootstrap-icons/icons/database-exclamation.svg"
    },
    {
      "hash": "sha256-XipsYsARoGPQ8s39KRKkPO2pysHuWxNCRrvjdin0CEQ=",
      "url": "lib/bootstrap-icons/icons/database-fill-add.svg"
    },
    {
      "hash": "sha256-YqpbJM0R1ws3bxPtcbwHZ2mZ7yu6pbrrFSzar/xzD5U=",
      "url": "lib/bootstrap-icons/icons/database-fill-check.svg"
    },
    {
      "hash": "sha256-2vkIH7N7QVSClu9YkLzZQ2JX/zNV0SWCV5bCv5pel3k=",
      "url": "lib/bootstrap-icons/icons/database-fill-dash.svg"
    },
    {
      "hash": "sha256-hbpH2EmKtHDkCgtgK5S+lYLgzkQzqNELszmXuEZ+SIY=",
      "url": "lib/bootstrap-icons/icons/database-fill-down.svg"
    },
    {
      "hash": "sha256-cVMWAOd29Wh/S7wYj2Fku3xjJ1wHo4R0BGuXYP7wemI=",
      "url": "lib/bootstrap-icons/icons/database-fill-exclamation.svg"
    },
    {
      "hash": "sha256-G8KB5zunf4KM/dLInvJOUC5qjFJ0jKoAYylgrIc14hs=",
      "url": "lib/bootstrap-icons/icons/database-fill-gear.svg"
    },
    {
      "hash": "sha256-8bLdTVmOahA+QE6uSFm/WFd5U4l2Lq9+lBV9NFiprLo=",
      "url": "lib/bootstrap-icons/icons/database-fill-lock.svg"
    },
    {
      "hash": "sha256-8HKCZI+MEn084gczcW1lNTwCY3/9oDykc/+1QdF6MDg=",
      "url": "lib/bootstrap-icons/icons/database-fill-slash.svg"
    },
    {
      "hash": "sha256-bavi/a5K/ny9b7NV2Y+w3G5VE4Y02NBjSMjPEiF0nto=",
      "url": "lib/bootstrap-icons/icons/database-fill-up.svg"
    },
    {
      "hash": "sha256-jCiHD3D4FNqLA5DcoMHF9rQe62ifhJ7I2QscUZatABM=",
      "url": "lib/bootstrap-icons/icons/database-fill-x.svg"
    },
    {
      "hash": "sha256-dJpZmQIlV7nuoxXGHVlWTOHSst1RiTTRV8TPVBZwhB4=",
      "url": "lib/bootstrap-icons/icons/database-fill.svg"
    },
    {
      "hash": "sha256-qFnuk4I7WrVdCvxsrU+V4v0UE37MiS0SU2rSWeZQFds=",
      "url": "lib/bootstrap-icons/icons/database-gear.svg"
    },
    {
      "hash": "sha256-TB0P3oYA61bydo4X5fHbOlnYpNOyJFpES1yaCMu4djY=",
      "url": "lib/bootstrap-icons/icons/database-lock.svg"
    },
    {
      "hash": "sha256-QYsLRdhxTlP4jp2C0sb5ao3aY5C8GBQQM6WBQwKozJs=",
      "url": "lib/bootstrap-icons/icons/database-slash.svg"
    },
    {
      "hash": "sha256-mv+2INVZtNy7wmL51OrhUYdj6WlaeLm3lLFKVLGAd7U=",
      "url": "lib/bootstrap-icons/icons/database-up.svg"
    },
    {
      "hash": "sha256-miHRsWSBxqoThYfaYkL1JyHACOgaurKNwOOY9YdJHEU=",
      "url": "lib/bootstrap-icons/icons/database-x.svg"
    },
    {
      "hash": "sha256-wQtRw/kO+FyulYvKDyzqR3MFzWHSa+Bokz4Cxqz6wtw=",
      "url": "lib/bootstrap-icons/icons/database.svg"
    },
    {
      "hash": "sha256-4hpvGZtHANAQ1ZHirFjlvVGosOpUG+Gzem4njLQJu7c=",
      "url": "lib/bootstrap-icons/icons/device-hdd-fill.svg"
    },
    {
      "hash": "sha256-j6d9QQSd8bItsuCbr6EQi20RqxZt8TjcubUFmlK8O6w=",
      "url": "lib/bootstrap-icons/icons/device-hdd.svg"
    },
    {
      "hash": "sha256-RDgA56N7jFe3tF7C5k+qQ2tMvHr3CAh0OZX/keNG590=",
      "url": "lib/bootstrap-icons/icons/device-ssd-fill.svg"
    },
    {
      "hash": "sha256-XGGBpxMQHPRO7bdKfjfjn5YUfHlY36Gy0Z/NxZVx5Zc=",
      "url": "lib/bootstrap-icons/icons/device-ssd.svg"
    },
    {
      "hash": "sha256-65l3wt3onSO/rC22xqL/Ah3PUlqmqhVUeTl8ltQ3yz0=",
      "url": "lib/bootstrap-icons/icons/diagram-2-fill.svg"
    },
    {
      "hash": "sha256-JUaN5cEUzUo8VQ7rTpatxybEGjXS4CBptScmnMg2Yo8=",
      "url": "lib/bootstrap-icons/icons/diagram-2.svg"
    },
    {
      "hash": "sha256-VnJbCs8UIxGH1JacejxTBkTiXNczVRjN+yuJxNeV9XE=",
      "url": "lib/bootstrap-icons/icons/diagram-3-fill.svg"
    },
    {
      "hash": "sha256-CFeiPRxO+UGLKlMYK4zUyi89OZNq5iq2gSQqGh6Z7h0=",
      "url": "lib/bootstrap-icons/icons/diagram-3.svg"
    },
    {
      "hash": "sha256-CU8ATiuzfaEGEVF9tmoGVM0+WD5gQ5OWvKygbA8rZM0=",
      "url": "lib/bootstrap-icons/icons/diamond-fill.svg"
    },
    {
      "hash": "sha256-JTyRLdhRv8EHcy2vFXMOfdZsEFU3j9eZqYToUQLCb8w=",
      "url": "lib/bootstrap-icons/icons/diamond-half.svg"
    },
    {
      "hash": "sha256-+KxzPIU8Gn7UhMsQkgaDjzmJ4fNGEZNBI8kAiXNqSOo=",
      "url": "lib/bootstrap-icons/icons/diamond.svg"
    },
    {
      "hash": "sha256-gJi+zxDwnVVJJumc3tkc3jCwrCR+gjXMWr5jgkY+KG8=",
      "url": "lib/bootstrap-icons/icons/dice-1-fill.svg"
    },
    {
      "hash": "sha256-Pb2mSXsZzYziqBITmCIYG84vLJbTH96lVHRxvr93KXo=",
      "url": "lib/bootstrap-icons/icons/dice-1.svg"
    },
    {
      "hash": "sha256-q5FfixwN2P4SEhnQeMTo4NqyhWTcldGCAJGZvE5vOZI=",
      "url": "lib/bootstrap-icons/icons/dice-2-fill.svg"
    },
    {
      "hash": "sha256-nIsOHhcJh7gJTsw9KbKKajdcDRkOWfOAylQIZk0PWU4=",
      "url": "lib/bootstrap-icons/icons/dice-2.svg"
    },
    {
      "hash": "sha256-El3h/xAVFZERzPPlETbPJs5RdSjedAclgBBXI1zk0kQ=",
      "url": "lib/bootstrap-icons/icons/dice-3-fill.svg"
    },
    {
      "hash": "sha256-7Z9h2OIaVf5uYgySmnrTovW51rBLFEk0fH6H9O/NFwc=",
      "url": "lib/bootstrap-icons/icons/dice-3.svg"
    },
    {
      "hash": "sha256-Td9qvGrwPgZzHp+GYFEZoKWcWuq/zoOcU831GDOLTPk=",
      "url": "lib/bootstrap-icons/icons/dice-4-fill.svg"
    },
    {
      "hash": "sha256-qkixLp+R7GadA/8KeOy9LkWJmYbPTPFTxZchTslwEGo=",
      "url": "lib/bootstrap-icons/icons/dice-4.svg"
    },
    {
      "hash": "sha256-4un1pAzlTo69krVqbXv6tGpJal54VeTFUVgMebTJAqM=",
      "url": "lib/bootstrap-icons/icons/dice-5-fill.svg"
    },
    {
      "hash": "sha256-VVu8H4JQn0C6pv3CA6KQLXv3p5G9f7V+EnWtcB0dgAg=",
      "url": "lib/bootstrap-icons/icons/dice-5.svg"
    },
    {
      "hash": "sha256-s459TqSHOdBc+outEN5WPbJ84BP9x/zm304u42qpBXA=",
      "url": "lib/bootstrap-icons/icons/dice-6-fill.svg"
    },
    {
      "hash": "sha256-hHdeeX1c04STx1Ww0CL8cU/NqF86+X0jlcs9/jJu0rY=",
      "url": "lib/bootstrap-icons/icons/dice-6.svg"
    },
    {
      "hash": "sha256-PkPZs3VqSJ7hV/OIbIQGCDoz2B10IDL02ySHYid1jTA=",
      "url": "lib/bootstrap-icons/icons/disc-fill.svg"
    },
    {
      "hash": "sha256-jgFg79xi27QQ2+v8TqVOcXEohEt4/aCkHB2dnWYCWk4=",
      "url": "lib/bootstrap-icons/icons/disc.svg"
    },
    {
      "hash": "sha256-Zj8oPacEWlaJIsYDllqkItDGXIpV6kKa+t+1kBlSEPI=",
      "url": "lib/bootstrap-icons/icons/discord.svg"
    },
    {
      "hash": "sha256-zqBP3wL0aArvZY88ENiRP3L37xvzudfDeQ2/0SGHxlM=",
      "url": "lib/bootstrap-icons/icons/display-fill.svg"
    },
    {
      "hash": "sha256-lVbVlVWYEJYuAs7z3xTNpVm27sVMJoLYjx06pRVQUt8=",
      "url": "lib/bootstrap-icons/icons/display.svg"
    },
    {
      "hash": "sha256-IiGoO8kexQjk2vUdr0QtcIz4Im2Yo6c4lM/lIE6iiyM=",
      "url": "lib/bootstrap-icons/icons/displayport-fill.svg"
    },
    {
      "hash": "sha256-pLK0/+rlB4LdfxH6/g7Gsw51Q1KQ46gZdfw9d12uT+U=",
      "url": "lib/bootstrap-icons/icons/displayport.svg"
    },
    {
      "hash": "sha256-CRTxe5/N0Casmhw0UU+dY3Tx2PpCUhed0ZzQwlhQblQ=",
      "url": "lib/bootstrap-icons/icons/distribute-horizontal.svg"
    },
    {
      "hash": "sha256-ed0LvwOKaBfub/SsOnfe5Y+Ba+dbVP6ymfDOo5a78mM=",
      "url": "lib/bootstrap-icons/icons/distribute-vertical.svg"
    },
    {
      "hash": "sha256-azO3CznRGPhnUqool4vyCWYFH75qVG8j7TzbDu0A7Uc=",
      "url": "lib/bootstrap-icons/icons/door-closed-fill.svg"
    },
    {
      "hash": "sha256-/QNcJ5ov1EDeThdwNkfhPmFb17Ei8kYp+YpFhuM+Ylc=",
      "url": "lib/bootstrap-icons/icons/door-closed.svg"
    },
    {
      "hash": "sha256-1JDZvKDTlm1eWKhgW+TdLtxtMoBN97RNsKUiS7PstIk=",
      "url": "lib/bootstrap-icons/icons/door-open-fill.svg"
    },
    {
      "hash": "sha256-ta6jhgyQy2C2akczCnssDXHzaczfG1y63AaEW3e+z1o=",
      "url": "lib/bootstrap-icons/icons/door-open.svg"
    },
    {
      "hash": "sha256-bWV05J58FNFH6uCF1CUD6B3g8Bcz4u6lIWvvhNIu6AY=",
      "url": "lib/bootstrap-icons/icons/dot.svg"
    },
    {
      "hash": "sha256-6/VYhQ9rEhHjXUZcofL5xpvZvq+l70uuyUrkWP+EIm0=",
      "url": "lib/bootstrap-icons/icons/download.svg"
    },
    {
      "hash": "sha256-E/lVbD0/eWykbxnanWPndzZUwBblmMwcnhsrQ8TEgao=",
      "url": "lib/bootstrap-icons/icons/dpad-fill.svg"
    },
    {
      "hash": "sha256-4SIa8KNvoAaDXe4FC0UT8PrtwUudfnpuTmWKJIX00TE=",
      "url": "lib/bootstrap-icons/icons/dpad.svg"
    },
    {
      "hash": "sha256-SI4iGiKZlK0Yne6q4iuu9sMv054KSWTyO9rM1mDlXHE=",
      "url": "lib/bootstrap-icons/icons/dribbble.svg"
    },
    {
      "hash": "sha256-aR6kndcVVFYZpOGy1DBdBm9PG49ORraS42A1/TpLQMs=",
      "url": "lib/bootstrap-icons/icons/dropbox.svg"
    },
    {
      "hash": "sha256-3aIH7t2Bb3Tc8JC5IO3isMxcbT9r3jYa63JiBvyWezc=",
      "url": "lib/bootstrap-icons/icons/droplet-fill.svg"
    },
    {
      "hash": "sha256-PcpQhLw+nT8z5tMhi3+iqM4zaPHJl67slDLFTd/sk9o=",
      "url": "lib/bootstrap-icons/icons/droplet-half.svg"
    },
    {
      "hash": "sha256-SRnuf0xiYzPT+Zummru702NaV//CcruxdbIaX5vR/rU=",
      "url": "lib/bootstrap-icons/icons/droplet.svg"
    },
    {
      "hash": "sha256-QCBFC5asTfByWime+U6/uGpZOvytmjAaqabaEdsw0Pk=",
      "url": "lib/bootstrap-icons/icons/duffle-fill.svg"
    },
    {
      "hash": "sha256-WN6yl3akpx91GeUVXgCr9+m69U6ZGnQ3MxI3dSZPKZk=",
      "url": "lib/bootstrap-icons/icons/duffle.svg"
    },
    {
      "hash": "sha256-a0xXnEUSFKzRiBmzQGvMRFPpAjTHlBJX0fYTzEfOyuc=",
      "url": "lib/bootstrap-icons/icons/ear-fill.svg"
    },
    {
      "hash": "sha256-ucS9LuE7byfNd8JixnjCnRhIulWVVbVzGQbo4L568+A=",
      "url": "lib/bootstrap-icons/icons/ear.svg"
    },
    {
      "hash": "sha256-0WYaHFdNk/BJU84OJqhPPNcfHJzt7MC+VYCBgXWbWCE=",
      "url": "lib/bootstrap-icons/icons/earbuds.svg"
    },
    {
      "hash": "sha256-KzWY/afSyzLfPp+kkYYW8w3MEKbCFFVum++h/xbpeM8=",
      "url": "lib/bootstrap-icons/icons/easel-fill.svg"
    },
    {
      "hash": "sha256-HcuI39/IXf+taBguM8k+myvRMiUfVu/z4gV14pgdk50=",
      "url": "lib/bootstrap-icons/icons/easel.svg"
    },
    {
      "hash": "sha256-fSXeYfOErhUpcIH+hRbEEyAToPWpHUsmLjC7WdmR/j4=",
      "url": "lib/bootstrap-icons/icons/easel2-fill.svg"
    },
    {
      "hash": "sha256-wAvzMH89p3LulxNpfuhFvwaFx71EM8MXSsiNJUkqwco=",
      "url": "lib/bootstrap-icons/icons/easel2.svg"
    },
    {
      "hash": "sha256-smQ5IZg4qND++gWdnQQXoMpTaoPa/+Sz+Ds592wHIG8=",
      "url": "lib/bootstrap-icons/icons/easel3-fill.svg"
    },
    {
      "hash": "sha256-cfFY1m/ZQdlVbXL2u2THm//aXEGzEAeLiZ+hS5hdMOU=",
      "url": "lib/bootstrap-icons/icons/easel3.svg"
    },
    {
      "hash": "sha256-yPvRP5nxivTpVAEZ6lXTwiNY6xb9VZ8LPnjVoNR7FN0=",
      "url": "lib/bootstrap-icons/icons/egg-fill.svg"
    },
    {
      "hash": "sha256-uWOXO1GwCdQnVWupSQfRJIiw0pzl0OKO7jP572QNSPA=",
      "url": "lib/bootstrap-icons/icons/egg-fried.svg"
    },
    {
      "hash": "sha256-ibIKGQum5enLoHsytQOSM32t02D96afDD4mmUqeZSVs=",
      "url": "lib/bootstrap-icons/icons/egg.svg"
    },
    {
      "hash": "sha256-8FOfjrI4uuND9vkRtyUEbu+i4nFi8fzA5K0o0P2XPUY=",
      "url": "lib/bootstrap-icons/icons/eject-fill.svg"
    },
    {
      "hash": "sha256-X5IPmJjx1NZXaIDvqyVVVKvNbYadRBjW9bU8URQIP0w=",
      "url": "lib/bootstrap-icons/icons/eject.svg"
    },
    {
      "hash": "sha256-mAESs6dr48IEnmFMxgf6IH9op7aIoOTdwF4uiH+id5g=",
      "url": "lib/bootstrap-icons/icons/emoji-angry-fill.svg"
    },
    {
      "hash": "sha256-mkgoi9GuOPkv0nK9xU1hq1jSZu2ukHE449Gw6+qhHaw=",
      "url": "lib/bootstrap-icons/icons/emoji-angry.svg"
    },
    {
      "hash": "sha256-WYHn4UonBDiDygmYtMyZkYWirr0HHTuMBKDRTf7ehfo=",
      "url": "lib/bootstrap-icons/icons/emoji-astonished-fill.svg"
    },
    {
      "hash": "sha256-20Lb8G5g7W20YeTsiM2AdSaR+e6rql9B4HNNWOtOx1o=",
      "url": "lib/bootstrap-icons/icons/emoji-astonished.svg"
    },
    {
      "hash": "sha256-+FmzKhkgVTKa1JsVzI0txYqT3+MSQupf+IjHicMbHyw=",
      "url": "lib/bootstrap-icons/icons/emoji-dizzy-fill.svg"
    },
    {
      "hash": "sha256-HKGS9JQMGH06Bn8nC2IeDpOKZQ7aPpONJcZ2rE4CtOw=",
      "url": "lib/bootstrap-icons/icons/emoji-dizzy.svg"
    },
    {
      "hash": "sha256-wkG6ebbvRhxviRcgqveuA5YH/aChL6XZS2H+E8TP6BY=",
      "url": "lib/bootstrap-icons/icons/emoji-expressionless-fill.svg"
    },
    {
      "hash": "sha256-H9E1CWDCuNua64golGxf1ENxZ0u401zYVQlWcFJ/nvg=",
      "url": "lib/bootstrap-icons/icons/emoji-expressionless.svg"
    },
    {
      "hash": "sha256-Fv5DLAyvFfWEZ0KfuJH3Qq71Wn04+5FltUEzFq2rZ70=",
      "url": "lib/bootstrap-icons/icons/emoji-frown-fill.svg"
    },
    {
      "hash": "sha256-Ce+GpanKMpiI03aIM7kS5DGPyXiiFVq95ktuF3jjZD0=",
      "url": "lib/bootstrap-icons/icons/emoji-frown.svg"
    },
    {
      "hash": "sha256-xklxcoR0sjzRZNX7/BHWBV2quTFkLzg+0fM3i0uooQk=",
      "url": "lib/bootstrap-icons/icons/emoji-grimace-fill.svg"
    },
    {
      "hash": "sha256-Tof/u1LY/9stxjiszsIQRJjHXEODc73O7ClvqQWtlus=",
      "url": "lib/bootstrap-icons/icons/emoji-grimace.svg"
    },
    {
      "hash": "sha256-lLyAKire8/K2vzxWi2/geJOgGGv4MuBDlqfneDQI50k=",
      "url": "lib/bootstrap-icons/icons/emoji-grin-fill.svg"
    },
    {
      "hash": "sha256-2PinRlF3eob1CpG8gCajKikaTxgPqwZ4devJGifnZaY=",
      "url": "lib/bootstrap-icons/icons/emoji-grin.svg"
    },
    {
      "hash": "sha256-dLyKEje46PDpjmVIgCGZgaJh2daPGIJXdnUDeslrqho=",
      "url": "lib/bootstrap-icons/icons/emoji-heart-eyes-fill.svg"
    },
    {
      "hash": "sha256-NkL+zWUkaB/nVnnKaLI229Pnn8g14PXFLpUEIONoIGM=",
      "url": "lib/bootstrap-icons/icons/emoji-heart-eyes.svg"
    },
    {
      "hash": "sha256-eOTRT3fByoI5oi0WM3fp4XYstVHNHmPEp245L8ClxPs=",
      "url": "lib/bootstrap-icons/icons/emoji-kiss-fill.svg"
    },
    {
      "hash": "sha256-1TC6nv0MO+xw4Yy606b5zbdVa7qgoYHM+NobUvh8d2U=",
      "url": "lib/bootstrap-icons/icons/emoji-kiss.svg"
    },
    {
      "hash": "sha256-BBJTo22HtSviXO9SNuvoSsrBwxqn09f3qxARsGE/NKY=",
      "url": "lib/bootstrap-icons/icons/emoji-laughing-fill.svg"
    },
    {
      "hash": "sha256-FrmwcCkyzfw6ok1hONrnW2f+JB2DlDp7utHa4FqxwIU=",
      "url": "lib/bootstrap-icons/icons/emoji-laughing.svg"
    },
    {
      "hash": "sha256-hBow/g88IYPjovZZrSyvS3mhG6ILMi1Um9JR22aJYTg=",
      "url": "lib/bootstrap-icons/icons/emoji-neutral-fill.svg"
    },
    {
      "hash": "sha256-Ya5PJenWaw59AiXbBBttF9nhclEgwRVahUulp9F1Tqw=",
      "url": "lib/bootstrap-icons/icons/emoji-neutral.svg"
    },
    {
      "hash": "sha256-bmy4f22uDvy1B9cninhJgSbGocnloFT1illYGDZrGrQ=",
      "url": "lib/bootstrap-icons/icons/emoji-smile-fill.svg"
    },
    {
      "hash": "sha256-d5vKzuOCvJsUPgpC145WnBHkvOXQtSs3/VQBgPvrfjI=",
      "url": "lib/bootstrap-icons/icons/emoji-smile-upside-down-fill.svg"
    },
    {
      "hash": "sha256-t+JglyI+aLV5K3TTG8x8aTEyPIzIfEzRbT3yvYq6P78=",
      "url": "lib/bootstrap-icons/icons/emoji-smile-upside-down.svg"
    },
    {
      "hash": "sha256-aLBjhDPnmadcpfPB5e+wvXNUqA1BKbe6eCjdYulYDFM=",
      "url": "lib/bootstrap-icons/icons/emoji-smile.svg"
    },
    {
      "hash": "sha256-tgwBIG0QFAMFmXjZbiR5OyAzgruZ0L9TZFevFlAmK6c=",
      "url": "lib/bootstrap-icons/icons/emoji-sunglasses-fill.svg"
    },
    {
      "hash": "sha256-qrUKaWjl1AZya8ZUKvk6EvOb3QHjfJRR5DWwR+L+wc4=",
      "url": "lib/bootstrap-icons/icons/emoji-sunglasses.svg"
    },
    {
      "hash": "sha256-yCrB6C3wRO+B7KTbI9LwVgOCXWl9GOUApTioBWhhNI0=",
      "url": "lib/bootstrap-icons/icons/emoji-surprise-fill.svg"
    },
    {
      "hash": "sha256-7kqlowqkMcN85OwmZbiSEMwVcsdIUByhVvvNJb4bLfc=",
      "url": "lib/bootstrap-icons/icons/emoji-surprise.svg"
    },
    {
      "hash": "sha256-TAN1S49ar9Y9Uw6z/G31Bayv4VVBcxoRatTK6fmPMxM=",
      "url": "lib/bootstrap-icons/icons/emoji-tear-fill.svg"
    },
    {
      "hash": "sha256-rb5SMyXVxNj2enhrszFjydY2AIUeDzJdoFYYI0nZQ/4=",
      "url": "lib/bootstrap-icons/icons/emoji-tear.svg"
    },
    {
      "hash": "sha256-u4NvzCRD161v955D+SCODygr3JOE/iQWG7/R0TL3Uww=",
      "url": "lib/bootstrap-icons/icons/emoji-wink-fill.svg"
    },
    {
      "hash": "sha256-RtOR3CzJf7gxWNaSN2h7sfxr8Q8zfsELzzERQ89GpFQ=",
      "url": "lib/bootstrap-icons/icons/emoji-wink.svg"
    },
    {
      "hash": "sha256-mgLI9OFgSVrGmMiOY0g/KGA8ufucSGzV2HMYU1c6xik=",
      "url": "lib/bootstrap-icons/icons/envelope-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-hl2rszMRvPiiAwVVFz2aXQ7rtPFall7Tukn1tnBLYns=",
      "url": "lib/bootstrap-icons/icons/envelope-arrow-down.svg"
    },
    {
      "hash": "sha256-XfkAIvZyxozAE0q8VdN4q9A0HMx56fb86K5uLoSg5S4=",
      "url": "lib/bootstrap-icons/icons/envelope-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-mMBW6QKk+PmMQVN6ZH3NnEBw0oF6kBw/3mS9TY5tXV0=",
      "url": "lib/bootstrap-icons/icons/envelope-arrow-up.svg"
    },
    {
      "hash": "sha256-oxVu2NywQsq5iLMZ1dbygBmltdnYPFi4FMOLR+iWWyU=",
      "url": "lib/bootstrap-icons/icons/envelope-at-fill.svg"
    },
    {
      "hash": "sha256-P5r1zervL7uQAZS07BO4xE/ti7iYsdJ7DT/Lt4L0A50=",
      "url": "lib/bootstrap-icons/icons/envelope-at.svg"
    },
    {
      "hash": "sha256-3qaT2nBduMRC4UZy3Mt6Yd/uyy082B0YaIHssfVn5uw=",
      "url": "lib/bootstrap-icons/icons/envelope-check-fill.svg"
    },
    {
      "hash": "sha256-MmrdzGHM2xcrdSbI2FbXLp7cMoprJMcV06wVG3JW4cc=",
      "url": "lib/bootstrap-icons/icons/envelope-check.svg"
    },
    {
      "hash": "sha256-Y17+Hz4XHkgtT7sMRCGbXZhiSKwWrM0Mk5V7omdrIR0=",
      "url": "lib/bootstrap-icons/icons/envelope-dash-fill.svg"
    },
    {
      "hash": "sha256-rjnayE4LZ7UGF5xKPWp3hPMs6UJrQpL/gl6eN6AWo1I=",
      "url": "lib/bootstrap-icons/icons/envelope-dash.svg"
    },
    {
      "hash": "sha256-p7wNLKcwglVIfJeWWalPfkaSkjQHMr57RaG+FCrpp8s=",
      "url": "lib/bootstrap-icons/icons/envelope-exclamation-fill.svg"
    },
    {
      "hash": "sha256-9qQYN0eQbqand6vAiWwI5gVvKjq3E1sHP7TC0AgdBaE=",
      "url": "lib/bootstrap-icons/icons/envelope-exclamation.svg"
    },
    {
      "hash": "sha256-E6X3/8WpVzIXOS0pEPt6dFUz5s3vkSVf7l481wIjF6Q=",
      "url": "lib/bootstrap-icons/icons/envelope-fill.svg"
    },
    {
      "hash": "sha256-3rQ4O5H6jHbPAPduNNSOv3xdhgNzVNGvLqnrWpwsu90=",
      "url": "lib/bootstrap-icons/icons/envelope-heart-fill.svg"
    },
    {
      "hash": "sha256-bjN+cx4eLPUipESEvV+bVB0uoXQGjzSdNcWcwO5qsf0=",
      "url": "lib/bootstrap-icons/icons/envelope-heart.svg"
    },
    {
      "hash": "sha256-1xIiJM6g7iAuTqgGaHnvmZjbkwcALz6bt9NnKlHQDOw=",
      "url": "lib/bootstrap-icons/icons/envelope-open-fill.svg"
    },
    {
      "hash": "sha256-w/B/k66yPkgJy6Z8r7WR4hRZaPmN31rAEpP1iHo/5vw=",
      "url": "lib/bootstrap-icons/icons/envelope-open-heart-fill.svg"
    },
    {
      "hash": "sha256-m9Tdrs7v5kf0h7+SfqVph44FSoaOxd673Yy6tfNo99Y=",
      "url": "lib/bootstrap-icons/icons/envelope-open-heart.svg"
    },
    {
      "hash": "sha256-3d+ykoJfNXAVAWEQZYnr+IYdWnKuiYxltUhYALh8DU8=",
      "url": "lib/bootstrap-icons/icons/envelope-open.svg"
    },
    {
      "hash": "sha256-BRp8pjtflpjus3Bc3dciB9O5E+BX+ea6NdAT32wGQTY=",
      "url": "lib/bootstrap-icons/icons/envelope-paper-fill.svg"
    },
    {
      "hash": "sha256-/PHEsTxYx5RTBzL5M3atQ9St2/IFH6ivqfcgqYxwm+4=",
      "url": "lib/bootstrap-icons/icons/envelope-paper-heart-fill.svg"
    },
    {
      "hash": "sha256-PnDc6h3AFwieg6krVHiMAyj1bascMnETSD/WfkwejGo=",
      "url": "lib/bootstrap-icons/icons/envelope-paper-heart.svg"
    },
    {
      "hash": "sha256-rooCs4r03cqbx2hiGN0ty9JwK8lAvPcO1aDTgJIoRmo=",
      "url": "lib/bootstrap-icons/icons/envelope-paper.svg"
    },
    {
      "hash": "sha256-0HAnIaHzoJoEOuiy+7TPlR7dva38hImZ2Jdf2E9HkfQ=",
      "url": "lib/bootstrap-icons/icons/envelope-plus-fill.svg"
    },
    {
      "hash": "sha256-4GRqs3Uo++pjSY+RDjbbR1Zx9hejY692YS1EC9ufUYA=",
      "url": "lib/bootstrap-icons/icons/envelope-plus.svg"
    },
    {
      "hash": "sha256-HyFjoOkPPgRwNdV4yl8AuOT4ik7TS6zIhu/UT2EcFKY=",
      "url": "lib/bootstrap-icons/icons/envelope-slash-fill.svg"
    },
    {
      "hash": "sha256-6amnombJfEZtB9mO4Uujq2bb2wg99lPS1/p26HhwFuc=",
      "url": "lib/bootstrap-icons/icons/envelope-slash.svg"
    },
    {
      "hash": "sha256-EKMZ4115WBG6emWSMo+Nh/SiBqlka+Lld1yoidOg/F8=",
      "url": "lib/bootstrap-icons/icons/envelope-x-fill.svg"
    },
    {
      "hash": "sha256-QlkWAnVFUpWRGnp8aLgXDjmDX7CZepiT5AOxVzjLiuk=",
      "url": "lib/bootstrap-icons/icons/envelope-x.svg"
    },
    {
      "hash": "sha256-8uXHDdBUh6aTsFnei5YamulyRMwTAeQcbdiLhNCBF/M=",
      "url": "lib/bootstrap-icons/icons/envelope.svg"
    },
    {
      "hash": "sha256-x7z9a3Efsp0rwtLuSLSqbuTDQlB3gWBOd+K8P18mMCE=",
      "url": "lib/bootstrap-icons/icons/eraser-fill.svg"
    },
    {
      "hash": "sha256-FC8F2j57p31/JGz/scJryycXJDuBI3d03QHSxdeUaYU=",
      "url": "lib/bootstrap-icons/icons/eraser.svg"
    },
    {
      "hash": "sha256-VzVuufose7NVefszL31/wafXxaUYMt0RFePPP1SFQFs=",
      "url": "lib/bootstrap-icons/icons/escape.svg"
    },
    {
      "hash": "sha256-v0V70bv5nlMbot7dwHgt/gJB7PkInjyzZ/9lGDN4OyA=",
      "url": "lib/bootstrap-icons/icons/ethernet.svg"
    },
    {
      "hash": "sha256-wudZlVDC9hYPm2XlvVu0DC9IzFnL00Bc2bdoEdTYy/M=",
      "url": "lib/bootstrap-icons/icons/ev-front-fill.svg"
    },
    {
      "hash": "sha256-MCHfR8VaEp79kazUyBmIRPl/PTuglWwu0a0tUukL1VM=",
      "url": "lib/bootstrap-icons/icons/ev-front.svg"
    },
    {
      "hash": "sha256-mQXeUoB92/NZeGkY7JXhbziyO399sEHHeRmuvNOwWwI=",
      "url": "lib/bootstrap-icons/icons/ev-station-fill.svg"
    },
    {
      "hash": "sha256-zu7vRkRvFliYERR5fEyTjhbNufd8dI8m35AJ31GZYo4=",
      "url": "lib/bootstrap-icons/icons/ev-station.svg"
    },
    {
      "hash": "sha256-WOPVuJD5X7232Qa2Fhw66mJJEeUphzigngTsS/dzrlE=",
      "url": "lib/bootstrap-icons/icons/exclamation-circle-fill.svg"
    },
    {
      "hash": "sha256-+PE516zJN5bVpoiahwrfaa4GDBlsD4YVYrSJbXEgKes=",
      "url": "lib/bootstrap-icons/icons/exclamation-circle.svg"
    },
    {
      "hash": "sha256-699kpcsiWV9GkhxRZiYCjY+oE0pk5pTSbJIiWWn+f9g=",
      "url": "lib/bootstrap-icons/icons/exclamation-diamond-fill.svg"
    },
    {
      "hash": "sha256-jtdAt3r8hrH2gSetUR1dYCt284FrQlVio49+iuHT3XY=",
      "url": "lib/bootstrap-icons/icons/exclamation-diamond.svg"
    },
    {
      "hash": "sha256-REaTTgzgXTJFPaTIfUMWoA1j3+X1zaqkqpZEFsPGy0w=",
      "url": "lib/bootstrap-icons/icons/exclamation-lg.svg"
    },
    {
      "hash": "sha256-w3JwX1ylRbS52gCx4uyX4CBP9wMQlBzU+cQDFu6jv7s=",
      "url": "lib/bootstrap-icons/icons/exclamation-octagon-fill.svg"
    },
    {
      "hash": "sha256-uOMXYa8EzM3QYWM3pWLUCXYLA3yfv/7OnnUL5mX9xIs=",
      "url": "lib/bootstrap-icons/icons/exclamation-octagon.svg"
    },
    {
      "hash": "sha256-ZX/6if+VlxPv6FbMiipnWyu3/4It8P1ZFWBb/f64n30=",
      "url": "lib/bootstrap-icons/icons/exclamation-square-fill.svg"
    },
    {
      "hash": "sha256-Q9R5nEq0y5nKK8ogLqrSniZKws5Cn2dEsusl577WbDg=",
      "url": "lib/bootstrap-icons/icons/exclamation-square.svg"
    },
    {
      "hash": "sha256-Vt8B1UHvEEk0LneC0y9ByE5EtPsHz1TXyA1nGcQNalo=",
      "url": "lib/bootstrap-icons/icons/exclamation-triangle-fill.svg"
    },
    {
      "hash": "sha256-8ChIhKyvUch7I9L4FeCNLAzLGKCysiCceUJINvkm/8k=",
      "url": "lib/bootstrap-icons/icons/exclamation-triangle.svg"
    },
    {
      "hash": "sha256-f1+P5Pc8I0O51eeIsFwqCYoNfcPn8rd2feUY8Qdvmng=",
      "url": "lib/bootstrap-icons/icons/exclamation.svg"
    },
    {
      "hash": "sha256-YNM901PtQWmwTK2f3kBbCVOJhPvfrv51sY5cXYTicso=",
      "url": "lib/bootstrap-icons/icons/exclude.svg"
    },
    {
      "hash": "sha256-+xSy2L6qWr/tYcpy9QxQCr+k8Au2XcyM2JeSz/IUwug=",
      "url": "lib/bootstrap-icons/icons/explicit-fill.svg"
    },
    {
      "hash": "sha256-E1vY9bBuKceTA43SnEdOQZY27NHqjnM3aOqtlEGoykE=",
      "url": "lib/bootstrap-icons/icons/explicit.svg"
    },
    {
      "hash": "sha256-lP0zxPfNulXCL2h3cxW9fss9QX6w4lQ8nBVfttst0QY=",
      "url": "lib/bootstrap-icons/icons/exposure.svg"
    },
    {
      "hash": "sha256-WDEtox4mwYKX+IkzlUgzAdASGNRSJo4Pw8ot2iAONnI=",
      "url": "lib/bootstrap-icons/icons/eye-fill.svg"
    },
    {
      "hash": "sha256-NXywwPDyhpS5yCxcxc1OtKkJiNen9PRw4HkC0FZt5hI=",
      "url": "lib/bootstrap-icons/icons/eye-slash-fill.svg"
    },
    {
      "hash": "sha256-5nMh4COqZPvSBvP59NXTNFJuWIW0Yr6me+PRdqMxGYM=",
      "url": "lib/bootstrap-icons/icons/eye-slash.svg"
    },
    {
      "hash": "sha256-MGBXklJCEFkCeyGmDuAkFGBgvUORwni6r0QYa4e3AkE=",
      "url": "lib/bootstrap-icons/icons/eye.svg"
    },
    {
      "hash": "sha256-N38kUq+JSU1S8oIfo5Ki26btX5+/8fI7fe6ja/n7q2Q=",
      "url": "lib/bootstrap-icons/icons/eyedropper.svg"
    },
    {
      "hash": "sha256-PoIdml+BETinFINtGBmYloKACZL7a9Aw6qM5b1p46gE=",
      "url": "lib/bootstrap-icons/icons/eyeglasses.svg"
    },
    {
      "hash": "sha256-EAK2HYAgypCTJGMpMzWA9XIdfhbGkrtkJpQ1YffMqGY=",
      "url": "lib/bootstrap-icons/icons/facebook.svg"
    },
    {
      "hash": "sha256-Q3/8SIGRhuJquuCGKVNlXzhXQFukQYBtE4+p2kmtNbU=",
      "url": "lib/bootstrap-icons/icons/fan.svg"
    },
    {
      "hash": "sha256-TsDsCNncjM4UUKVKSWLb/CVS5gEgOe8jH/q1xyP7Clw=",
      "url": "lib/bootstrap-icons/icons/fast-forward-btn-fill.svg"
    },
    {
      "hash": "sha256-1c3BJX4VvzcRkyHe4RRPia/lQi5lZHcVLLU/YNWRcKo=",
      "url": "lib/bootstrap-icons/icons/fast-forward-btn.svg"
    },
    {
      "hash": "sha256-jg8swhg2Ay8+s4XG+xbtWqeBptlAx0IpauZTRHe4/tw=",
      "url": "lib/bootstrap-icons/icons/fast-forward-circle-fill.svg"
    },
    {
      "hash": "sha256-sSeV16WFIW+fZdZvsg1d0AJFu8+7515+rX70UC5gGAo=",
      "url": "lib/bootstrap-icons/icons/fast-forward-circle.svg"
    },
    {
      "hash": "sha256-mRayMlo4Q6FkOU3UkXL8pXvmARiwn84W7vEj3VEVdiw=",
      "url": "lib/bootstrap-icons/icons/fast-forward-fill.svg"
    },
    {
      "hash": "sha256-AZUezaIhaa6HsuSyQNhMoQYIwsspUAB7IrnIVbQcf+s=",
      "url": "lib/bootstrap-icons/icons/fast-forward.svg"
    },
    {
      "hash": "sha256-D6yH1ra5S0nV6+zT94BaOhazMlVlYA05TFSGqazOQXc=",
      "url": "lib/bootstrap-icons/icons/feather.svg"
    },
    {
      "hash": "sha256-9K8CdWxi0aFhNyQeK5Tbznh7sTmmFfmNjkV/DAfO698=",
      "url": "lib/bootstrap-icons/icons/feather2.svg"
    },
    {
      "hash": "sha256-JXh3bNlal4kpgi4XKmM6GPmIV6aynqPpG9ECZ9a6c34=",
      "url": "lib/bootstrap-icons/icons/file-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-WhO82X1lwseuVTFBMH3KafRPoURHJkauFb4jWQdCoQI=",
      "url": "lib/bootstrap-icons/icons/file-arrow-down.svg"
    },
    {
      "hash": "sha256-5ny7q3AAzGZ1Id6/puEhCHdBNwrKgUKbz1gN+6jnSdU=",
      "url": "lib/bootstrap-icons/icons/file-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-jLFSh20CxPz0wvIfXnAZKTQFF3idkVkiwK8vhbVrRmU=",
      "url": "lib/bootstrap-icons/icons/file-arrow-up.svg"
    },
    {
      "hash": "sha256-q6M62Ci+5RVa9SNzlPOutwQt+6KQN27B1tKAOC7JEm8=",
      "url": "lib/bootstrap-icons/icons/file-bar-graph-fill.svg"
    },
    {
      "hash": "sha256-4ytX/Q/TF7s6dIyjQKoGmvJA2LC+4+DEAq5Pd1mV2SQ=",
      "url": "lib/bootstrap-icons/icons/file-bar-graph.svg"
    },
    {
      "hash": "sha256-KZaevuv0TN/pkyUw9RnBV2/ZntN6j5ZVCu/Bzn/LYqM=",
      "url": "lib/bootstrap-icons/icons/file-binary-fill.svg"
    },
    {
      "hash": "sha256-UsZqofghTdKFvZN8ZNkyvSpEHQAgPDqCdSwTQpX99c0=",
      "url": "lib/bootstrap-icons/icons/file-binary.svg"
    },
    {
      "hash": "sha256-QBsZy/gXmxJoyE/u0hazZH690gmRs2jFU3DcVSYWTuc=",
      "url": "lib/bootstrap-icons/icons/file-break-fill.svg"
    },
    {
      "hash": "sha256-eoc7BVwGnHAbbZksItzbXWhU04HDaNXDlJFLL378kKc=",
      "url": "lib/bootstrap-icons/icons/file-break.svg"
    },
    {
      "hash": "sha256-RV1sDUohj8bB4ypFqBLiOPQZQh/d9RQUdYXwWTyDXHE=",
      "url": "lib/bootstrap-icons/icons/file-check-fill.svg"
    },
    {
      "hash": "sha256-23ZuTJnCM6gfhOe/fbo1y5YkKiQLFuSl/snP5mBP/6U=",
      "url": "lib/bootstrap-icons/icons/file-check.svg"
    },
    {
      "hash": "sha256-2ayg8F47tWq2Bnq5IQVPCI7wewS7QwVRQrfkYaVJOVc=",
      "url": "lib/bootstrap-icons/icons/file-code-fill.svg"
    },
    {
      "hash": "sha256-f2RPMT/j8OE3VKL6MaKWPNOZSpSxaOURLiF3wSlUvuw=",
      "url": "lib/bootstrap-icons/icons/file-code.svg"
    },
    {
      "hash": "sha256-6i+OlhP8dBCc7/xVhqCC3oUWzhaADAnVSgMTbpASVaQ=",
      "url": "lib/bootstrap-icons/icons/file-diff-fill.svg"
    },
    {
      "hash": "sha256-8T5sLNxZ1zhIA3hMTLJALnAEeegpgbtMuu6XOUjO/wE=",
      "url": "lib/bootstrap-icons/icons/file-diff.svg"
    },
    {
      "hash": "sha256-SWztSOeFjz2o4C/nKBr7R3IO3GXQw8p2ouhLqM9Cuqk=",
      "url": "lib/bootstrap-icons/icons/file-earmark-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-ob5LuZDwuh4ruhltvmH+vgma7E1q8IPWX4WofMrL0jY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-arrow-down.svg"
    },
    {
      "hash": "sha256-SGaNqCLErNMvvAachUpPSp/yzw+T5Oy0mhhI+zxcm6I=",
      "url": "lib/bootstrap-icons/icons/file-earmark-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-pVoZoFfOnESQmekusL1P3Rff7vLnzSeKg5fxYdH3LAU=",
      "url": "lib/bootstrap-icons/icons/file-earmark-arrow-up.svg"
    },
    {
      "hash": "sha256-0Oe+GEn11Bvd50szdtrHL9DFfE6Bp0BCQNc6cgIN2ac=",
      "url": "lib/bootstrap-icons/icons/file-earmark-bar-graph-fill.svg"
    },
    {
      "hash": "sha256-iTiqoYI9GrA3x1wGUw/te/mYshjEJalIXPN+gdgFgUQ=",
      "url": "lib/bootstrap-icons/icons/file-earmark-bar-graph.svg"
    },
    {
      "hash": "sha256-4LVPdH+yT16qjX+hjQ9p5dZ7VxligJ9CGOaBjQZdWgY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-binary-fill.svg"
    },
    {
      "hash": "sha256-jOQ1T5EYU7V4LPC5jZ49u4mUrgpRO4VaVAhx8PSmuKc=",
      "url": "lib/bootstrap-icons/icons/file-earmark-binary.svg"
    },
    {
      "hash": "sha256-GBP7jN3/FH83kfiS2xUEOmsiFXrB19N2yMdDle22vrA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-break-fill.svg"
    },
    {
      "hash": "sha256-hP5BR2ZHXefkb6a0Zd/mUj6ajfUcgzA1EzGtp5u23uo=",
      "url": "lib/bootstrap-icons/icons/file-earmark-break.svg"
    },
    {
      "hash": "sha256-rYjxuGwM0DdQdwlcrDiU2i/rvdXPli8xbITGUEo1BqY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-check-fill.svg"
    },
    {
      "hash": "sha256-TuDCNOe2lJsjv0/2fNsW0z8oo/mNl4Vgp1c6Ls2L5nM=",
      "url": "lib/bootstrap-icons/icons/file-earmark-check.svg"
    },
    {
      "hash": "sha256-p11Q6nWHNC+Ko+44vH9bLTjHFM7XJ9bM4U1SQqlG+1I=",
      "url": "lib/bootstrap-icons/icons/file-earmark-code-fill.svg"
    },
    {
      "hash": "sha256-qywkkrfgg+xm4QGPyZJQu3BuG6ml1cgqoX65ts88UoE=",
      "url": "lib/bootstrap-icons/icons/file-earmark-code.svg"
    },
    {
      "hash": "sha256-VoL2ff0y10L4KVNpIEAYWogQxJ+pQYdAziVt3YcOJHc=",
      "url": "lib/bootstrap-icons/icons/file-earmark-diff-fill.svg"
    },
    {
      "hash": "sha256-s4hkAUtCASxQWzydMTeuCxuZWg1K5VQrQtg5QfgFpQA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-diff.svg"
    },
    {
      "hash": "sha256-ScxXMVVT+ChP+6M88dab8d1sypXUfz6fIooGHncZlu8=",
      "url": "lib/bootstrap-icons/icons/file-earmark-easel-fill.svg"
    },
    {
      "hash": "sha256-l6GkXrm9bnhMZj57ToNn4DUEUjBzIBbyP1fJvbXmJNU=",
      "url": "lib/bootstrap-icons/icons/file-earmark-easel.svg"
    },
    {
      "hash": "sha256-JqNKAiMJusMXA8mXRrXe9gVMV3oxsLA1Rpg80wulTlA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-excel-fill.svg"
    },
    {
      "hash": "sha256-7HbBztgSdeRgscld2+OyzypoWXVVT7YpShikS9jkTYY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-excel.svg"
    },
    {
      "hash": "sha256-qJqlNYTm2NzMSVN9LJyGRgdJo6y5Bq36Sq+yG9OApOg=",
      "url": "lib/bootstrap-icons/icons/file-earmark-fill.svg"
    },
    {
      "hash": "sha256-oNqQkDHCCn1sUxJly/i3mlpl9JKDoXbWRA+YbunPlNA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-font-fill.svg"
    },
    {
      "hash": "sha256-NJ765jSqpdHMIP5sXcvh5KRpu84gyhT6z45tbS0Zbec=",
      "url": "lib/bootstrap-icons/icons/file-earmark-font.svg"
    },
    {
      "hash": "sha256-pBtsi+arcDoftG9wgmfha3Dvk59FnTEiokWD5BiYyPU=",
      "url": "lib/bootstrap-icons/icons/file-earmark-image-fill.svg"
    },
    {
      "hash": "sha256-C0ijlif/r2mvf9tkNFMhNVoBj01cJIVJEA7uJ7x8nyE=",
      "url": "lib/bootstrap-icons/icons/file-earmark-image.svg"
    },
    {
      "hash": "sha256-OYbX2DqSLy4LByKoBvkRsPZxwZAPLjmUZ9C3Rypfn94=",
      "url": "lib/bootstrap-icons/icons/file-earmark-lock-fill.svg"
    },
    {
      "hash": "sha256-76vCfh5waOaJjEH7Qh96ioj0d1xtGrWFf3E8+OqVz+4=",
      "url": "lib/bootstrap-icons/icons/file-earmark-lock.svg"
    },
    {
      "hash": "sha256-9By7r/IQPYeRyjMiu6j7vEXN8okGlIagEUyZC+wM728=",
      "url": "lib/bootstrap-icons/icons/file-earmark-lock2-fill.svg"
    },
    {
      "hash": "sha256-Hpa9gAJ7Iui8IyDxCpWQkY72FpbMy7cKYFeAak6/d4I=",
      "url": "lib/bootstrap-icons/icons/file-earmark-lock2.svg"
    },
    {
      "hash": "sha256-7mFSXPHxROTyRV3V8c2YRp77au0TGjt42xWh5kFiGHU=",
      "url": "lib/bootstrap-icons/icons/file-earmark-medical-fill.svg"
    },
    {
      "hash": "sha256-Y2+GzSLqHebAaLgPtQteByvGYXW0eKnTam9Y8O8aP4o=",
      "url": "lib/bootstrap-icons/icons/file-earmark-medical.svg"
    },
    {
      "hash": "sha256-CVD8psysTfUOYaNtKyE40oUtLLSZ+7QMUWP5T77+yxw=",
      "url": "lib/bootstrap-icons/icons/file-earmark-minus-fill.svg"
    },
    {
      "hash": "sha256-9Mzzp52Ba/WVfgg73DN2Tvw68bA3FXFG3g9d7MX7mO0=",
      "url": "lib/bootstrap-icons/icons/file-earmark-minus.svg"
    },
    {
      "hash": "sha256-SjHxnNTpvSQGTx5ndr0lMyCSsFdf2pL7QHs7CZnwoTE=",
      "url": "lib/bootstrap-icons/icons/file-earmark-music-fill.svg"
    },
    {
      "hash": "sha256-sOaGheg5tvS4E/zYTmIJiYvgtwAu0lAiiOeIDvCrW9Q=",
      "url": "lib/bootstrap-icons/icons/file-earmark-music.svg"
    },
    {
      "hash": "sha256-srQwvhQhpz+X/GeHRLSjYxjgNVjgsQQ1/hsUAx1txq4=",
      "url": "lib/bootstrap-icons/icons/file-earmark-pdf-fill.svg"
    },
    {
      "hash": "sha256-6EITK5y+Qw7BnmoHL3Qp3tb8t5cAul2EnVNrlGqIBXA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-pdf.svg"
    },
    {
      "hash": "sha256-Z2sgRDVosc0ohNtF71BZDkfx+WshB5vCv0DpyE0na7o=",
      "url": "lib/bootstrap-icons/icons/file-earmark-person-fill.svg"
    },
    {
      "hash": "sha256-BSAXlNHeFBXGFf3Px9T4OMKtHy8uOWWULldvuwq15KU=",
      "url": "lib/bootstrap-icons/icons/file-earmark-person.svg"
    },
    {
      "hash": "sha256-a+lZ6IJfMHI3K+dlM0H6Bl0xLhPLXu+ZmVra8oFTCXM=",
      "url": "lib/bootstrap-icons/icons/file-earmark-play-fill.svg"
    },
    {
      "hash": "sha256-i1x8mvM/SIxvaXaphlyLh6ENJmP5UgB5Y/dbBKIyvdo=",
      "url": "lib/bootstrap-icons/icons/file-earmark-play.svg"
    },
    {
      "hash": "sha256-sP9hTfIROIQZN5KenuqEmpI1YEf+UD7wcVtt5UD1lSo=",
      "url": "lib/bootstrap-icons/icons/file-earmark-plus-fill.svg"
    },
    {
      "hash": "sha256-qbnYzbRl19cA0/42+L1PF9tcsFbvdyHs7y6gw4gbj38=",
      "url": "lib/bootstrap-icons/icons/file-earmark-plus.svg"
    },
    {
      "hash": "sha256-9jJd+GVG3pjs1QI377UVdv7qInWewV7oGFCQBRObu3A=",
      "url": "lib/bootstrap-icons/icons/file-earmark-post-fill.svg"
    },
    {
      "hash": "sha256-v4H1wm/lAuflkHb/0l727fH//SQy1CNWh/O/fNayJSY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-post.svg"
    },
    {
      "hash": "sha256-NjN3KNFbM2MhWIwJBnS1GRGbEYT/SaX+TBKf9sb1Q1M=",
      "url": "lib/bootstrap-icons/icons/file-earmark-ppt-fill.svg"
    },
    {
      "hash": "sha256-IdZwGlsTnDty7dMK/5eaLGKtGfLvA7Y3kvt18uBhCIc=",
      "url": "lib/bootstrap-icons/icons/file-earmark-ppt.svg"
    },
    {
      "hash": "sha256-uNkYyWB8yTfk+ZIdkW6wPkmfvbeIKn9gdu/rpB5DL5s=",
      "url": "lib/bootstrap-icons/icons/file-earmark-richtext-fill.svg"
    },
    {
      "hash": "sha256-/O9C+MZxNk4unV9PKzCRfd20DMutambOuBloNqteTkY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-richtext.svg"
    },
    {
      "hash": "sha256-MkJeZrvo3aSqb18e+EgqJMdh0xc3k3zg64oZoz26/34=",
      "url": "lib/bootstrap-icons/icons/file-earmark-ruled-fill.svg"
    },
    {
      "hash": "sha256-tBafL6QUikaMCl9mYaRYhi8TA/dwSbbC8rAp/hDEVoI=",
      "url": "lib/bootstrap-icons/icons/file-earmark-ruled.svg"
    },
    {
      "hash": "sha256-CksHmfAjXgx7bS2ePsMwOD0V59s1NS6za0i9NlE50WI=",
      "url": "lib/bootstrap-icons/icons/file-earmark-slides-fill.svg"
    },
    {
      "hash": "sha256-soY2lsOD4ewE+bzduSGhc4N9i/TDG70+A8ueH9/5YUo=",
      "url": "lib/bootstrap-icons/icons/file-earmark-slides.svg"
    },
    {
      "hash": "sha256-n9Atm5a4YcgZErgvvHvEBOBqXmbAG/K1Z3YPPWD0ols=",
      "url": "lib/bootstrap-icons/icons/file-earmark-spreadsheet-fill.svg"
    },
    {
      "hash": "sha256-+nEcNLTvlz3HGL+MOevpK0X/j5YafsJ25Wr5OWqPJIo=",
      "url": "lib/bootstrap-icons/icons/file-earmark-spreadsheet.svg"
    },
    {
      "hash": "sha256-5UAb2LHtr53UipYmQbXwFQUbdnSvpznsbDuRpXIV1Ww=",
      "url": "lib/bootstrap-icons/icons/file-earmark-text-fill.svg"
    },
    {
      "hash": "sha256-Ms+7HgycQWr0eGHo2UG58LVE8Ddf4tRg7NVDyJeohsM=",
      "url": "lib/bootstrap-icons/icons/file-earmark-text.svg"
    },
    {
      "hash": "sha256-HjWD1fsAmREonjDMYK4q+7HJgRcdf2sjSuRzTDMvI0I=",
      "url": "lib/bootstrap-icons/icons/file-earmark-word-fill.svg"
    },
    {
      "hash": "sha256-qh2FvuEY5+Qgjo983R/mfZlTGVR8bkOIAbcU378FMF4=",
      "url": "lib/bootstrap-icons/icons/file-earmark-word.svg"
    },
    {
      "hash": "sha256-0b933WP8esRHLW1ZVPILh3AkbV2vqwaroO7+oWntHHA=",
      "url": "lib/bootstrap-icons/icons/file-earmark-x-fill.svg"
    },
    {
      "hash": "sha256-CdeiisN9nEx/sf5XwyVn+qm0iwfgehQxfBapP+ZlJUY=",
      "url": "lib/bootstrap-icons/icons/file-earmark-x.svg"
    },
    {
      "hash": "sha256-Uiv1cOCxxl98FjRlz3GutHVeG6SpHOGAmIFOWWcvA+g=",
      "url": "lib/bootstrap-icons/icons/file-earmark-zip-fill.svg"
    },
    {
      "hash": "sha256-+RT0xEJ2Olb9FGbtWSgiyJgiPqXjbfqFKdJyXOtqZ3w=",
      "url": "lib/bootstrap-icons/icons/file-earmark-zip.svg"
    },
    {
      "hash": "sha256-LjUrcSKjcIoafifSZtU0xl5QPk0IEtBiHAwGKMykPk8=",
      "url": "lib/bootstrap-icons/icons/file-earmark.svg"
    },
    {
      "hash": "sha256-qpLN4en9VJpt7PHQ6kWA9DhBSH/Pbz1U79G2+jBVSWY=",
      "url": "lib/bootstrap-icons/icons/file-easel-fill.svg"
    },
    {
      "hash": "sha256-5ivYo+vV19EFoXVpfeTCz/PeJgEgJDuwGAXt3XdvbKY=",
      "url": "lib/bootstrap-icons/icons/file-easel.svg"
    },
    {
      "hash": "sha256-MUH6BSZTJggqIOJ52cWGu4eWV+bImdM0ovxmzFj9Grg=",
      "url": "lib/bootstrap-icons/icons/file-excel-fill.svg"
    },
    {
      "hash": "sha256-zc2J6MuOpa69OA854c/sxZzU5d4SSfhxnz7YIVlGxg0=",
      "url": "lib/bootstrap-icons/icons/file-excel.svg"
    },
    {
      "hash": "sha256-sRYsuuzrA8oMmaccJFmf+tQ6+uXU5DJpHt22AJg8HrY=",
      "url": "lib/bootstrap-icons/icons/file-fill.svg"
    },
    {
      "hash": "sha256-VZhHeC8rEeIUxXVpV/vSyFsQDuX7vl3JLDoJHRrn8tY=",
      "url": "lib/bootstrap-icons/icons/file-font-fill.svg"
    },
    {
      "hash": "sha256-PGhBctL132zss3PeJGWl0ComucGGqSzy2PZLN7du3CM=",
      "url": "lib/bootstrap-icons/icons/file-font.svg"
    },
    {
      "hash": "sha256-HPfI9J2f2eXEF1DPBBB6iHBCF/lO/kLu2Zp32NInev4=",
      "url": "lib/bootstrap-icons/icons/file-image-fill.svg"
    },
    {
      "hash": "sha256-NvjjaoyYmfZMuyB3jxgk7pkRPJukZM8RbHQ9s51lyr0=",
      "url": "lib/bootstrap-icons/icons/file-image.svg"
    },
    {
      "hash": "sha256-OyNwHjAmA7cKlIpDyN9OQE4GdCD9WIEj+NlTfYxeDFI=",
      "url": "lib/bootstrap-icons/icons/file-lock-fill.svg"
    },
    {
      "hash": "sha256-uijqg0EFBlsDpfMvfZvN3VYCAnwUiFmn1a9sxKp47Ys=",
      "url": "lib/bootstrap-icons/icons/file-lock.svg"
    },
    {
      "hash": "sha256-p7v2kmsR3XhDNtIJb4SNJN3cF3V3LGfTVT1QnxRQJlo=",
      "url": "lib/bootstrap-icons/icons/file-lock2-fill.svg"
    },
    {
      "hash": "sha256-/2EQ303tUcVcNPqLaYwk645aEyBtVI0PuR1SbdCXO/o=",
      "url": "lib/bootstrap-icons/icons/file-lock2.svg"
    },
    {
      "hash": "sha256-cRPN52DYCKPh503rFP4+4IE74+ZWee4saKJP3qLFFtA=",
      "url": "lib/bootstrap-icons/icons/file-medical-fill.svg"
    },
    {
      "hash": "sha256-JkBH6avpykcOD/0/G4eQi9/4eM0Qj1XMJ94+G+0NP78=",
      "url": "lib/bootstrap-icons/icons/file-medical.svg"
    },
    {
      "hash": "sha256-PNRq9uKvrbSyvo7aOJmRlcY2gSWiLJfTUzqiH0LgZQo=",
      "url": "lib/bootstrap-icons/icons/file-minus-fill.svg"
    },
    {
      "hash": "sha256-P28AgPK8n7TsihsVeKfqLngLO8OZ+eAx3ulSmtbSeDo=",
      "url": "lib/bootstrap-icons/icons/file-minus.svg"
    },
    {
      "hash": "sha256-c/VXPIlyPIZyjCQt3zXkxUGdnam+4/giSdSGy8e4SSg=",
      "url": "lib/bootstrap-icons/icons/file-music-fill.svg"
    },
    {
      "hash": "sha256-yCpZAifobBHR4V2tQ2tOK1T0saYPXm/V1gjQ0nyGJxw=",
      "url": "lib/bootstrap-icons/icons/file-music.svg"
    },
    {
      "hash": "sha256-gPgtHaJFu2HBcmbd1fLcGlNJRXKyDsN5XpBZBY9Vmuc=",
      "url": "lib/bootstrap-icons/icons/file-pdf-fill.svg"
    },
    {
      "hash": "sha256-cDqPt5RA+ih1rRIwIUCUWPzJ8SrLbMjR+PMKTU1d3RE=",
      "url": "lib/bootstrap-icons/icons/file-pdf.svg"
    },
    {
      "hash": "sha256-AR7IJJqB7vmgc1njJ93JChoppdbhzf1nbftdogx2Tas=",
      "url": "lib/bootstrap-icons/icons/file-person-fill.svg"
    },
    {
      "hash": "sha256-yrrYEWq7iTxSSX73LwntSNpOZuu5u/fxhAkdogg30io=",
      "url": "lib/bootstrap-icons/icons/file-person.svg"
    },
    {
      "hash": "sha256-m+3KiKumsR9ntDK0zJZPQj38Hz77UoVmb5oPKVXxMQA=",
      "url": "lib/bootstrap-icons/icons/file-play-fill.svg"
    },
    {
      "hash": "sha256-flWK2oAuxQ6p1T57fnL2Zus0p+X5TQwKEG/GOEixFgc=",
      "url": "lib/bootstrap-icons/icons/file-play.svg"
    },
    {
      "hash": "sha256-MQ64fN+0H5MeYH7inRHU0yEmd7TBTsI7U6cjjXrPLEE=",
      "url": "lib/bootstrap-icons/icons/file-plus-fill.svg"
    },
    {
      "hash": "sha256-QyhHNmG8x4tWYf5r7WRkbd7X8cFTuKEnzc/QKtCjIkE=",
      "url": "lib/bootstrap-icons/icons/file-plus.svg"
    },
    {
      "hash": "sha256-7pxh4ESB9L+E8H+prwRpX7x8fhXe93nvGsUwuE7LEPs=",
      "url": "lib/bootstrap-icons/icons/file-post-fill.svg"
    },
    {
      "hash": "sha256-Bo5Wo+7Syx1D8mFAnLTmp3vQZE11qCDfaYRtyaf5jis=",
      "url": "lib/bootstrap-icons/icons/file-post.svg"
    },
    {
      "hash": "sha256-bICM+Qe2gdM+RkftCcYhHeMhlh7SDYcJkqYnhdjDcok=",
      "url": "lib/bootstrap-icons/icons/file-ppt-fill.svg"
    },
    {
      "hash": "sha256-wsFNMpzLLdVsjqJfln6pEW8bgb8M94fOKsbFrE2ab9s=",
      "url": "lib/bootstrap-icons/icons/file-ppt.svg"
    },
    {
      "hash": "sha256-6B4nUj4l8bsd5Z/H29SlIrVvgFu4wcpWdGtRRBM7RVg=",
      "url": "lib/bootstrap-icons/icons/file-richtext-fill.svg"
    },
    {
      "hash": "sha256-nAXJieG/mGBJpWfqtePUaTMk9notRRiOKaQm9TAfWaQ=",
      "url": "lib/bootstrap-icons/icons/file-richtext.svg"
    },
    {
      "hash": "sha256-eYiv7oX3mp4K7efJ6G4J5ppo3PwonKMjtSMYcFhJcaM=",
      "url": "lib/bootstrap-icons/icons/file-ruled-fill.svg"
    },
    {
      "hash": "sha256-LSGRvyda+A3CVj6J9CzjP5wQN2MjQpjfdqhwRu7s3OA=",
      "url": "lib/bootstrap-icons/icons/file-ruled.svg"
    },
    {
      "hash": "sha256-KyzAfxMwFeTWftplPeIaaSRRLfpzhZwE6823zORpyhA=",
      "url": "lib/bootstrap-icons/icons/file-slides-fill.svg"
    },
    {
      "hash": "sha256-zCZAH2QoGlnwZXUNbf2faUWQ9lDnUmTf60Wh52koH9g=",
      "url": "lib/bootstrap-icons/icons/file-slides.svg"
    },
    {
      "hash": "sha256-ihplhemCNrKAXFJdRu/6ZrHtINQ+HsaEcW9c/nlakvU=",
      "url": "lib/bootstrap-icons/icons/file-spreadsheet-fill.svg"
    },
    {
      "hash": "sha256-KoDTdoSnSQ2E1FWs1pWpAlsLDi8IbbAggV4vCssxGo8=",
      "url": "lib/bootstrap-icons/icons/file-spreadsheet.svg"
    },
    {
      "hash": "sha256-4KuzeO3NmYrZJNMg+aY2iKuCwSe/rW9nLHdtdFnBaDs=",
      "url": "lib/bootstrap-icons/icons/file-text-fill.svg"
    },
    {
      "hash": "sha256-q8+/e7uXfe/L8SFYEffOxrh4qByMM7ZpaGmU1qj2gNY=",
      "url": "lib/bootstrap-icons/icons/file-text.svg"
    },
    {
      "hash": "sha256-OYSLPACFv9S8sRipozEWe79/3hMCfGFOfBQEt7dCyBs=",
      "url": "lib/bootstrap-icons/icons/file-word-fill.svg"
    },
    {
      "hash": "sha256-8CtvCn9p75+yjf3S0ArgS2KUceoG0q4cDwCXtJJ3ZNw=",
      "url": "lib/bootstrap-icons/icons/file-word.svg"
    },
    {
      "hash": "sha256-q1BAoY5lcee1449vCkVfg4slirXAXQ42JPFkwPPo8fE=",
      "url": "lib/bootstrap-icons/icons/file-x-fill.svg"
    },
    {
      "hash": "sha256-2Xd9q+hoK6in34Th9nrzig3koPWe7HNFN8eliq1PXS8=",
      "url": "lib/bootstrap-icons/icons/file-x.svg"
    },
    {
      "hash": "sha256-tk13m/tu4DhwmBVsfU84kZvI40zZP0pBNS3RE36HzKA=",
      "url": "lib/bootstrap-icons/icons/file-zip-fill.svg"
    },
    {
      "hash": "sha256-5pDlfSmBWfzZKZjG2ppDEsv3via/pjawGWdItqYM6oc=",
      "url": "lib/bootstrap-icons/icons/file-zip.svg"
    },
    {
      "hash": "sha256-yMTJ+lSgz9t3y1EdPrzo0dorkGuL67Juh9Ye00KGTr8=",
      "url": "lib/bootstrap-icons/icons/file.svg"
    },
    {
      "hash": "sha256-n00XPzozEoDF25E9GphvMnUSnEtafIrxh57nnUSuKhw=",
      "url": "lib/bootstrap-icons/icons/files-alt.svg"
    },
    {
      "hash": "sha256-hA/2frellJuyFhO2ukxukQdWxF4sJi4ft3K169V7FmE=",
      "url": "lib/bootstrap-icons/icons/files.svg"
    },
    {
      "hash": "sha256-VLJlphQqF0iCLMZsjG4fzYcj4lQm7CCqTvy1rkqB1oc=",
      "url": "lib/bootstrap-icons/icons/filetype-aac.svg"
    },
    {
      "hash": "sha256-ljWL8v0yEbtxRMsEqV1aW62+TNKXgKJIx79DJsL7nUU=",
      "url": "lib/bootstrap-icons/icons/filetype-ai.svg"
    },
    {
      "hash": "sha256-O9UnYqDYLf/cHbu9uTIF9Fq6csRFKvVXkG8RjU46Tk8=",
      "url": "lib/bootstrap-icons/icons/filetype-bmp.svg"
    },
    {
      "hash": "sha256-RU+kUi2FmLYyX1ZtNdSoD4a5EDsgHwL1nErRiFuzJ4Y=",
      "url": "lib/bootstrap-icons/icons/filetype-cs.svg"
    },
    {
      "hash": "sha256-9smfASuA0mK/rAxoqPw+Q14U9IDAGbCDhsMh/FhYaDo=",
      "url": "lib/bootstrap-icons/icons/filetype-css.svg"
    },
    {
      "hash": "sha256-EryXHzwvxu1VegGzOLDowJLa6hP2nAw9Xa4RagW3NkQ=",
      "url": "lib/bootstrap-icons/icons/filetype-csv.svg"
    },
    {
      "hash": "sha256-iv1lSAkbevJSW3O0qKwYXVoEIy4hMUCT1fU4DoDKEIU=",
      "url": "lib/bootstrap-icons/icons/filetype-doc.svg"
    },
    {
      "hash": "sha256-sNcLb7ZSwK3X44MhIzUyURsEHSiqcOfr3rkqiqPYxpU=",
      "url": "lib/bootstrap-icons/icons/filetype-docx.svg"
    },
    {
      "hash": "sha256-dGzFJzac74PKlkILAEaVhsIGGisKFrpDl4PUOLQp6L8=",
      "url": "lib/bootstrap-icons/icons/filetype-exe.svg"
    },
    {
      "hash": "sha256-Q6QsMZd4fEHRQf2ZTF3DHFfKuZnEojcjerOwBsnB1+E=",
      "url": "lib/bootstrap-icons/icons/filetype-gif.svg"
    },
    {
      "hash": "sha256-Yk/xr8oxNwhyCX+KdRIGca4G/DbN5cJSekumIq+HvCw=",
      "url": "lib/bootstrap-icons/icons/filetype-heic.svg"
    },
    {
      "hash": "sha256-3NGzvNGq8qAl/QGNHU5NHjCxNGipdpg00Evql17SBYw=",
      "url": "lib/bootstrap-icons/icons/filetype-html.svg"
    },
    {
      "hash": "sha256-RhAmqj49A9gPjeaiy+xTF4895bhB+SETGnCzCPYDXAQ=",
      "url": "lib/bootstrap-icons/icons/filetype-java.svg"
    },
    {
      "hash": "sha256-aHUEqjD4OFe3kR6Em2ghc7WMvILEr+Fv4szahYjMTr8=",
      "url": "lib/bootstrap-icons/icons/filetype-jpg.svg"
    },
    {
      "hash": "sha256-YD1ua8iMVVQB6ps/Grgcg7jz9AguDNOGJClvWKeLQVQ=",
      "url": "lib/bootstrap-icons/icons/filetype-js.svg"
    },
    {
      "hash": "sha256-ULX5qvO9uzePuVpZ6R5JoYYtFSoT8CxW7ubwbDcVFvY=",
      "url": "lib/bootstrap-icons/icons/filetype-json.svg"
    },
    {
      "hash": "sha256-xhh1OAgOUS8nskYgWQckYB6jMd24EocZVTGOp70dtLA=",
      "url": "lib/bootstrap-icons/icons/filetype-jsx.svg"
    },
    {
      "hash": "sha256-rIfNY5DByLYs4cPsLcbckOoLcDDIssnDZIkrQqJ7T1Q=",
      "url": "lib/bootstrap-icons/icons/filetype-key.svg"
    },
    {
      "hash": "sha256-lKwOjlI9AksVKpsAd5NqKrCCBNXM8z+vi8dnV5R/b94=",
      "url": "lib/bootstrap-icons/icons/filetype-m4p.svg"
    },
    {
      "hash": "sha256-rmUOJ6y7vnYfIAfDReR6z+6opnzSzw554XuB5N8UXl0=",
      "url": "lib/bootstrap-icons/icons/filetype-md.svg"
    },
    {
      "hash": "sha256-5YWL1eufKIB5HSnHxxbJ/dq+iWiELx8Hk3xTX/FWL4U=",
      "url": "lib/bootstrap-icons/icons/filetype-mdx.svg"
    },
    {
      "hash": "sha256-jMWnAxzrFdsjTrVBFXVdzj/A/TH2xiHAx4FQ6p7mUWk=",
      "url": "lib/bootstrap-icons/icons/filetype-mov.svg"
    },
    {
      "hash": "sha256-WxvuomNkBEiR+uUnphqLdLByLQOIl384FSZhOswuTPE=",
      "url": "lib/bootstrap-icons/icons/filetype-mp3.svg"
    },
    {
      "hash": "sha256-wCPT5B19iWQAVprSeTDvy95XfHGk6lM6xLzO8FUQDEw=",
      "url": "lib/bootstrap-icons/icons/filetype-mp4.svg"
    },
    {
      "hash": "sha256-EKPJ0NrpTKnRfelLz/3br2y3EOh3mvvrb7XFe1ey93c=",
      "url": "lib/bootstrap-icons/icons/filetype-otf.svg"
    },
    {
      "hash": "sha256-5eSuFTDSToTSoh/buhfGIF+NvSKfNJSIkLbZIdUFI9U=",
      "url": "lib/bootstrap-icons/icons/filetype-pdf.svg"
    },
    {
      "hash": "sha256-kMKZ0Jkp9yFp7vHR19yvtcGVp3O8fap4xcJ53bRk+Xs=",
      "url": "lib/bootstrap-icons/icons/filetype-php.svg"
    },
    {
      "hash": "sha256-B/4MQd9pr4/EFzJIDo2xLroqDvz1JIPVyoq/LREmxSE=",
      "url": "lib/bootstrap-icons/icons/filetype-png.svg"
    },
    {
      "hash": "sha256-LdHD2epTRyIZ+Tuo5ULQqizVEP4QxdP8pLEiwjBZ3UQ=",
      "url": "lib/bootstrap-icons/icons/filetype-ppt.svg"
    },
    {
      "hash": "sha256-pJ/Bul2k38XFxQlomICw4moPAszUIPiASjMSOSWXonY=",
      "url": "lib/bootstrap-icons/icons/filetype-pptx.svg"
    },
    {
      "hash": "sha256-Ir2uDxMxmot330Jy4ir+uyLf3WO75OgX4fBMAcEAqR0=",
      "url": "lib/bootstrap-icons/icons/filetype-psd.svg"
    },
    {
      "hash": "sha256-iHCXHrifiOF9MVCBMWHsV6z0lcEhNv2rynC+8jHxg0A=",
      "url": "lib/bootstrap-icons/icons/filetype-py.svg"
    },
    {
      "hash": "sha256-PW6FS70K+j3U/SwRVs27fbIpZAKVk2NhCV+FwmX9e8s=",
      "url": "lib/bootstrap-icons/icons/filetype-raw.svg"
    },
    {
      "hash": "sha256-I/DDbb7CFw0MccxklDwCJEJ0285mDt9ZlEN7gveuvaQ=",
      "url": "lib/bootstrap-icons/icons/filetype-rb.svg"
    },
    {
      "hash": "sha256-iZ4nA1zDI/HBQs6A0zEvphh8NCaJUwSKMZE4ekzh1Oo=",
      "url": "lib/bootstrap-icons/icons/filetype-sass.svg"
    },
    {
      "hash": "sha256-lGALgeX4v7GuqG5h35u0h0yGTQCiXj9mUmmTCPS4I6g=",
      "url": "lib/bootstrap-icons/icons/filetype-scss.svg"
    },
    {
      "hash": "sha256-3R8CZIClskzspL6zCK1jIVqdKPc7ievGGqS+7e36vjI=",
      "url": "lib/bootstrap-icons/icons/filetype-sh.svg"
    },
    {
      "hash": "sha256-6dYcKP9fK3W7uc2+8B/ggqad5hiM7UWuSW364+WlH+Q=",
      "url": "lib/bootstrap-icons/icons/filetype-sql.svg"
    },
    {
      "hash": "sha256-dTshivY6G6Xx9q+0PEQVipHlDfKZZdKZesXYp71bSvg=",
      "url": "lib/bootstrap-icons/icons/filetype-svg.svg"
    },
    {
      "hash": "sha256-0Y/YLpEpMk3BZ/1pGEdHI9Cz5+f00rIANdZvnlqUGIw=",
      "url": "lib/bootstrap-icons/icons/filetype-tiff.svg"
    },
    {
      "hash": "sha256-1n+x1vz0FodzEvlfGElZedPQV/RJVUKo0SYkFAEK+Mk=",
      "url": "lib/bootstrap-icons/icons/filetype-tsx.svg"
    },
    {
      "hash": "sha256-2FmintlFxYBnqUrfriWl4lvMugvtjOLjHnUxslZ5uhU=",
      "url": "lib/bootstrap-icons/icons/filetype-ttf.svg"
    },
    {
      "hash": "sha256-8tOV6BccN/fmPjHB26GHK5+zwHi5R+J70DtxNrj86T4=",
      "url": "lib/bootstrap-icons/icons/filetype-txt.svg"
    },
    {
      "hash": "sha256-bYaadUuc2hk0JL1W40Cy5+bwxO24jRDR6LBAxB8u3F4=",
      "url": "lib/bootstrap-icons/icons/filetype-wav.svg"
    },
    {
      "hash": "sha256-oPWsW75cncD6NZJ2e0lopOVlKG+0YagY9egC5OK6drQ=",
      "url": "lib/bootstrap-icons/icons/filetype-woff.svg"
    },
    {
      "hash": "sha256-A7/sme++iWQ73tdMF4RWsA1lDc25okBMp84KX5TdmCM=",
      "url": "lib/bootstrap-icons/icons/filetype-xls.svg"
    },
    {
      "hash": "sha256-Hv+kd2MQ/9osGED92n5iosk958IP9ZBD+LUNmEAkrSo=",
      "url": "lib/bootstrap-icons/icons/filetype-xlsx.svg"
    },
    {
      "hash": "sha256-7WKmYQhPFgrD0/S5nKLKRkN8bKHHk/PfYXwR46yviKU=",
      "url": "lib/bootstrap-icons/icons/filetype-xml.svg"
    },
    {
      "hash": "sha256-ZLCBR628SVM6epB/5ANDgMe/ri9bBTOH41VS6rN0GFQ=",
      "url": "lib/bootstrap-icons/icons/filetype-yml.svg"
    },
    {
      "hash": "sha256-F5XOcYzJT8JDpC2U0Oavl1SrEgjpE4fgf8UeTTpYzGE=",
      "url": "lib/bootstrap-icons/icons/film.svg"
    },
    {
      "hash": "sha256-bKRr04fbnffjTQ2NCm0tZq4PyEItFFf1NTARYH89EMg=",
      "url": "lib/bootstrap-icons/icons/filter-circle-fill.svg"
    },
    {
      "hash": "sha256-LU6NmamI3OS3hwKY+OIPqwDdkroM9ZhCDNmxuJcghD8=",
      "url": "lib/bootstrap-icons/icons/filter-circle.svg"
    },
    {
      "hash": "sha256-mmhh7l4Ry0oS1E48Z1/aoVHLBsnnJp/pjLtxCkgj3Fg=",
      "url": "lib/bootstrap-icons/icons/filter-left.svg"
    },
    {
      "hash": "sha256-g1ITtHBvjw69AKM8fcaPAfz6xbt76QFvEtuBV8iUo88=",
      "url": "lib/bootstrap-icons/icons/filter-right.svg"
    },
    {
      "hash": "sha256-8S4XS9Qv3PTZXWkgCi6QES9BKBkhy4BpDzkEHzfMx8k=",
      "url": "lib/bootstrap-icons/icons/filter-square-fill.svg"
    },
    {
      "hash": "sha256-2ctR0ptWvvEkIxEhvjIsSLw/DwfQ9tAvod5d1RFGLc4=",
      "url": "lib/bootstrap-icons/icons/filter-square.svg"
    },
    {
      "hash": "sha256-reYDbxl2PffC+x+4Ltq4YV7Jgl1v5mjWEXTBkrwYHlw=",
      "url": "lib/bootstrap-icons/icons/filter.svg"
    },
    {
      "hash": "sha256-ToYiSP+jWBNjcWzrh7KHAk6swe3esA4YNAVA3i5a4YU=",
      "url": "lib/bootstrap-icons/icons/fingerprint.svg"
    },
    {
      "hash": "sha256-7rCOPMvYPMejfvd1FK/FvBDM177ZaolTJlfHcw87JW0=",
      "url": "lib/bootstrap-icons/icons/fire.svg"
    },
    {
      "hash": "sha256-MGVeyG14hWBgpLmIJ5rcg1vKwmydyY+6IFJtkoBa9is=",
      "url": "lib/bootstrap-icons/icons/flag-fill.svg"
    },
    {
      "hash": "sha256-q3nFtE0iuFAkLBoBy03fXCR0yFiT4Kn69kAjYyExxgI=",
      "url": "lib/bootstrap-icons/icons/flag.svg"
    },
    {
      "hash": "sha256-iKD8nOoZpdFo1JuTmU3fV9ljatvX58MoLr2vEUao8X8=",
      "url": "lib/bootstrap-icons/icons/floppy-fill.svg"
    },
    {
      "hash": "sha256-uE1BKtnm++WhUdOzKp+Zeummg2+B4ll9zWkr4eVYvS8=",
      "url": "lib/bootstrap-icons/icons/floppy.svg"
    },
    {
      "hash": "sha256-gqP3uRx8vm/KKaPcKCjESo4JihcgZuXYkl2EM8eK+/Q=",
      "url": "lib/bootstrap-icons/icons/floppy2-fill.svg"
    },
    {
      "hash": "sha256-v/8nZWiOJyRo91/qXJOHP2dM6ucisIRURTjI5hhI/u8=",
      "url": "lib/bootstrap-icons/icons/floppy2.svg"
    },
    {
      "hash": "sha256-saUsXx4GL7QT1E8HtVS/D6oIfC9opa7emni6he6Skss=",
      "url": "lib/bootstrap-icons/icons/flower1.svg"
    },
    {
      "hash": "sha256-G9CcHcHgqSPO6A/ZQopilxGv/a2UQaAfgFykW5cFpKk=",
      "url": "lib/bootstrap-icons/icons/flower2.svg"
    },
    {
      "hash": "sha256-NkQo0RM5ZwhwgDPY4peTVLa1uFTmVyoy/Ff+MLsCryA=",
      "url": "lib/bootstrap-icons/icons/flower3.svg"
    },
    {
      "hash": "sha256-DGxPv/QKDo/vneimTob53UlMsc8r/cU7HYA9aVH5VRI=",
      "url": "lib/bootstrap-icons/icons/folder-check.svg"
    },
    {
      "hash": "sha256-cs+ZL8C7z0KVrnONyHGvKlaMiA4kM23k1pXLC3CWoAQ=",
      "url": "lib/bootstrap-icons/icons/folder-fill.svg"
    },
    {
      "hash": "sha256-mXiXE9ukmaRZnjq6fFPpqI0okc+SiPZuTVnvGfWZo6k=",
      "url": "lib/bootstrap-icons/icons/folder-minus.svg"
    },
    {
      "hash": "sha256-0Wz+z5jLTLeAAH1KRRG+kFzrdszNgRjJsZ8q8E61SGY=",
      "url": "lib/bootstrap-icons/icons/folder-plus.svg"
    },
    {
      "hash": "sha256-sYfuJWoo/kMAIImAt//o1By6f3wJUbuMHhRLWI8wJrY=",
      "url": "lib/bootstrap-icons/icons/folder-symlink-fill.svg"
    },
    {
      "hash": "sha256-IV0/ss1+BPlB95nhVRzDnUapWtrEygBGDulyWSMLxsc=",
      "url": "lib/bootstrap-icons/icons/folder-symlink.svg"
    },
    {
      "hash": "sha256-emQsPNff4Wo8TpsohY7gXt7UAlKmoQuMHe5Wnbnnvvc=",
      "url": "lib/bootstrap-icons/icons/folder-x.svg"
    },
    {
      "hash": "sha256-6aPG5Gc+NH0ra346ZccFgCVg2s15pYQ2WhujFkaTYuc=",
      "url": "lib/bootstrap-icons/icons/folder.svg"
    },
    {
      "hash": "sha256-+9OltDbI0xnswalVPVTkYBLGIhSJz3nAojAel9Fepqc=",
      "url": "lib/bootstrap-icons/icons/folder2-open.svg"
    },
    {
      "hash": "sha256-k1sJfTG+F4TSMpTv3OcTJy84jrxrrvzdp76aJ9W0dJI=",
      "url": "lib/bootstrap-icons/icons/folder2.svg"
    },
    {
      "hash": "sha256-KQZw/tbcX317Z2DN6aGVWJsHQaSCf4zpn2CVnChDOiw=",
      "url": "lib/bootstrap-icons/icons/fonts.svg"
    },
    {
      "hash": "sha256-3N5pcJftquip2GFT4dg8dO7V+rJtOU2L8MlV8sTlGRw=",
      "url": "lib/bootstrap-icons/icons/forward-fill.svg"
    },
    {
      "hash": "sha256-3aV0FwbloKKUJSwpfbiC/yuHjvVo8UB4IPW/x+lUoj0=",
      "url": "lib/bootstrap-icons/icons/forward.svg"
    },
    {
      "hash": "sha256-nwxHFZxq51dsI732FH+cdCBwA5ZzKr7qNeAfkfrc7xA=",
      "url": "lib/bootstrap-icons/icons/front.svg"
    },
    {
      "hash": "sha256-WpwrOMetduCLB9aCr8xEFyoe6loz9WmyROeEslNogNQ=",
      "url": "lib/bootstrap-icons/icons/fuel-pump-diesel-fill.svg"
    },
    {
      "hash": "sha256-7QCpR1Hkuvq8qtoWo7EfMYef97P+HqspbLRpmZ+cWMA=",
      "url": "lib/bootstrap-icons/icons/fuel-pump-diesel.svg"
    },
    {
      "hash": "sha256-7NXyKkpJK1l0BJPBVw1P0OlZldOsSVabjQGzolCE2UY=",
      "url": "lib/bootstrap-icons/icons/fuel-pump-fill.svg"
    },
    {
      "hash": "sha256-ll1CEB2aDs4hv0KRn08lKvsfaqH8UmqAaW0pD6vM84s=",
      "url": "lib/bootstrap-icons/icons/fuel-pump.svg"
    },
    {
      "hash": "sha256-XmzC/RsgFYhLmU9Ch5PlMKpHAcsFcEtvkYuwYTTygnQ=",
      "url": "lib/bootstrap-icons/icons/fullscreen-exit.svg"
    },
    {
      "hash": "sha256-Wm5Hy/qwL/HJy3yk3Si4qBJKByJmWVv+Bv0QStiP4WA=",
      "url": "lib/bootstrap-icons/icons/fullscreen.svg"
    },
    {
      "hash": "sha256-czFj3RifvmWQiRJA3iPm1h2q2mA4W1IHJTCxbn3YpIY=",
      "url": "lib/bootstrap-icons/icons/funnel-fill.svg"
    },
    {
      "hash": "sha256-7+srQZVk4VDiPyiJcfGbEN8cVAIJM/E2EiqQrHQJK84=",
      "url": "lib/bootstrap-icons/icons/funnel.svg"
    },
    {
      "hash": "sha256-PyRael6iukT4JawD644HHS5Qh0bdtDui1FetO9o8t0k=",
      "url": "lib/bootstrap-icons/icons/gear-fill.svg"
    },
    {
      "hash": "sha256-lysQB+sW/Y8vvmWOvHkDztW1YcPoBV8gaPJgMRfDqwQ=",
      "url": "lib/bootstrap-icons/icons/gear-wide-connected.svg"
    },
    {
      "hash": "sha256-Fn6RVNQTF72fRW/SDx2ZQgJxrghQw/y2zDsr2+b/HlA=",
      "url": "lib/bootstrap-icons/icons/gear-wide.svg"
    },
    {
      "hash": "sha256-r9vQjDKQBKlB3I0RKT5FP9Rz7IQ859nHZDo+pItly8I=",
      "url": "lib/bootstrap-icons/icons/gear.svg"
    },
    {
      "hash": "sha256-SAmDrzqNpzeSCoFJHuqUpdM4uB8Lj8rymrfxtc16sSo=",
      "url": "lib/bootstrap-icons/icons/gem.svg"
    },
    {
      "hash": "sha256-YgMxeVDK43O0BF8bZX7cj2falWOagb4qX5oQLh7cRzg=",
      "url": "lib/bootstrap-icons/icons/gender-ambiguous.svg"
    },
    {
      "hash": "sha256-8eMJfQzGm7gfICa6htI738R26r20ab8MeI7W9P9vgcs=",
      "url": "lib/bootstrap-icons/icons/gender-female.svg"
    },
    {
      "hash": "sha256-jrc9VmURuzH00idSGWO1cMw5CLIhZu8d8TNoeS8SXIs=",
      "url": "lib/bootstrap-icons/icons/gender-male.svg"
    },
    {
      "hash": "sha256-mSUAWbgsK8fqjbu9VpJso1f9YG7Cl9//hT/UJLUU0Fo=",
      "url": "lib/bootstrap-icons/icons/gender-neuter.svg"
    },
    {
      "hash": "sha256-6i5l4BgSqEfn4cGQPUd4O7OP2bOjVmJNzS8/PAUEJNc=",
      "url": "lib/bootstrap-icons/icons/gender-trans.svg"
    },
    {
      "hash": "sha256-olSyp9uztk5xkb94RcNHRLdsrp65eomA9HRt+Hvdldg=",
      "url": "lib/bootstrap-icons/icons/geo-alt-fill.svg"
    },
    {
      "hash": "sha256-0NafX1Mk7OPCPUTYvg4ESWxjRr7LOZe2dS0RAiT375Y=",
      "url": "lib/bootstrap-icons/icons/geo-alt.svg"
    },
    {
      "hash": "sha256-1vdH26/ZkakrqyZM9y42KTsh21iZ/Q9MXeAOhGalWDI=",
      "url": "lib/bootstrap-icons/icons/geo-fill.svg"
    },
    {
      "hash": "sha256-VXoCmJPm4OO7V0E4H/9Lt9NY0es5Q01kKqxA8jQmJ8I=",
      "url": "lib/bootstrap-icons/icons/geo.svg"
    },
    {
      "hash": "sha256-IuNKQcqr5HsHg4OUoip5sFWQhFdxG8IRm9ADh28CH9c=",
      "url": "lib/bootstrap-icons/icons/gift-fill.svg"
    },
    {
      "hash": "sha256-NVXeaur8IpNpuqvk213GxGqiw009my9e0RrA+vXFUz8=",
      "url": "lib/bootstrap-icons/icons/gift.svg"
    },
    {
      "hash": "sha256-vjmP2HJZdKME/CxxcBId0WO0NyIgIuFea47vUXMwXTc=",
      "url": "lib/bootstrap-icons/icons/git.svg"
    },
    {
      "hash": "sha256-XzfVfGuEeqRvhnt9MMPFl41T/XCuufzWNUQfai/0ECw=",
      "url": "lib/bootstrap-icons/icons/github.svg"
    },
    {
      "hash": "sha256-B8WZRvjaaM/Qvh5bcTsQ2gBnMqWsAjjIKijnOinCF40=",
      "url": "lib/bootstrap-icons/icons/gitlab.svg"
    },
    {
      "hash": "sha256-kp5fBk0kiAKCntP6VIYn3GIxt6QEU8D4ghWC6w56Uqg=",
      "url": "lib/bootstrap-icons/icons/globe-americas.svg"
    },
    {
      "hash": "sha256-GzTc6IDjtEcN5B+m42aQJXL4UDoH1cZ2a9vXKdl4UGg=",
      "url": "lib/bootstrap-icons/icons/globe-asia-australia.svg"
    },
    {
      "hash": "sha256-15AJoSj6xkyem7YCmz0tZQSv5Et9H/6SnUdBepoOrQM=",
      "url": "lib/bootstrap-icons/icons/globe-central-south-asia.svg"
    },
    {
      "hash": "sha256-YlSvTj7egU3hW+nUKmAkaJyj/yApiapldX8yq932lkY=",
      "url": "lib/bootstrap-icons/icons/globe-europe-africa.svg"
    },
    {
      "hash": "sha256-eCQab6GfZOOPwkS72Fo6XHijMipO+ylIUuhW+BW8HNE=",
      "url": "lib/bootstrap-icons/icons/globe.svg"
    },
    {
      "hash": "sha256-Y9hObSZB7eT23yO6YCunbEnsv9vcfyoz6qSDoGeiyug=",
      "url": "lib/bootstrap-icons/icons/globe2.svg"
    },
    {
      "hash": "sha256-FHDOpjJS2Mc4XJsSJWK2rUG7U3eNOzQEVC0Nzh74brY=",
      "url": "lib/bootstrap-icons/icons/google-play.svg"
    },
    {
      "hash": "sha256-o9BCmr7C3uF9k2yGLhNtmtcZLIYYDAwCj/5DDOWkK4Y=",
      "url": "lib/bootstrap-icons/icons/google.svg"
    },
    {
      "hash": "sha256-816O5HxWnxk5JyDGtGvDzH1THYEr7H6r1FXwHzHYfGQ=",
      "url": "lib/bootstrap-icons/icons/gpu-card.svg"
    },
    {
      "hash": "sha256-Gq/80B9Xrs1G+Ky//eVJiVPbF12A91H8cBjAfl+nFIg=",
      "url": "lib/bootstrap-icons/icons/graph-down-arrow.svg"
    },
    {
      "hash": "sha256-a0FaP9EXCaf7j8eus8eC8KNFR7sZ38s6EJvGNxLv87E=",
      "url": "lib/bootstrap-icons/icons/graph-down.svg"
    },
    {
      "hash": "sha256-303sry/i41jABqJAE0BO4y0A2rQQT08rNTvflAl0R3U=",
      "url": "lib/bootstrap-icons/icons/graph-up-arrow.svg"
    },
    {
      "hash": "sha256-hFGgRIHLq54Bwhadi4bx+E1F5X4GwGksOpDBZHc6xKM=",
      "url": "lib/bootstrap-icons/icons/graph-up.svg"
    },
    {
      "hash": "sha256-DMwWvpFZrE5e5/u18wdvL3F3x7FVzaDNqNVcX7GUg2I=",
      "url": "lib/bootstrap-icons/icons/grid-1x2-fill.svg"
    },
    {
      "hash": "sha256-DhGOGm/YKVDlHBTCkGHilNKE8RBpnjMTCwB6OdBN0jQ=",
      "url": "lib/bootstrap-icons/icons/grid-1x2.svg"
    },
    {
      "hash": "sha256-+J35hQDJVvhdpaDyvCRABDU3Mwsg/gF4X7yKk046G/U=",
      "url": "lib/bootstrap-icons/icons/grid-3x2-gap-fill.svg"
    },
    {
      "hash": "sha256-6HN4/HgpOIaXNQ/tAOMVzC7d1yOa3hnJGhjamc+WX/s=",
      "url": "lib/bootstrap-icons/icons/grid-3x2-gap.svg"
    },
    {
      "hash": "sha256-6s1r9kjncZnVMM/DAbVpX5rsRHLcbXQ1zApl08sHyP0=",
      "url": "lib/bootstrap-icons/icons/grid-3x2.svg"
    },
    {
      "hash": "sha256-nHOq2yUOJC2W2Zdi+OpAnSbK4FWDQYqhfAP5lnZMoHA=",
      "url": "lib/bootstrap-icons/icons/grid-3x3-gap-fill.svg"
    },
    {
      "hash": "sha256-rJ1NPaRq/TqxSssLvjkGaYB9SGEgprz/KobDAA3vBOQ=",
      "url": "lib/bootstrap-icons/icons/grid-3x3-gap.svg"
    },
    {
      "hash": "sha256-3gWdyDse9VGau1tx3UyRw+QJ+Dt4R1+RE/pCPoQOd2c=",
      "url": "lib/bootstrap-icons/icons/grid-3x3.svg"
    },
    {
      "hash": "sha256-fy9Wz7n4Hq8d4OHfU2CyF7HfmSPFuFpxkKpMUWXyxAc=",
      "url": "lib/bootstrap-icons/icons/grid-fill.svg"
    },
    {
      "hash": "sha256-ec/CvaWT5/uR5Y1HjzSTPRbEN8rAaIpOg3hmILN16mY=",
      "url": "lib/bootstrap-icons/icons/grid.svg"
    },
    {
      "hash": "sha256-Nsxq1DWg2Hxe5Cg3MkW2rRf/p+LIn3lCAC0bIEgKTQU=",
      "url": "lib/bootstrap-icons/icons/grip-horizontal.svg"
    },
    {
      "hash": "sha256-9rXism81LcupZE1e3l6afeQUGaRZHZwEHelplOZJyeE=",
      "url": "lib/bootstrap-icons/icons/grip-vertical.svg"
    },
    {
      "hash": "sha256-Yyf/5INm5JHheQGu/pYNxslsMNc/vQDSMHeam800v4E=",
      "url": "lib/bootstrap-icons/icons/h-circle-fill.svg"
    },
    {
      "hash": "sha256-px5hX0XvQhD/xcGoMd7jM6c2XYucJPtOwlIXK4yyu8E=",
      "url": "lib/bootstrap-icons/icons/h-circle.svg"
    },
    {
      "hash": "sha256-EDNiVU1BUrkEWn5P7GxJFg+ke+JDgMJcqZOKgxSG0VQ=",
      "url": "lib/bootstrap-icons/icons/h-square-fill.svg"
    },
    {
      "hash": "sha256-oY+pAwrboPT/IvbmBssjv2XJB3hlWRlGhVZ1a/BuMbw=",
      "url": "lib/bootstrap-icons/icons/h-square.svg"
    },
    {
      "hash": "sha256-5f9qJT9/1m304WaK55NnvcbhNpHwyP86gPnzzv4IATI=",
      "url": "lib/bootstrap-icons/icons/hammer.svg"
    },
    {
      "hash": "sha256-+6Rl/0wLCH+D7SbQ7UPDIXIaE9+ZfCky794mAQMY93s=",
      "url": "lib/bootstrap-icons/icons/hand-index-fill.svg"
    },
    {
      "hash": "sha256-572cIwX2zQYct7/gW0b5jLedRyW4DP8Gr9yJpznrxTI=",
      "url": "lib/bootstrap-icons/icons/hand-index-thumb-fill.svg"
    },
    {
      "hash": "sha256-ZZiKeeWS0lvtTTWbnlm5PyYSPdyBVNJeXtqyTVx8vjU=",
      "url": "lib/bootstrap-icons/icons/hand-index-thumb.svg"
    },
    {
      "hash": "sha256-dOsFCYyBAf6OWokAl3B9rTm97J9d7YTohUVibKzinL4=",
      "url": "lib/bootstrap-icons/icons/hand-index.svg"
    },
    {
      "hash": "sha256-FpjL6+v2Pwdxb6jFe32ZG0qd+eYZ3IDsR0phBCceRc8=",
      "url": "lib/bootstrap-icons/icons/hand-thumbs-down-fill.svg"
    },
    {
      "hash": "sha256-Q8dSE8tJ3vlD2pU3FVv61NFmRck5Z5LuKHmncbhcB8o=",
      "url": "lib/bootstrap-icons/icons/hand-thumbs-down.svg"
    },
    {
      "hash": "sha256-glwu9oPJrhMPfCMP2NwSoZXvorDTvRhDY1fmUdgvLv4=",
      "url": "lib/bootstrap-icons/icons/hand-thumbs-up-fill.svg"
    },
    {
      "hash": "sha256-xghAbAIZxH+KxBvyz+jfylvmRO8ztu2EXCgIc2OIpX4=",
      "url": "lib/bootstrap-icons/icons/hand-thumbs-up.svg"
    },
    {
      "hash": "sha256-leagBN0HWoGRpCz9nkVIq7LbY3Qc0RPSHAhYuqF89yY=",
      "url": "lib/bootstrap-icons/icons/handbag-fill.svg"
    },
    {
      "hash": "sha256-YhuO2LGrBhEb0sxD/t305zbY6OHPJ2qOAlOQFgla/qk=",
      "url": "lib/bootstrap-icons/icons/handbag.svg"
    },
    {
      "hash": "sha256-iBIdPi7OpUyNLUHp41Xmd2uCoITWe/jj8DF/ZMdyqi4=",
      "url": "lib/bootstrap-icons/icons/hash.svg"
    },
    {
      "hash": "sha256-0Ny/0dzbunsgMeP5ZO31+HfllT9csfPbyImarZ1aJZc=",
      "url": "lib/bootstrap-icons/icons/hdd-fill.svg"
    },
    {
      "hash": "sha256-GfS6PjRkE6AD0+0X4YtZZzxirY3i9BqzmoPA7qkGsMA=",
      "url": "lib/bootstrap-icons/icons/hdd-network-fill.svg"
    },
    {
      "hash": "sha256-6HTQ82fUGK3QqNtWH+9GfgWTOKXf64VsG6dI/+5SlZs=",
      "url": "lib/bootstrap-icons/icons/hdd-network.svg"
    },
    {
      "hash": "sha256-Cc9EyNRRdJ7D7FsZYIeBd8LiT/2rhsVlwhyTekR1yOE=",
      "url": "lib/bootstrap-icons/icons/hdd-rack-fill.svg"
    },
    {
      "hash": "sha256-kgI8KY2wBAYTSzIxdZOVE1g6ojZNCAnHYkbJI6L1b/E=",
      "url": "lib/bootstrap-icons/icons/hdd-rack.svg"
    },
    {
      "hash": "sha256-WHK5fH3Mc2Ye4D5pJcLSG+lixN7SbfBsctZvhtQssvs=",
      "url": "lib/bootstrap-icons/icons/hdd-stack-fill.svg"
    },
    {
      "hash": "sha256-9SyS2eDHcAUh8aRI6L31y+L7WwmPYsNKDEXErdqPPUQ=",
      "url": "lib/bootstrap-icons/icons/hdd-stack.svg"
    },
    {
      "hash": "sha256-we5IJ3Al3Qf/fLkNj1OihIb5nCIv3tYi1wXHi6aWv14=",
      "url": "lib/bootstrap-icons/icons/hdd.svg"
    },
    {
      "hash": "sha256-D0hWaMC2jVmNrJty+2w9nRwLXhIA/v1Yu1qvg4mAx9A=",
      "url": "lib/bootstrap-icons/icons/hdmi-fill.svg"
    },
    {
      "hash": "sha256-lGA+SMkL0oafRChhvBoCHwYcb/pSS/TcQFHoY2vNe5Y=",
      "url": "lib/bootstrap-icons/icons/hdmi.svg"
    },
    {
      "hash": "sha256-SVNFDsOmHW9euUThMUpKF6k4XVRvRxmxPvb4rV+mZEQ=",
      "url": "lib/bootstrap-icons/icons/headphones.svg"
    },
    {
      "hash": "sha256-4MiN05Pfbcfg6q2pGGjObjhELjltSM/8yh9bVIPoSds=",
      "url": "lib/bootstrap-icons/icons/headset-vr.svg"
    },
    {
      "hash": "sha256-pomtOpgvzNPQoT+xdY4oBlaS40sauPxLbDR97GY8REc=",
      "url": "lib/bootstrap-icons/icons/headset.svg"
    },
    {
      "hash": "sha256-V5PhW5ggRtuqlu3zzk0UMdcV7UJpzIx2cYNjbx1SH1c=",
      "url": "lib/bootstrap-icons/icons/heart-arrow.svg"
    },
    {
      "hash": "sha256-mOdbJISgmuNlTaTxyiKV+SWfGvf1SrV6kfVdbzAdutc=",
      "url": "lib/bootstrap-icons/icons/heart-fill.svg"
    },
    {
      "hash": "sha256-KOlfMe2yxKoN0VlhWnCC2w3Mi2z/5ogdOSgLsaGF0/g=",
      "url": "lib/bootstrap-icons/icons/heart-half.svg"
    },
    {
      "hash": "sha256-w+0MYv88d6+hzRcNG8qrQmlSfY2Z4MIUH2nvXR6koZI=",
      "url": "lib/bootstrap-icons/icons/heart-pulse-fill.svg"
    },
    {
      "hash": "sha256-qeSYktdEm3LMGi5FjESjI7XobB5xwd4zPmUrX1ozPm4=",
      "url": "lib/bootstrap-icons/icons/heart-pulse.svg"
    },
    {
      "hash": "sha256-kBc1lr/mPiVi6MLB8Fu2yGA5+PGHdvl2OqspBjv5GcU=",
      "url": "lib/bootstrap-icons/icons/heart.svg"
    },
    {
      "hash": "sha256-2FTbqvt7qzDK/6YnXgA/pUu5inWmNv2M7a7E679GhZE=",
      "url": "lib/bootstrap-icons/icons/heartbreak-fill.svg"
    },
    {
      "hash": "sha256-QCAbY8wBTTm8XBzr28jkq7SZCoFPNCGyqSADu/cL6b8=",
      "url": "lib/bootstrap-icons/icons/heartbreak.svg"
    },
    {
      "hash": "sha256-h+Q2QqCZmBwhZN0Ryk9eRJ33T+Qp099rUpJsfldHcT0=",
      "url": "lib/bootstrap-icons/icons/hearts.svg"
    },
    {
      "hash": "sha256-hEme/FFD4xN7KBu6DAR1Bd6Fw75MecAbKq+qchuG/zU=",
      "url": "lib/bootstrap-icons/icons/heptagon-fill.svg"
    },
    {
      "hash": "sha256-yBlaLafjwsUxF3PSgcQiIm0d7ZzTX7WXuW9L2mqAhss=",
      "url": "lib/bootstrap-icons/icons/heptagon-half.svg"
    },
    {
      "hash": "sha256-ewyJqGieh8ua8UIqDwvISCB+wVljnWN21yrkJciBMgw=",
      "url": "lib/bootstrap-icons/icons/heptagon.svg"
    },
    {
      "hash": "sha256-GsW+zvOumYvzQeNyLNwZdvM+U4Wx+yixk+tV1Qy3S3Y=",
      "url": "lib/bootstrap-icons/icons/hexagon-fill.svg"
    },
    {
      "hash": "sha256-AF1YS7mwDsOASRTGLV1Pgq7uZcVX6OjLApmuQohnGQ8=",
      "url": "lib/bootstrap-icons/icons/hexagon-half.svg"
    },
    {
      "hash": "sha256-fI3r1TWUH2yNt1DNwOAqoSJSj1VFEv7bdeZYJL3pBYI=",
      "url": "lib/bootstrap-icons/icons/hexagon.svg"
    },
    {
      "hash": "sha256-NBy4HpjSVK8DBOKRE2JNMs522STWJ2Bpo3Cx1B6WZCY=",
      "url": "lib/bootstrap-icons/icons/highlighter.svg"
    },
    {
      "hash": "sha256-/wOGO4zle73hOl1yJ1gq5MKk5fGIRQJtyQfr3W4EgmA=",
      "url": "lib/bootstrap-icons/icons/highlights.svg"
    },
    {
      "hash": "sha256-L7AEcXcAmTmVCI7FrC5emdxTaYmOU2KrA9aHErZ1vsM=",
      "url": "lib/bootstrap-icons/icons/hospital-fill.svg"
    },
    {
      "hash": "sha256-tTF+IPeyX1QkoTZm97reBK7osd11zUwoy67tIG3rHsM=",
      "url": "lib/bootstrap-icons/icons/hospital.svg"
    },
    {
      "hash": "sha256-XpgO3gxxrThVNdZOijYNnf7lj0d6G4yG8Fnwj3lXtfg=",
      "url": "lib/bootstrap-icons/icons/hourglass-bottom.svg"
    },
    {
      "hash": "sha256-B+xdMMXruFeg24pe6tHcRshJPQWkWCFSr6PKwWEXjcw=",
      "url": "lib/bootstrap-icons/icons/hourglass-split.svg"
    },
    {
      "hash": "sha256-mgWx0xhb12z9VHinrIOcS7anY34UjMcLJJ6GP4xjvS4=",
      "url": "lib/bootstrap-icons/icons/hourglass-top.svg"
    },
    {
      "hash": "sha256-KJ9icLaEgpTbTIF5DROwrG/OrN8XskKn7sDCkqc7il4=",
      "url": "lib/bootstrap-icons/icons/hourglass.svg"
    },
    {
      "hash": "sha256-Rtb/RxRL+RUOa7JgVVG5WEu7PgLLET4TWzspkrlrVZY=",
      "url": "lib/bootstrap-icons/icons/house-add-fill.svg"
    },
    {
      "hash": "sha256-7GjFhMK24UkrC0Uu24gMl0UHmLELdtUSwDOrSbM+02I=",
      "url": "lib/bootstrap-icons/icons/house-add.svg"
    },
    {
      "hash": "sha256-AiW4TQmCnkp3RykVVmAfLkw37gYvgXbjQkV/Ko5tkqI=",
      "url": "lib/bootstrap-icons/icons/house-check-fill.svg"
    },
    {
      "hash": "sha256-I7XRV/NHs+fuMNP3ap4rChzp8fDAkXUpBjlWjel9Ta0=",
      "url": "lib/bootstrap-icons/icons/house-check.svg"
    },
    {
      "hash": "sha256-MyM7tS+5AqDakSmCip+bhA73QU/jwej8s0iCahZpiDM=",
      "url": "lib/bootstrap-icons/icons/house-dash-fill.svg"
    },
    {
      "hash": "sha256-9jSaD2bv9j7zBNZOFJKuu/Z4KvvpO4ToF0zLn7w+7PE=",
      "url": "lib/bootstrap-icons/icons/house-dash.svg"
    },
    {
      "hash": "sha256-zI/urVIV9AnKCiNqyfmtNXR59tR/qjk3jg+Fc7Ca8aE=",
      "url": "lib/bootstrap-icons/icons/house-door-fill.svg"
    },
    {
      "hash": "sha256-dnK3oW9XSFBopcigXUMst2JVF9yumNMXgArcBeI/b98=",
      "url": "lib/bootstrap-icons/icons/house-door.svg"
    },
    {
      "hash": "sha256-tODE9by7df9RPHerynwt7vjH/P1aekDJa2/0dJf2/u0=",
      "url": "lib/bootstrap-icons/icons/house-down-fill.svg"
    },
    {
      "hash": "sha256-ZGiE53TJvoYd5r6PVuaTnHcsrAHJxMHuu4mmL6m/+W0=",
      "url": "lib/bootstrap-icons/icons/house-down.svg"
    },
    {
      "hash": "sha256-5qqwnKt1M7ty8SxF0XKriCnpnod2RsGmRFJBjeJykdc=",
      "url": "lib/bootstrap-icons/icons/house-exclamation-fill.svg"
    },
    {
      "hash": "sha256-H1X6KFI0y9q234cfg2234r//LMyUh/iyVDzCZ3KX+18=",
      "url": "lib/bootstrap-icons/icons/house-exclamation.svg"
    },
    {
      "hash": "sha256-6fRwfhMu1RM8zV2y6JU6MP1lzM/zJHpJYI6gjEThueg=",
      "url": "lib/bootstrap-icons/icons/house-fill.svg"
    },
    {
      "hash": "sha256-ScTZAgadQw0HVspDUhs29+ixbYxwiPByRkAFaGFLlHM=",
      "url": "lib/bootstrap-icons/icons/house-gear-fill.svg"
    },
    {
      "hash": "sha256-zMhQ1d771ijQAYYJhTlnKQ5IgzkiQmnRUxyQ8LODhFI=",
      "url": "lib/bootstrap-icons/icons/house-gear.svg"
    },
    {
      "hash": "sha256-+ISXQ30U4Vz4/OgP3b7TErNhGJLdHdImh+19Hx6UTtI=",
      "url": "lib/bootstrap-icons/icons/house-heart-fill.svg"
    },
    {
      "hash": "sha256-TcXrMef/Zsf7YnJ+GZQUo0H+p9NgW4aWnN/K1U0dhnw=",
      "url": "lib/bootstrap-icons/icons/house-heart.svg"
    },
    {
      "hash": "sha256-e8lKxQq1ScvPkKQQIaQ4T9VjzENO3+59dsPCQF8Ks2c=",
      "url": "lib/bootstrap-icons/icons/house-lock-fill.svg"
    },
    {
      "hash": "sha256-0kcwnr5amMUJybpJdg+omqsdvyJA9HLC6BWMx7YY6JI=",
      "url": "lib/bootstrap-icons/icons/house-lock.svg"
    },
    {
      "hash": "sha256-edDsxpo3jM+0D5mb69XKEVuRAHBGV5mLothJ4i9oO80=",
      "url": "lib/bootstrap-icons/icons/house-slash-fill.svg"
    },
    {
      "hash": "sha256-tpXroKoqGWeo8WPfal6wtnmkbSAQ4KHJlyHTA7r2ec0=",
      "url": "lib/bootstrap-icons/icons/house-slash.svg"
    },
    {
      "hash": "sha256-gpcZ1cdoQix9wAND7AtGunk5yVE+/jhG3ZDskSAiAXE=",
      "url": "lib/bootstrap-icons/icons/house-up-fill.svg"
    },
    {
      "hash": "sha256-JAYiz6rJ2xrMgJKw8l3dooh03jMFJhKQzBwn1ZGDKbw=",
      "url": "lib/bootstrap-icons/icons/house-up.svg"
    },
    {
      "hash": "sha256-fsxPqQoQ7xt3thGL5iJhpIlNuwamWhcYPzhbPVqCJuY=",
      "url": "lib/bootstrap-icons/icons/house-x-fill.svg"
    },
    {
      "hash": "sha256-8bgNzswj4IDDRWdBmVq9tL5R0+h5ls3Tix5vNxMdMXQ=",
      "url": "lib/bootstrap-icons/icons/house-x.svg"
    },
    {
      "hash": "sha256-fkOgEx8pzdyoa7vJOh61XopmVYRBmc5cePgsrE0JV2g=",
      "url": "lib/bootstrap-icons/icons/house.svg"
    },
    {
      "hash": "sha256-L/lKaFtygGXFhqdGrkgauitpdeEALEa8n1wG5r8AwU8=",
      "url": "lib/bootstrap-icons/icons/houses-fill.svg"
    },
    {
      "hash": "sha256-wOmDQ9nzY0dZiD6XYA7FRCeB1vfuxvXrgMtIeoMnyDA=",
      "url": "lib/bootstrap-icons/icons/houses.svg"
    },
    {
      "hash": "sha256-VXwR13YcjzMwcAK6Ys0Pi6rdrGQYJYDb2rno0J5bGpc=",
      "url": "lib/bootstrap-icons/icons/hr.svg"
    },
    {
      "hash": "sha256-zPsM00Ttn8nJ6jwS3n+mY+QmlqnMJPD9qNkyNIqd/zk=",
      "url": "lib/bootstrap-icons/icons/hurricane.svg"
    },
    {
      "hash": "sha256-tPRe78A4o5sz9T3fWf9tPaXqyqrhDzMGqjMzlhhAC+w=",
      "url": "lib/bootstrap-icons/icons/hypnotize.svg"
    },
    {
      "hash": "sha256-gZ8ZfrRb6uuiHZE5jLW5NPiXjVN6otxRIkYJMSRUhmU=",
      "url": "lib/bootstrap-icons/icons/image-alt.svg"
    },
    {
      "hash": "sha256-hhcdKYYSEUZcmaF/j9dAOmzhDs4gZzj3qf1BsITgb60=",
      "url": "lib/bootstrap-icons/icons/image-fill.svg"
    },
    {
      "hash": "sha256-zbTupqbDcQwzOOyBcodgIqj8snJviXz3UDt0JZt0USY=",
      "url": "lib/bootstrap-icons/icons/image.svg"
    },
    {
      "hash": "sha256-KsWaK3KC3YA2Cy9Z/3Tgz2mltBWSnZq+yrbyjzh7aIU=",
      "url": "lib/bootstrap-icons/icons/images.svg"
    },
    {
      "hash": "sha256-ELF5IRvT0/GaFiXF31G9LPoIEraZF96w5pi/K4hVrl8=",
      "url": "lib/bootstrap-icons/icons/inbox-fill.svg"
    },
    {
      "hash": "sha256-n71fDhSr9l7TgA8xHbwwxsrC0pqQP1erp35flJULEV8=",
      "url": "lib/bootstrap-icons/icons/inbox.svg"
    },
    {
      "hash": "sha256-Xt/t9pVA1fF7H3jw5sAYx99yQ+VNAoWYTofxA/HC/Xw=",
      "url": "lib/bootstrap-icons/icons/inboxes-fill.svg"
    },
    {
      "hash": "sha256-mNx9NBrzk/lIazJgOpCXyzynXVHVCDZearybvQOTm+4=",
      "url": "lib/bootstrap-icons/icons/inboxes.svg"
    },
    {
      "hash": "sha256-EQ+ZAX0gA5xSaTUupQ9EMrLqVKZqL5YrbuABAFsBDw0=",
      "url": "lib/bootstrap-icons/icons/incognito.svg"
    },
    {
      "hash": "sha256-+zZ6pX0rT+5W1wWzRLpCgAXawwtN5iVCTyU8Ymt/qBQ=",
      "url": "lib/bootstrap-icons/icons/indent.svg"
    },
    {
      "hash": "sha256-vl+BhFggP7JfDmGqvGyAp8RA+s7F+8HV5h9AAm7ZVVs=",
      "url": "lib/bootstrap-icons/icons/infinity.svg"
    },
    {
      "hash": "sha256-0In6Nn+tsV8oyD5qkLqLXZxbxEycD924G9afH8kr7IE=",
      "url": "lib/bootstrap-icons/icons/info-circle-fill.svg"
    },
    {
      "hash": "sha256-v2QubEowDv1N3vSrtns0XIsNrrLBsI1V564IKNLNVXs=",
      "url": "lib/bootstrap-icons/icons/info-circle.svg"
    },
    {
      "hash": "sha256-7m9J2+3hndmddV+/TwxTGcZfPkk4lsVBJZC3q6Pg2ow=",
      "url": "lib/bootstrap-icons/icons/info-lg.svg"
    },
    {
      "hash": "sha256-aU8aO4EzEEx4YUMf/VsRkzlfNTlI7Y4Br+FQfgmvLqk=",
      "url": "lib/bootstrap-icons/icons/info-square-fill.svg"
    },
    {
      "hash": "sha256-CwxpC0PiHTQeCtzEpuEIrHSBt1Je53T+Jf9EEuf7Ft8=",
      "url": "lib/bootstrap-icons/icons/info-square.svg"
    },
    {
      "hash": "sha256-m1F5jH0knSuyMBRs+jioGI1ozG/h8ffr0ufu4AMU0hI=",
      "url": "lib/bootstrap-icons/icons/info.svg"
    },
    {
      "hash": "sha256-lvWfRuP780kcFLr8wkerlrA8jEosZGDWNMGyOMNVBfE=",
      "url": "lib/bootstrap-icons/icons/input-cursor-text.svg"
    },
    {
      "hash": "sha256-rc6L0fTAw1vxm+G8B62aj74+3txfTLVs5ocmgG83b3Y=",
      "url": "lib/bootstrap-icons/icons/input-cursor.svg"
    },
    {
      "hash": "sha256-myLGKmriEo7eZKptCze0P7Er4Afj0vUyHa2GjBiilOA=",
      "url": "lib/bootstrap-icons/icons/instagram.svg"
    },
    {
      "hash": "sha256-7xKRQie9Nf4r7iAIs3XdJ0OmCmHa57VUisVVqt+6ask=",
      "url": "lib/bootstrap-icons/icons/intersect.svg"
    },
    {
      "hash": "sha256-kqIMKMmj6osjvbdFhlG4m7L+UlHgCxIQWBdVrr4kAKU=",
      "url": "lib/bootstrap-icons/icons/journal-album.svg"
    },
    {
      "hash": "sha256-CglCMaqt6+6T5lIwliG94mJzlsozkB8E10WQwoIr/vs=",
      "url": "lib/bootstrap-icons/icons/journal-arrow-down.svg"
    },
    {
      "hash": "sha256-/YGNtBliKv+3kXuRmPs0K2eOtAlJspET2Uc3TwucUd4=",
      "url": "lib/bootstrap-icons/icons/journal-arrow-up.svg"
    },
    {
      "hash": "sha256-fOrY2aQ9UYfkM4bjzeEurKaWS8/37Nglw7Rxe6RculQ=",
      "url": "lib/bootstrap-icons/icons/journal-bookmark-fill.svg"
    },
    {
      "hash": "sha256-tJHwkWNijAPHef9EggWBkwq39cFHUPJ7KnEuSYOLS7k=",
      "url": "lib/bootstrap-icons/icons/journal-bookmark.svg"
    },
    {
      "hash": "sha256-ChZkBWH0LOGAsqNNeYudVuJnDZ6qGkJkohkYI4LmLvo=",
      "url": "lib/bootstrap-icons/icons/journal-check.svg"
    },
    {
      "hash": "sha256-YvbpREsJ+CfYuDrV4a3OqcZbMvJxeumGTt0rSjOprnM=",
      "url": "lib/bootstrap-icons/icons/journal-code.svg"
    },
    {
      "hash": "sha256-VXMgkZBkFBlsOJrG2pYUZn7b1NzzzMzabJmoE484HU0=",
      "url": "lib/bootstrap-icons/icons/journal-medical.svg"
    },
    {
      "hash": "sha256-XTRJjxnZU3LJA7eGUP/Yr+kcu+QFM7ubjN2x2xOD7E0=",
      "url": "lib/bootstrap-icons/icons/journal-minus.svg"
    },
    {
      "hash": "sha256-IfTKaUSiOrIHa/xLZXmTBfsrPM2bOKWBSbNG6xaXy0o=",
      "url": "lib/bootstrap-icons/icons/journal-plus.svg"
    },
    {
      "hash": "sha256-SQM/RBVGiRm8DUE15DoImqp4g0paUx4colCzSmQseNE=",
      "url": "lib/bootstrap-icons/icons/journal-richtext.svg"
    },
    {
      "hash": "sha256-VY/qOL67hGmaX6ka4qEMHwQ8C91hMiidCktjgqHp5gU=",
      "url": "lib/bootstrap-icons/icons/journal-text.svg"
    },
    {
      "hash": "sha256-w5PcZ5SqdIhv688UtuIvYrKuNF3edgJ4etaXl2OqO2c=",
      "url": "lib/bootstrap-icons/icons/journal-x.svg"
    },
    {
      "hash": "sha256-oFm6tGjrSq4jebc16JooE1AjDrqijtsHfU0ZKQYUBUk=",
      "url": "lib/bootstrap-icons/icons/journal.svg"
    },
    {
      "hash": "sha256-3b0nYwnjKpllAvWyPlznKWTct8gEGGOYxhguwSbfJcU=",
      "url": "lib/bootstrap-icons/icons/journals.svg"
    },
    {
      "hash": "sha256-XdSkk1/VEGVIFfexw/wm2yc5floAOELlgvqlrnBIp9c=",
      "url": "lib/bootstrap-icons/icons/joystick.svg"
    },
    {
      "hash": "sha256-Z36Dku1+rsOY4cny3mDyFJWvLQ2wB6coJg2ITIjGH44=",
      "url": "lib/bootstrap-icons/icons/justify-left.svg"
    },
    {
      "hash": "sha256-HElrhouwT8Y0vvdW/LbYW8OElk6C+Xe/ZkWeEdulCII=",
      "url": "lib/bootstrap-icons/icons/justify-right.svg"
    },
    {
      "hash": "sha256-4uORnP4SnWYCknQYROJOYk+DxXTvYxncsWgsfapUpcs=",
      "url": "lib/bootstrap-icons/icons/justify.svg"
    },
    {
      "hash": "sha256-Oh3yZhKeZo0qmUczzOtuRWZgdKTju8VvIwhS9TFucu0=",
      "url": "lib/bootstrap-icons/icons/kanban-fill.svg"
    },
    {
      "hash": "sha256-UFbmfwuNUys10/VN+581YO+6WWUNKxYAee4wIAp85Zs=",
      "url": "lib/bootstrap-icons/icons/kanban.svg"
    },
    {
      "hash": "sha256-XmuCTypothon6luedcAx4syo7yP8/wqw1WRCTseMakg=",
      "url": "lib/bootstrap-icons/icons/key-fill.svg"
    },
    {
      "hash": "sha256-W174jArRD85ta1o2L81rH0K3z0umkLt1T0ER2WAMGvo=",
      "url": "lib/bootstrap-icons/icons/key.svg"
    },
    {
      "hash": "sha256-GTEQiFF2adNytLbYsgIC+rcvF1ywIbGhTMcR+F18cj4=",
      "url": "lib/bootstrap-icons/icons/keyboard-fill.svg"
    },
    {
      "hash": "sha256-oJElicimD3nZHttkbptutpP5PXVS6q61EsV4JLiMkr8=",
      "url": "lib/bootstrap-icons/icons/keyboard.svg"
    },
    {
      "hash": "sha256-sw5CkMwpFa9M0foV9UD7V2klKdc6tpjMq+CWHTvRSAo=",
      "url": "lib/bootstrap-icons/icons/ladder.svg"
    },
    {
      "hash": "sha256-6BShkUUcEkvhAICpM0HPYYWgywzCE4mo9MnK70NJdMo=",
      "url": "lib/bootstrap-icons/icons/lamp-fill.svg"
    },
    {
      "hash": "sha256-d4tExvcG/pAXX4T948JweLpz5NrweZ8Izdnfu2/aMvY=",
      "url": "lib/bootstrap-icons/icons/lamp.svg"
    },
    {
      "hash": "sha256-/EJRZCG4o1LFUF641A1GfSSpO9T37ViJVrHxdz29H30=",
      "url": "lib/bootstrap-icons/icons/laptop-fill.svg"
    },
    {
      "hash": "sha256-I3vXEPZ0YrKvQM9AovNvaYgZO2YY1qzhJoltGaSrs1o=",
      "url": "lib/bootstrap-icons/icons/laptop.svg"
    },
    {
      "hash": "sha256-rB2067/YW1CZijwWPjArKuVEem1d8fJEIDkv0b98DM8=",
      "url": "lib/bootstrap-icons/icons/layer-backward.svg"
    },
    {
      "hash": "sha256-poJt1J3aYQDehst7mn+pfaXUj3CnhY2mQeVfONYA334=",
      "url": "lib/bootstrap-icons/icons/layer-forward.svg"
    },
    {
      "hash": "sha256-e1qbfgHIscJkVmsiiqdUUY1e4j9ptz1J82FyzrwZZmE=",
      "url": "lib/bootstrap-icons/icons/layers-fill.svg"
    },
    {
      "hash": "sha256-5YwRTBOYarjTmlbD8YiTX6GjKINRUFH0hwm09VdVDmI=",
      "url": "lib/bootstrap-icons/icons/layers-half.svg"
    },
    {
      "hash": "sha256-xRJ6PbiOrbaEkQqbosBrNO5IcvopAIbMLzTq2Ye3Ltk=",
      "url": "lib/bootstrap-icons/icons/layers.svg"
    },
    {
      "hash": "sha256-iY6nk0e4PVyEoo6HksZUm/EhZ+ERsjxF5lpzb70VU0g=",
      "url": "lib/bootstrap-icons/icons/layout-sidebar-inset-reverse.svg"
    },
    {
      "hash": "sha256-ppuZK7A4aq4WiJfauCO5lqksveFCQXs+L9sszxb1xys=",
      "url": "lib/bootstrap-icons/icons/layout-sidebar-inset.svg"
    },
    {
      "hash": "sha256-rlqsF5HD4pmQ6dJ/icPBWUqkTFvdNnyeFkw/TP2g5k0=",
      "url": "lib/bootstrap-icons/icons/layout-sidebar-reverse.svg"
    },
    {
      "hash": "sha256-CaufMRkyWYhJmF0VYtS37ZThomMOYdyVYg5P6O+At4U=",
      "url": "lib/bootstrap-icons/icons/layout-sidebar.svg"
    },
    {
      "hash": "sha256-V9aVKxetZOrDxkD4g7ZYl95+9VSImhtIA63ucBwkVsk=",
      "url": "lib/bootstrap-icons/icons/layout-split.svg"
    },
    {
      "hash": "sha256-wWk3PljwL9uceAX1qeoTZALoOAz25de/kJfks54BXn8=",
      "url": "lib/bootstrap-icons/icons/layout-text-sidebar-reverse.svg"
    },
    {
      "hash": "sha256-QP6kaWXgV/ukIkresbGywQ1UB4G6hzHZjEw+xcq2j9Q=",
      "url": "lib/bootstrap-icons/icons/layout-text-sidebar.svg"
    },
    {
      "hash": "sha256-aADp5jIw3ZzPm9n3gcJu1Pc7RjYZGW7zhQy2sX0KkUo=",
      "url": "lib/bootstrap-icons/icons/layout-text-window-reverse.svg"
    },
    {
      "hash": "sha256-iDdWyeqRqgtWOnRdRFw+slqbmxrrSHNX0n8G6uScM04=",
      "url": "lib/bootstrap-icons/icons/layout-text-window.svg"
    },
    {
      "hash": "sha256-Ic9wgW/KINVYSUmWV/jTLBmlYyKKieVsms6L+L5A6Ho=",
      "url": "lib/bootstrap-icons/icons/layout-three-columns.svg"
    },
    {
      "hash": "sha256-S14mK8FwtpKNfhcIdTelUfshBFbDsZ8p1vyUEtf9BiA=",
      "url": "lib/bootstrap-icons/icons/layout-wtf.svg"
    },
    {
      "hash": "sha256-/36X6PWxXzQNITDyLgA75s6ZcTVo8De3YRWX/BFKJ04=",
      "url": "lib/bootstrap-icons/icons/life-preserver.svg"
    },
    {
      "hash": "sha256-07aY2AhnbxO/vuB112yMS1uFJGiOuYSNpDpJYggko9o=",
      "url": "lib/bootstrap-icons/icons/lightbulb-fill.svg"
    },
    {
      "hash": "sha256-9Z2vbNMyf5b0InHaFHcMeeRZNNih4IQzuVufIdb1C2g=",
      "url": "lib/bootstrap-icons/icons/lightbulb-off-fill.svg"
    },
    {
      "hash": "sha256-p+Stdsnk35fkG98pskf3bnTzC+8aFybbLKJo7AXBJro=",
      "url": "lib/bootstrap-icons/icons/lightbulb-off.svg"
    },
    {
      "hash": "sha256-Lnx+LwI6b9mw8lOs/bhs6zI7Pabp1u21/ThZa3xRFIk=",
      "url": "lib/bootstrap-icons/icons/lightbulb.svg"
    },
    {
      "hash": "sha256-KRKYWxeuMzT6iH2V2i5ahtvlrF6GPXYO5ZL8FlMhS/4=",
      "url": "lib/bootstrap-icons/icons/lightning-charge-fill.svg"
    },
    {
      "hash": "sha256-UDWnM168tH1SclYvMlfufBYMmFkzZpdshVqs2tAv8N8=",
      "url": "lib/bootstrap-icons/icons/lightning-charge.svg"
    },
    {
      "hash": "sha256-sJ4/0vLN7J1XnxfrHo4ZVSWCbt9UeHPfefumMWZhUpM=",
      "url": "lib/bootstrap-icons/icons/lightning-fill.svg"
    },
    {
      "hash": "sha256-tSHlVWehNeUmeMHhCbvYEbbkEI5Vuz19+lflXb7Ib0Y=",
      "url": "lib/bootstrap-icons/icons/lightning.svg"
    },
    {
      "hash": "sha256-Ir0F78eMydaNBRJZjwhEr45Dn8CX6u0J6+CzIfYpsK0=",
      "url": "lib/bootstrap-icons/icons/line.svg"
    },
    {
      "hash": "sha256-vCFGH/bwQCt7I84sr1DKVd++EmUrCA9h19ZVAGVszsw=",
      "url": "lib/bootstrap-icons/icons/link-45deg.svg"
    },
    {
      "hash": "sha256-PK+9VHB7s7RxGmzZGS1Wc0YK47CubYflzi56wWHhYQg=",
      "url": "lib/bootstrap-icons/icons/link.svg"
    },
    {
      "hash": "sha256-ExEkpCxssZKr+X5zPQvAGd4XevezaNa4AizQEjeXlZU=",
      "url": "lib/bootstrap-icons/icons/linkedin.svg"
    },
    {
      "hash": "sha256-KrNw7IgHKOMuX5+5kur+K6sqL+CAhkBePJqamd+zU7Y=",
      "url": "lib/bootstrap-icons/icons/list-check.svg"
    },
    {
      "hash": "sha256-mUU+SvRfXMH6DHljc/Q9R90AGVo9XpdKOGrqqBty0+0=",
      "url": "lib/bootstrap-icons/icons/list-columns-reverse.svg"
    },
    {
      "hash": "sha256-IBi11I9Ls9+AhYFuWpFUjVjsDKVOsAcZzRlLozgZ+yc=",
      "url": "lib/bootstrap-icons/icons/list-columns.svg"
    },
    {
      "hash": "sha256-bEZ680GJi1/qdRvi7yjmytsHX6u62qri+nE/fszS0PA=",
      "url": "lib/bootstrap-icons/icons/list-nested.svg"
    },
    {
      "hash": "sha256-vRr4WT/SLl14V+nDCqarzSN1fD/W1/WXSnl57BstDOs=",
      "url": "lib/bootstrap-icons/icons/list-ol.svg"
    },
    {
      "hash": "sha256-k7qjOhfv885bXLjwN2W6i78guo9p8fMnje4K0s5KLzU=",
      "url": "lib/bootstrap-icons/icons/list-stars.svg"
    },
    {
      "hash": "sha256-6Q3I5rUVuVksJ2mXyZ8sJVoy2R+16M5b1qsRw12ctIU=",
      "url": "lib/bootstrap-icons/icons/list-task.svg"
    },
    {
      "hash": "sha256-6wc2k/JvF7WzFoUps/kCRerssShNxSJo+GZEvbFa734=",
      "url": "lib/bootstrap-icons/icons/list-ul.svg"
    },
    {
      "hash": "sha256-aImaCtTRMofA8uNALMkO8MW4vHE36wrQh7BRNeSnGPU=",
      "url": "lib/bootstrap-icons/icons/list.svg"
    },
    {
      "hash": "sha256-gg5kyBz/optIw05pBHWGBwJo62RPDyjRQ4drSEal2nk=",
      "url": "lib/bootstrap-icons/icons/lock-fill.svg"
    },
    {
      "hash": "sha256-Zkhv6jmjN8iXT6rXc40Qw/yr8tgwCBJ/kUT8wDp3K+4=",
      "url": "lib/bootstrap-icons/icons/lock.svg"
    },
    {
      "hash": "sha256-Srgae1NfTiR039oi4dGljnBTWPvkt3aJ4QTX01PaOtY=",
      "url": "lib/bootstrap-icons/icons/luggage-fill.svg"
    },
    {
      "hash": "sha256-cLPXjLYgm1P8X4CFxNOzGtAM4r0Z9sBMOZdwEmQWuVs=",
      "url": "lib/bootstrap-icons/icons/luggage.svg"
    },
    {
      "hash": "sha256-cyenW9/+ntcp2BSIbI7pAwZaxw0u435Kt6nsFhT6iIU=",
      "url": "lib/bootstrap-icons/icons/lungs-fill.svg"
    },
    {
      "hash": "sha256-MHom/O1FpONhMpG4YoXmIFIxxzIH7pVUNcKjStLqvY4=",
      "url": "lib/bootstrap-icons/icons/lungs.svg"
    },
    {
      "hash": "sha256-rNNK/Mp6sioeFcLfH4Vr/UFSl6XSb70sTnQ7WYHBPVk=",
      "url": "lib/bootstrap-icons/icons/magic.svg"
    },
    {
      "hash": "sha256-LnB/ztWWp4/t8vE0nXQ2XSjTMxuMkvSXRt5gpdTZvdc=",
      "url": "lib/bootstrap-icons/icons/magnet-fill.svg"
    },
    {
      "hash": "sha256-H4+Ls1e+9F1iqJlv16F87A83ToJF84vpRlfvQyujwSI=",
      "url": "lib/bootstrap-icons/icons/magnet.svg"
    },
    {
      "hash": "sha256-x/mfb+YtBIrcYWf3EgVDkMoRID7aovEVQ9sGsjgzx1c=",
      "url": "lib/bootstrap-icons/icons/mailbox-flag.svg"
    },
    {
      "hash": "sha256-fPkGL4FO4vnKVRmTuDrJYI6KuH5BcFklH1dDyh2u7hY=",
      "url": "lib/bootstrap-icons/icons/mailbox.svg"
    },
    {
      "hash": "sha256-32/sDfm45UGEdd6VkIfsZEnkkM0+mo9o9496YGGUx8s=",
      "url": "lib/bootstrap-icons/icons/mailbox2-flag.svg"
    },
    {
      "hash": "sha256-g8QIIY/8kIgB0plCDuB6JjncSfgM44XUZOZT50VchEA=",
      "url": "lib/bootstrap-icons/icons/mailbox2.svg"
    },
    {
      "hash": "sha256-zl6fW8R5kY8KA6FO5C8QBxPLs6Y/jEu4Yb0EiW7IZto=",
      "url": "lib/bootstrap-icons/icons/map-fill.svg"
    },
    {
      "hash": "sha256-beLqChr33+6IRDsHy48i4xFGLjuIJaDFwCmM3WQp354=",
      "url": "lib/bootstrap-icons/icons/map.svg"
    },
    {
      "hash": "sha256-Dwdm4udB/a1zef8Mej7MPHLZ2GbvPU5vuaEMcne1uNY=",
      "url": "lib/bootstrap-icons/icons/markdown-fill.svg"
    },
    {
      "hash": "sha256-MyxrwAIyJcQhF8m3nNoDN17rN9ftp1sHd1xNIHsuUbo=",
      "url": "lib/bootstrap-icons/icons/markdown.svg"
    },
    {
      "hash": "sha256-OelZIzRyedGU0tBDysG9ZRtXAgN6lkV6ffpE5pMTvW4=",
      "url": "lib/bootstrap-icons/icons/marker-tip.svg"
    },
    {
      "hash": "sha256-9o8KLBvqeZPoby2ThRux+9rGAppmirMWmlj2gZjOO/M=",
      "url": "lib/bootstrap-icons/icons/mask.svg"
    },
    {
      "hash": "sha256-d1lHMSuOaUaZrGFeWwbc70WL2gqrSDwJP6gRTql61G0=",
      "url": "lib/bootstrap-icons/icons/mastodon.svg"
    },
    {
      "hash": "sha256-Mk5n9QYJ4sUvFzHyNA3rCrVsAHewjvWqkP3AUZ4dPRI=",
      "url": "lib/bootstrap-icons/icons/medium.svg"
    },
    {
      "hash": "sha256-4LoDsFha73NnLpkRq/ag0ognC2AXKs6Hn2UuDz1/E/8=",
      "url": "lib/bootstrap-icons/icons/megaphone-fill.svg"
    },
    {
      "hash": "sha256-PXIfSs9HHTwEOd2GE2sFdPOiiaIkc4QUH+Bfccxre5E=",
      "url": "lib/bootstrap-icons/icons/megaphone.svg"
    },
    {
      "hash": "sha256-FYfYZA7J4pkg5P995SOqg5CjyYC264cPLTmBLlGLDxQ=",
      "url": "lib/bootstrap-icons/icons/memory.svg"
    },
    {
      "hash": "sha256-6tnlZ8A9GgT/jaCChIjatS83F+simBkNp+nPVYJQwWI=",
      "url": "lib/bootstrap-icons/icons/menu-app-fill.svg"
    },
    {
      "hash": "sha256-BPsvqt6nLmcKjcDoflbV6nkHB1VL+XJu323402kUj00=",
      "url": "lib/bootstrap-icons/icons/menu-app.svg"
    },
    {
      "hash": "sha256-qmT3hA8fxDL9IwaJ38LFktnTPNHjuyPYDXrCgoEfO2k=",
      "url": "lib/bootstrap-icons/icons/menu-button-fill.svg"
    },
    {
      "hash": "sha256-VYvH1BCw7cM/vEysbPBeKF0zIPiqzsmxCm/HflZLmwA=",
      "url": "lib/bootstrap-icons/icons/menu-button-wide-fill.svg"
    },
    {
      "hash": "sha256-0c3SfgqH+nOZD5lB5DJPB3yuyQiI4EoXjYSpW/w9/I0=",
      "url": "lib/bootstrap-icons/icons/menu-button-wide.svg"
    },
    {
      "hash": "sha256-QoA4slXQIvpaqCFQjVxw5w5AJgEjs2PzVXMsvwlZr3k=",
      "url": "lib/bootstrap-icons/icons/menu-button.svg"
    },
    {
      "hash": "sha256-ng/dTrOHl/sXRnlwS+b9ZJ1sQJe4vuZgl/9WWXlN8Pc=",
      "url": "lib/bootstrap-icons/icons/menu-down.svg"
    },
    {
      "hash": "sha256-mmDKOpOGw79jFq1RTLu3K0b9yTji9gO1aDsqRy4nvAw=",
      "url": "lib/bootstrap-icons/icons/menu-up.svg"
    },
    {
      "hash": "sha256-GsrRsql3+SKOw5VsoQxGakz0LhoQ+OyKVNz73i53RKM=",
      "url": "lib/bootstrap-icons/icons/messenger.svg"
    },
    {
      "hash": "sha256-8KIRCNGBHYXe1m4VQswoBWIhaUSgXpFhdu3jiy+H0Wg=",
      "url": "lib/bootstrap-icons/icons/meta.svg"
    },
    {
      "hash": "sha256-kjfYsGEJw5DOpH39cbM6lWlhHdvNoRS4OzxoPWl3hxE=",
      "url": "lib/bootstrap-icons/icons/mic-fill.svg"
    },
    {
      "hash": "sha256-I7jYzn+0FS2e7dsexUXVqHS9r55dPPkcBtEU4EcG1VA=",
      "url": "lib/bootstrap-icons/icons/mic-mute-fill.svg"
    },
    {
      "hash": "sha256-cmi3p9ObU62ad9z256Gv7Le7OUnnqhfdhYVDfH2lrf8=",
      "url": "lib/bootstrap-icons/icons/mic-mute.svg"
    },
    {
      "hash": "sha256-BSDFiscQPgfOBMavPdcIUuIOHisUlrm7cUFN325H+CE=",
      "url": "lib/bootstrap-icons/icons/mic.svg"
    },
    {
      "hash": "sha256-e8ra6r25P4aH1e7b7DDGO8V5lJU92Ef8mAWabntMc+c=",
      "url": "lib/bootstrap-icons/icons/microsoft-teams.svg"
    },
    {
      "hash": "sha256-w18TyKThk5I4CEJz2hI4CKPTu3lDREMmELo5sY77MUg=",
      "url": "lib/bootstrap-icons/icons/microsoft.svg"
    },
    {
      "hash": "sha256-Qkqyw0wvuw1qwcOKMHroiwH75WP3XlmeK0QU4yTlX8o=",
      "url": "lib/bootstrap-icons/icons/minecart-loaded.svg"
    },
    {
      "hash": "sha256-DAda8aoDBwzakHtfCUVRbxE7WX1pecNrSntgnd/QZzA=",
      "url": "lib/bootstrap-icons/icons/minecart.svg"
    },
    {
      "hash": "sha256-grbO7Ia9vTknizJLptCTUhhtyO77XZArpHkz9gcvBGw=",
      "url": "lib/bootstrap-icons/icons/modem-fill.svg"
    },
    {
      "hash": "sha256-xRGqZ1twYXHAYgcrvf1pitmc3W9D5N3t11uxF4l8OTM=",
      "url": "lib/bootstrap-icons/icons/modem.svg"
    },
    {
      "hash": "sha256-dsOIgyXmnqg5fyStmmvaiVZvZ7oTiJ2LbnC5u9lmsOg=",
      "url": "lib/bootstrap-icons/icons/moisture.svg"
    },
    {
      "hash": "sha256-gd5dnlVmTtnrjDPZGV+MtvPSLGJCE2i6RMX4f6IvTek=",
      "url": "lib/bootstrap-icons/icons/moon-fill.svg"
    },
    {
      "hash": "sha256-/IjGQm8EMBUDbrBrV+zse12q3afsFR/8HfcfO+p/p1U=",
      "url": "lib/bootstrap-icons/icons/moon-stars-fill.svg"
    },
    {
      "hash": "sha256-pB5NVpO9rVZtu51+6qdJ3CCHcFtiuNz+QWrBm8uzn0o=",
      "url": "lib/bootstrap-icons/icons/moon-stars.svg"
    },
    {
      "hash": "sha256-jm0Hmbj3TFZm31KlAvWG98oQesD1QFTEB5FC9T0eAcU=",
      "url": "lib/bootstrap-icons/icons/moon.svg"
    },
    {
      "hash": "sha256-iG23IW8KN0PPk8Wzlvc++1VJmPSKMzhoxN45LPh3vv8=",
      "url": "lib/bootstrap-icons/icons/mortarboard-fill.svg"
    },
    {
      "hash": "sha256-Snen+n8PMudfW6/AAnZfDDNh53X7XhZajw3SuYsKaDM=",
      "url": "lib/bootstrap-icons/icons/mortarboard.svg"
    },
    {
      "hash": "sha256-C61lmntDX6LXt/WxjoBOKLOCjK9rtqImFUq+klPlxz8=",
      "url": "lib/bootstrap-icons/icons/motherboard-fill.svg"
    },
    {
      "hash": "sha256-XNYyUgPO9Es4GNMPeOD6jN7K0hTt/+79qD2O+BqNzHE=",
      "url": "lib/bootstrap-icons/icons/motherboard.svg"
    },
    {
      "hash": "sha256-5CPbvszWvGborDL1xqHIxqv/5iTovQ9e2lhdcWkTL0I=",
      "url": "lib/bootstrap-icons/icons/mouse-fill.svg"
    },
    {
      "hash": "sha256-MC0Nci7khPXzZyLNFHWk81AijDxAF2roxZhx27yYFC0=",
      "url": "lib/bootstrap-icons/icons/mouse.svg"
    },
    {
      "hash": "sha256-r1qLM7dujTiKBOurhRyWOmkjrvsbRwIuEsnyxA25xTU=",
      "url": "lib/bootstrap-icons/icons/mouse2-fill.svg"
    },
    {
      "hash": "sha256-/wX9TexMOStRr3HecgI0QxP4kp1zkeofovakQEKpQOg=",
      "url": "lib/bootstrap-icons/icons/mouse2.svg"
    },
    {
      "hash": "sha256-a4dkTR5gB9SN8uCgIrjYb7Q4iC3oV4lgGMM4qVeNC6U=",
      "url": "lib/bootstrap-icons/icons/mouse3-fill.svg"
    },
    {
      "hash": "sha256-ro9sDSozFgGKdVI5ig/xFuHjtjvRQTSfXD+B6U+ppuY=",
      "url": "lib/bootstrap-icons/icons/mouse3.svg"
    },
    {
      "hash": "sha256-1vGXF6i4bQkb6pOjmtuxH3Uxoc3jxvMkidrWznSjaAU=",
      "url": "lib/bootstrap-icons/icons/music-note-beamed.svg"
    },
    {
      "hash": "sha256-kEXN5Vz+wfALOySorWPBbHZNxb4RtitjoJYwG3HJAiE=",
      "url": "lib/bootstrap-icons/icons/music-note-list.svg"
    },
    {
      "hash": "sha256-4fAFviJ8Y8s8Fdf2QuEsq4gBSPubd7WbR4AKwxxu8GE=",
      "url": "lib/bootstrap-icons/icons/music-note.svg"
    },
    {
      "hash": "sha256-f2/opWIsqFRCMrYlhQgc2n7hLEz4+LXRyekSiiHO4vk=",
      "url": "lib/bootstrap-icons/icons/music-player-fill.svg"
    },
    {
      "hash": "sha256-BbHsk3cVXnSeniXWREspVGIRbaHcucnKDDqx5ZyH2zY=",
      "url": "lib/bootstrap-icons/icons/music-player.svg"
    },
    {
      "hash": "sha256-krw6AMs4HtVT0G2i22TRguTxMXXH0OS/SDKh9SmPQeM=",
      "url": "lib/bootstrap-icons/icons/newspaper.svg"
    },
    {
      "hash": "sha256-VZjiKyHtC02hth3nA06734EkO7DIDMXhj4swcp/OopI=",
      "url": "lib/bootstrap-icons/icons/nintendo-switch.svg"
    },
    {
      "hash": "sha256-uEyZJNWsQ/Bd9nlvycR4EomL2c2nE5+27QfgesFsFAo=",
      "url": "lib/bootstrap-icons/icons/node-minus-fill.svg"
    },
    {
      "hash": "sha256-dpw0T3NmHzakp91ECv9cfZ8qSlsMtI5fRS6V1jDZh9M=",
      "url": "lib/bootstrap-icons/icons/node-minus.svg"
    },
    {
      "hash": "sha256-tGG2Rd+1OyWew/0Lqm9uw+4ufmuf4hkmhReg7bGnlVI=",
      "url": "lib/bootstrap-icons/icons/node-plus-fill.svg"
    },
    {
      "hash": "sha256-3Kc9dxeFyqIKOKozjt7zvOyV7Sez4CJ+AEdYWQxAUUU=",
      "url": "lib/bootstrap-icons/icons/node-plus.svg"
    },
    {
      "hash": "sha256-LQOvDLhc7/F0u8B1yPyoZ2eTasib15K76TzDVPyCchc=",
      "url": "lib/bootstrap-icons/icons/noise-reduction.svg"
    },
    {
      "hash": "sha256-gt09nsE31dqWBIHSI7DCWMk7yHVGgRrM3SHKiC3duAQ=",
      "url": "lib/bootstrap-icons/icons/nut-fill.svg"
    },
    {
      "hash": "sha256-Iww4MUVuqtdCHwRaZIeEAU/AgiTmoKoCOyKHDz9jr6k=",
      "url": "lib/bootstrap-icons/icons/nut.svg"
    },
    {
      "hash": "sha256-k5ck7nyxqp9RCxs2CvSpEWYIDE3n1vkU+Rh9nhbpSxU=",
      "url": "lib/bootstrap-icons/icons/nvidia.svg"
    },
    {
      "hash": "sha256-+ny91QUzCrL9JmH4aXL4XLtau4orvhc8xbupXGQ+05A=",
      "url": "lib/bootstrap-icons/icons/nvme-fill.svg"
    },
    {
      "hash": "sha256-PP7Wg2eGi1ZLj5hMkwOP8GrCb67ojqlIvolQcJYjdTk=",
      "url": "lib/bootstrap-icons/icons/nvme.svg"
    },
    {
      "hash": "sha256-Zgc78ixGRkCrvaLM1UWDjncd6Frw9ba5bj2omYGQdsY=",
      "url": "lib/bootstrap-icons/icons/octagon-fill.svg"
    },
    {
      "hash": "sha256-yZuUqLMckCbW6sH8hR4rkHJkYwe1yZDrKDPeLl9wzs4=",
      "url": "lib/bootstrap-icons/icons/octagon-half.svg"
    },
    {
      "hash": "sha256-j0m5VESji1sJ+9Ntx4UCP80W6F6Xy6ye1LolmWxXdIU=",
      "url": "lib/bootstrap-icons/icons/octagon.svg"
    },
    {
      "hash": "sha256-+O27hFtLOaR/1c/Y6JZLpjwG0WZWbJFZ3N69g6LxhAY=",
      "url": "lib/bootstrap-icons/icons/opencollective.svg"
    },
    {
      "hash": "sha256-l1OmHcr4Hrjn1Bn7uhkZMxUWD6MDMh8jHPXbAB8MRGI=",
      "url": "lib/bootstrap-icons/icons/optical-audio-fill.svg"
    },
    {
      "hash": "sha256-UZrEaABtKFOrZm2KiMp5Ob8GGlIMnJOMM5RyTAjoVCE=",
      "url": "lib/bootstrap-icons/icons/optical-audio.svg"
    },
    {
      "hash": "sha256-Oh6CYg2ZnP0SfaP8okXnxeaTp+b6aqDIIl5LyA/aH0M=",
      "url": "lib/bootstrap-icons/icons/option.svg"
    },
    {
      "hash": "sha256-XwfrZR/NRBUCtmWBPpRyxYwTPpw3hcPsy4aZNFX6vhQ=",
      "url": "lib/bootstrap-icons/icons/outlet.svg"
    },
    {
      "hash": "sha256-+JEzKZKoOobhSCZRoEVCtcCE5OAtReaxrzewzUHGvf4=",
      "url": "lib/bootstrap-icons/icons/p-circle-fill.svg"
    },
    {
      "hash": "sha256-cUGEPXJf0oRecbaB/zPh+TQFhT0qO/T0tx1fMdPd7mo=",
      "url": "lib/bootstrap-icons/icons/p-circle.svg"
    },
    {
      "hash": "sha256-iswugif09z++BdQlUF4Ozuy4jEQ7X7hGPNGR2eWq958=",
      "url": "lib/bootstrap-icons/icons/p-square-fill.svg"
    },
    {
      "hash": "sha256-l/NamF+syf+tWNqnmfYVrnKPr4MUQbpTb5bjIS6sj1c=",
      "url": "lib/bootstrap-icons/icons/p-square.svg"
    },
    {
      "hash": "sha256-EjwZXm42FCpqZkBxN1GjrzsFA0Ka6e5mKUSAQixAC4Q=",
      "url": "lib/bootstrap-icons/icons/paint-bucket.svg"
    },
    {
      "hash": "sha256-12+Zrfv2Cj/I/sQc6HTFe1owkWU67u+b7XoDH6RBRg8=",
      "url": "lib/bootstrap-icons/icons/palette-fill.svg"
    },
    {
      "hash": "sha256-Fwmd7g9Rs9KfN/NSRUK/LQj1gqMLONtH6C41lyED6Ro=",
      "url": "lib/bootstrap-icons/icons/palette.svg"
    },
    {
      "hash": "sha256-sXaZWIk9G7Mf4sU85mYNxP6tOnDENpoBcfhQsbPK74M=",
      "url": "lib/bootstrap-icons/icons/palette2.svg"
    },
    {
      "hash": "sha256-MqGQ9Ue1Rv0K9sIt8RIa4hZGuPEAI0RkaGwBKlBvIeE=",
      "url": "lib/bootstrap-icons/icons/paperclip.svg"
    },
    {
      "hash": "sha256-oa0XPqPzDN/NX9glCqoWMeCI8kThq4AuEpyPIoN8mDI=",
      "url": "lib/bootstrap-icons/icons/paragraph.svg"
    },
    {
      "hash": "sha256-bpTHl08P5IGfkOs/0m3UELfnvl6+DtsodG6w79iXHu0=",
      "url": "lib/bootstrap-icons/icons/pass-fill.svg"
    },
    {
      "hash": "sha256-5jhC+YqaTV3O0yX3vqivKvylHtxX9T1gQGdlH1e5Xp4=",
      "url": "lib/bootstrap-icons/icons/pass.svg"
    },
    {
      "hash": "sha256-B+YnPeNSDC4ewfRdeYY9bScfUgkSfFroZ8BF5MpmweI=",
      "url": "lib/bootstrap-icons/icons/passport-fill.svg"
    },
    {
      "hash": "sha256-/Hk5e4ocCn0512s5pvfCB59Lnxg73gX807N5MfglCkQ=",
      "url": "lib/bootstrap-icons/icons/passport.svg"
    },
    {
      "hash": "sha256-82bCJM6QjwdJsTRKZ/xRj0NpkjY190miLzCQ0KyaS+U=",
      "url": "lib/bootstrap-icons/icons/patch-check-fill.svg"
    },
    {
      "hash": "sha256-M2DaNH5rnrYO5tzspt09uNpqkIcHzZOcSfZXGp5ozA8=",
      "url": "lib/bootstrap-icons/icons/patch-check.svg"
    },
    {
      "hash": "sha256-AbGlROaAcXw6gkwIvL16Ry6b8Mpp7ufOE6JW37m6cYM=",
      "url": "lib/bootstrap-icons/icons/patch-exclamation-fill.svg"
    },
    {
      "hash": "sha256-vNcMNMMi3iE/5ReDiJsV7ZA4XyXGgHzZtSyD0IBWdQk=",
      "url": "lib/bootstrap-icons/icons/patch-exclamation.svg"
    },
    {
      "hash": "sha256-fEBGzBWgMIweNBAK+TtPQ6l7HtBSOBpTAPjeVNfTGb8=",
      "url": "lib/bootstrap-icons/icons/patch-minus-fill.svg"
    },
    {
      "hash": "sha256-15CjVJeZRoYTuK8AIuKtPw2LXf/Tk7kOe8eMS7WxkSQ=",
      "url": "lib/bootstrap-icons/icons/patch-minus.svg"
    },
    {
      "hash": "sha256-mfKrW3w0phDbeBf4R3fuo+7KQmE1vlmSG7ZZ21g/Twk=",
      "url": "lib/bootstrap-icons/icons/patch-plus-fill.svg"
    },
    {
      "hash": "sha256-Q0MF7JUFYja2fV74MJQKN952Az6n49bl5fHhE8YnDH8=",
      "url": "lib/bootstrap-icons/icons/patch-plus.svg"
    },
    {
      "hash": "sha256-6ezZ0p90yXoJgOcCiiwcuLRfBwXwwWpAi+amwoVxCXo=",
      "url": "lib/bootstrap-icons/icons/patch-question-fill.svg"
    },
    {
      "hash": "sha256-2ZYOYs1c+P0urs0by3J72/sFX5G4de785+6kxHzB3cY=",
      "url": "lib/bootstrap-icons/icons/patch-question.svg"
    },
    {
      "hash": "sha256-WBjRyMXG2kFMBos7NfgNucpGXR53NBFVbUijZGG3RVg=",
      "url": "lib/bootstrap-icons/icons/pause-btn-fill.svg"
    },
    {
      "hash": "sha256-wvRl2+6KjnIlU+PfF6oEMVKPjfJMRud+6wV3MMNwZw4=",
      "url": "lib/bootstrap-icons/icons/pause-btn.svg"
    },
    {
      "hash": "sha256-QKeX7iu2yVevV3jCUY9+hfZY0Nrtlws8eBTs9QuZ6FE=",
      "url": "lib/bootstrap-icons/icons/pause-circle-fill.svg"
    },
    {
      "hash": "sha256-Fpp50AuKb3zsTBoy19/RPQdYXc04X77pbHFcAmVrNbE=",
      "url": "lib/bootstrap-icons/icons/pause-circle.svg"
    },
    {
      "hash": "sha256-unNCqFwKYYahJ/MfuTkZ5Xxj8pKYc2Y3W8lpB3x6MlE=",
      "url": "lib/bootstrap-icons/icons/pause-fill.svg"
    },
    {
      "hash": "sha256-h73409nNAKof7g9M7tG5JUQKdXvyllUVgCx9E8wmUfY=",
      "url": "lib/bootstrap-icons/icons/pause.svg"
    },
    {
      "hash": "sha256-9YIsgH7fM16zgwEWERc7llTG23z2tJzSdC0+RY8epDg=",
      "url": "lib/bootstrap-icons/icons/paypal.svg"
    },
    {
      "hash": "sha256-UWu7AMaPVesPz3vF19Rk6Ji//kgM7fAfJ8ZCT2SQts4=",
      "url": "lib/bootstrap-icons/icons/pc-display-horizontal.svg"
    },
    {
      "hash": "sha256-hBZsk+lwgwglVKHhlvDDXGd6+tD3R9fLyC3+jTz+Cuc=",
      "url": "lib/bootstrap-icons/icons/pc-display.svg"
    },
    {
      "hash": "sha256-AdWFzNgln8TkJelBXTZFkXLNNf621xzxNUCtlYf3gDI=",
      "url": "lib/bootstrap-icons/icons/pc-horizontal.svg"
    },
    {
      "hash": "sha256-5WC3Q2AgWNWzCMYLVVBzgRKtwls3V0OYdnePBkI1ylU=",
      "url": "lib/bootstrap-icons/icons/pc.svg"
    },
    {
      "hash": "sha256-AhD0Pr0PveAhW2pV+CYXV18u7VRX9nryH8K1TiA5JPk=",
      "url": "lib/bootstrap-icons/icons/pci-card-network.svg"
    },
    {
      "hash": "sha256-4CHvQ2Ulzy3WzsVVhIFP31cemTrrm5g+EyHp/hj1vRk=",
      "url": "lib/bootstrap-icons/icons/pci-card-sound.svg"
    },
    {
      "hash": "sha256-h2Fv4zeyQYcYtSt/VHedjZhwAXdDwu7IFuxoYnFljCc=",
      "url": "lib/bootstrap-icons/icons/pci-card.svg"
    },
    {
      "hash": "sha256-oD0nJttDOmrPUMdSpbxqvghIwpZV4G4oEb5E8kBeksU=",
      "url": "lib/bootstrap-icons/icons/peace-fill.svg"
    },
    {
      "hash": "sha256-swwMrqzSP3g/fTmZz7cJHlV4zlT9Mdyk16MbmaXZkco=",
      "url": "lib/bootstrap-icons/icons/peace.svg"
    },
    {
      "hash": "sha256-7vlomjiid4/2+LRkcYewZLK5ct9gpWvp++RODZgFsgY=",
      "url": "lib/bootstrap-icons/icons/pen-fill.svg"
    },
    {
      "hash": "sha256-VUn+l8IE16QsfindInnYQvo277lMTKiH8jLtK1krgFM=",
      "url": "lib/bootstrap-icons/icons/pen.svg"
    },
    {
      "hash": "sha256-ayrRpqPc15hymS8sCQZNZOChmeIlzgkmC0mpMzqdTPY=",
      "url": "lib/bootstrap-icons/icons/pencil-fill.svg"
    },
    {
      "hash": "sha256-734wdtapA0wZuye9DCV+cJaSvevCbY2diml43jdfqyA=",
      "url": "lib/bootstrap-icons/icons/pencil-square.svg"
    },
    {
      "hash": "sha256-V+EcLGMqtX6FpzccJheys5k372yBegYMUTiOG5Ppob0=",
      "url": "lib/bootstrap-icons/icons/pencil.svg"
    },
    {
      "hash": "sha256-nfMxflKZhYm0kHkOuniF0miM0jQn3dllLH6tSU+exbY=",
      "url": "lib/bootstrap-icons/icons/pentagon-fill.svg"
    },
    {
      "hash": "sha256-lMGo0URJf3Umjk94SqN2Vn8bd9sidiamHxHxnfhumG4=",
      "url": "lib/bootstrap-icons/icons/pentagon-half.svg"
    },
    {
      "hash": "sha256-I64DPKQYgCGQss5nOFwU7CXQ6IaYOYgVROztZdQnMEo=",
      "url": "lib/bootstrap-icons/icons/pentagon.svg"
    },
    {
      "hash": "sha256-tUaDpsyI589M2C7kJ8Ox5wzLErAwO5id6lOSnY6vpMA=",
      "url": "lib/bootstrap-icons/icons/people-fill.svg"
    },
    {
      "hash": "sha256-2bm5F5zg78fruq6+TZBdFgP/ZOlRWBUS/XinXIOQmfs=",
      "url": "lib/bootstrap-icons/icons/people.svg"
    },
    {
      "hash": "sha256-HtCRSFQ6sdkmREKhn7VZr5KytI4jRHhyhGher5KGE7w=",
      "url": "lib/bootstrap-icons/icons/percent.svg"
    },
    {
      "hash": "sha256-ibcPRBwrjomzo8P2F6GhLTfzW4DZuvxdWBQCoI0ZQ/c=",
      "url": "lib/bootstrap-icons/icons/person-add.svg"
    },
    {
      "hash": "sha256-iSpaWxH2LD32CnRoCo5qkobMc/2vrMo3ihfopH8y5rc=",
      "url": "lib/bootstrap-icons/icons/person-arms-up.svg"
    },
    {
      "hash": "sha256-0S3A5QdyoLptwwoe7UDAcB7a2L7GmagPwuDD6h1W1ZM=",
      "url": "lib/bootstrap-icons/icons/person-badge-fill.svg"
    },
    {
      "hash": "sha256-XS6bl7T+GVrcTEZ5xyQ5NNrtnFEB3dG76bjCfXmXScI=",
      "url": "lib/bootstrap-icons/icons/person-badge.svg"
    },
    {
      "hash": "sha256-0V/mfUHMBOCZTC8NI46l28VbpqxugqckqIWcGMLCDz0=",
      "url": "lib/bootstrap-icons/icons/person-bounding-box.svg"
    },
    {
      "hash": "sha256-O+zTHopaNmtnT1dDMxsZ4w79dcbl5AZdg6KndlGfEnw=",
      "url": "lib/bootstrap-icons/icons/person-check-fill.svg"
    },
    {
      "hash": "sha256-Sx6eChHFmoVmcEkjvVQF45/+z6zrlg2KAiK6/419tR4=",
      "url": "lib/bootstrap-icons/icons/person-check.svg"
    },
    {
      "hash": "sha256-vJ909ASDAVbBrg3qEHAWibZ9JVujKMm6ma283ru4BAs=",
      "url": "lib/bootstrap-icons/icons/person-circle.svg"
    },
    {
      "hash": "sha256-wEfReo/04L2foNSwBDbqUyB9AlgaYNLtclDONZGn0nY=",
      "url": "lib/bootstrap-icons/icons/person-dash-fill.svg"
    },
    {
      "hash": "sha256-5Hppf851HSrtoprb3bpeZQ11JpwoCW4ZXqy1eG/gy6Q=",
      "url": "lib/bootstrap-icons/icons/person-dash.svg"
    },
    {
      "hash": "sha256-jm64dHn66ZlncSRWWlolRYcOU8FkdhaPcPO6POboB74=",
      "url": "lib/bootstrap-icons/icons/person-down.svg"
    },
    {
      "hash": "sha256-4TD/eM/Ic2DaoWLc9caovVh9QzY+H4Czm1eAaZuJZ5w=",
      "url": "lib/bootstrap-icons/icons/person-exclamation.svg"
    },
    {
      "hash": "sha256-qRv3aeW1TeekTCKGY+f7it8rNoube9ZQd00ohoR561k=",
      "url": "lib/bootstrap-icons/icons/person-fill-add.svg"
    },
    {
      "hash": "sha256-pv/Js39jXfvxK+4rq/Ck/ohDVpYPIXq8iqhYDx6Hf10=",
      "url": "lib/bootstrap-icons/icons/person-fill-check.svg"
    },
    {
      "hash": "sha256-drmNmcmyayqGW4RFiqq5wlR6BzL5e5VhquwLd7/0sm0=",
      "url": "lib/bootstrap-icons/icons/person-fill-dash.svg"
    },
    {
      "hash": "sha256-BmT2eEhsuCZgmpliaQADDcwn1Kqdk5+Wel948sdlXkA=",
      "url": "lib/bootstrap-icons/icons/person-fill-down.svg"
    },
    {
      "hash": "sha256-MRs0/jFtvwVnEisVfQSeVYZKSy/uXpWMmnbQpLYtExY=",
      "url": "lib/bootstrap-icons/icons/person-fill-exclamation.svg"
    },
    {
      "hash": "sha256-6IqE7HHEPQYmLUb2D4OZ4zm2UJ3R8teI2HVM5Fa6Rng=",
      "url": "lib/bootstrap-icons/icons/person-fill-gear.svg"
    },
    {
      "hash": "sha256-Oj+RrVhDpopkiye4i7APPAAknp3TMmdD5DZ1nkI6QQM=",
      "url": "lib/bootstrap-icons/icons/person-fill-lock.svg"
    },
    {
      "hash": "sha256-zhPvaveM+7ZmdLqBQ4j3ofBlAYHowIQkYnyujuMWGmM=",
      "url": "lib/bootstrap-icons/icons/person-fill-slash.svg"
    },
    {
      "hash": "sha256-qU6/Vte0PCYAJ7QwIBgXr2pAkhxnvdkxUuVv7pcx4+Q=",
      "url": "lib/bootstrap-icons/icons/person-fill-up.svg"
    },
    {
      "hash": "sha256-q7w9rkJV2Prb0W1bg2Km/vXxDuBIBJHlr/QwxffYp3o=",
      "url": "lib/bootstrap-icons/icons/person-fill-x.svg"
    },
    {
      "hash": "sha256-qPhLqiXYtNKrMmG7UC7+neY0uQYx8snY04Yz4ezIf/0=",
      "url": "lib/bootstrap-icons/icons/person-fill.svg"
    },
    {
      "hash": "sha256-hwfUYwX1pzXrs+E6Y0S/Tkcti/zrdBedeEONdENadZc=",
      "url": "lib/bootstrap-icons/icons/person-gear.svg"
    },
    {
      "hash": "sha256-olvOIP4ZG0hLL8KnqY1henwyNqI0bYBVXo/66NS1Ir4=",
      "url": "lib/bootstrap-icons/icons/person-heart.svg"
    },
    {
      "hash": "sha256-b5zoA77Vn/3zZvdRf6JZTfZ1BbpFSzNCmMAoAk7u2iE=",
      "url": "lib/bootstrap-icons/icons/person-hearts.svg"
    },
    {
      "hash": "sha256-CjSZPCu1ZUmbejJU2G+SJ5mXw6DahrH0GZjvbH4DUyA=",
      "url": "lib/bootstrap-icons/icons/person-lines-fill.svg"
    },
    {
      "hash": "sha256-kjZrAN79HcONo60XPRvxV9K7spUN1Fu0eoQH/fZymUY=",
      "url": "lib/bootstrap-icons/icons/person-lock.svg"
    },
    {
      "hash": "sha256-My00k4s71oFpjRUavGNRNqY2ejtGqNINuvbRbMDeiiU=",
      "url": "lib/bootstrap-icons/icons/person-plus-fill.svg"
    },
    {
      "hash": "sha256-scCguKAKU4xFa45m9mwLKhzX42NKX4FhcU7TAEuBNRw=",
      "url": "lib/bootstrap-icons/icons/person-plus.svg"
    },
    {
      "hash": "sha256-m+bqlKLgHhbO5vEVMMWKdT7x1LrvXSR958AOH1nW8c0=",
      "url": "lib/bootstrap-icons/icons/person-raised-hand.svg"
    },
    {
      "hash": "sha256-/HrlJ05bHohisXbZHWzLNmPzEPqEK8HCfR/Auos9Pt4=",
      "url": "lib/bootstrap-icons/icons/person-rolodex.svg"
    },
    {
      "hash": "sha256-WRqzDAGEIMZLNLRH497+68gWTOqXwFTurBUvJ64VURo=",
      "url": "lib/bootstrap-icons/icons/person-slash.svg"
    },
    {
      "hash": "sha256-0itqiJzs7GamBGQeNju/1Js2udeRYhkog3pqkDUazwM=",
      "url": "lib/bootstrap-icons/icons/person-square.svg"
    },
    {
      "hash": "sha256-MzDWIo4zU79t3l2x7LE1w3QpE6GHi3HVKGmvbAAdAgw=",
      "url": "lib/bootstrap-icons/icons/person-standing-dress.svg"
    },
    {
      "hash": "sha256-wFPOfRlrPWWTrS0RPirBvMMIpblXERzT8hIqD0fFWIs=",
      "url": "lib/bootstrap-icons/icons/person-standing.svg"
    },
    {
      "hash": "sha256-5j6//6KwQA3IXMDk/0n1cHPmkz6iHc9qSHYB2yQPBtk=",
      "url": "lib/bootstrap-icons/icons/person-up.svg"
    },
    {
      "hash": "sha256-ATwhJdQyd7g2dOVSvuJuXlp+RXXnZtKiBP2T2H/4Lxc=",
      "url": "lib/bootstrap-icons/icons/person-vcard-fill.svg"
    },
    {
      "hash": "sha256-tEwxeNjOnWMYar6DIS1n2r9Lk5o6TXNuI2OXpGD0tM4=",
      "url": "lib/bootstrap-icons/icons/person-vcard.svg"
    },
    {
      "hash": "sha256-YkzYDEFB5EVxEZUWCXDZ+L6kjRy99OGdKYStrd3LxJk=",
      "url": "lib/bootstrap-icons/icons/person-video.svg"
    },
    {
      "hash": "sha256-vmHw9UFb6FkyCSGSEcGY7pxvel/o2Y0XJDgNgFUTfxY=",
      "url": "lib/bootstrap-icons/icons/person-video2.svg"
    },
    {
      "hash": "sha256-ZTx7haY00rpDpuQJ8oO6Jxl5i0q/dMVK6WrEBuCKSKI=",
      "url": "lib/bootstrap-icons/icons/person-video3.svg"
    },
    {
      "hash": "sha256-G/fW114be7mevIZPsTAJTJAXeuCz0ts2eW2KwNID1qc=",
      "url": "lib/bootstrap-icons/icons/person-walking.svg"
    },
    {
      "hash": "sha256-beS1xp6SJBrIuhLUNMk65NGqeE34gdsZUMc8PCpB724=",
      "url": "lib/bootstrap-icons/icons/person-wheelchair.svg"
    },
    {
      "hash": "sha256-tV0EGsu5DOXYfieEnxXDuQzJ0lyY02bQ5Rh0ZnQN9bY=",
      "url": "lib/bootstrap-icons/icons/person-workspace.svg"
    },
    {
      "hash": "sha256-UmcyYVDMQYHSlHp5DjWaZWG0KEkxwmqM1dKDYWsE7D8=",
      "url": "lib/bootstrap-icons/icons/person-x-fill.svg"
    },
    {
      "hash": "sha256-7H48YX+wVghz3Fc1WxYEXAoEo9gCMOr+q/x0Vf7BlQw=",
      "url": "lib/bootstrap-icons/icons/person-x.svg"
    },
    {
      "hash": "sha256-zAXyKPVFIVbpgbjEcj5tljNkOYjzFrqeAnkNf1OZoiE=",
      "url": "lib/bootstrap-icons/icons/person.svg"
    },
    {
      "hash": "sha256-8d514A19Fytoy/KCHqe5bSuUT7NOnb7mkZ+F6a+Fwlg=",
      "url": "lib/bootstrap-icons/icons/phone-fill.svg"
    },
    {
      "hash": "sha256-2XmHxq2i5VZaEeeKdhSy2Kf0EyJkpwEvlSfoDU+YJl8=",
      "url": "lib/bootstrap-icons/icons/phone-flip.svg"
    },
    {
      "hash": "sha256-5aHZihGpRipTAvcvPxOVXAu7JU9GMLQ1j9XHo+YGn/o=",
      "url": "lib/bootstrap-icons/icons/phone-landscape-fill.svg"
    },
    {
      "hash": "sha256-luGYf8e4K/hZiTPCcFZgyafUByOmQY51ytlaGmHy1ko=",
      "url": "lib/bootstrap-icons/icons/phone-landscape.svg"
    },
    {
      "hash": "sha256-5CiUoocTYyDaLTvBX3k7zkNTCyyMjjMDXTS2y237uHs=",
      "url": "lib/bootstrap-icons/icons/phone-vibrate-fill.svg"
    },
    {
      "hash": "sha256-kTqV6fPmaVkUG/xrWFs90+hbmWMtDLPo9nVgf/7xVUU=",
      "url": "lib/bootstrap-icons/icons/phone-vibrate.svg"
    },
    {
      "hash": "sha256-l1O65OeKbT2lS6/Y/Ad6iR+qlDO43jkzgKWuDutSsFc=",
      "url": "lib/bootstrap-icons/icons/phone.svg"
    },
    {
      "hash": "sha256-YgxnlRO2ePISL0BOrlrBzMQ9xVeaGmfV6Sqb0bF3qBQ=",
      "url": "lib/bootstrap-icons/icons/pie-chart-fill.svg"
    },
    {
      "hash": "sha256-Ur8Bn8yVI0JYvfHX5X1bMuq+NEPtVPuJGKeeThwpBMA=",
      "url": "lib/bootstrap-icons/icons/pie-chart.svg"
    },
    {
      "hash": "sha256-nkVL2vPnHIp9lH+f62ziBXsB2AMUmfDjIsJBB+fXaLY=",
      "url": "lib/bootstrap-icons/icons/piggy-bank-fill.svg"
    },
    {
      "hash": "sha256-fdQzR97mbIRHu370VFVlUMsqkurui4SbTuKHcJWVJY4=",
      "url": "lib/bootstrap-icons/icons/piggy-bank.svg"
    },
    {
      "hash": "sha256-TpXOp0AkeDKDZ3DdQchThVtZ0WDK0bPV3SdNfejabMU=",
      "url": "lib/bootstrap-icons/icons/pin-angle-fill.svg"
    },
    {
      "hash": "sha256-YdC8lHEFHpWBnf/1Ez/A0rP0lsNZyA/yFa4SFpSY17A=",
      "url": "lib/bootstrap-icons/icons/pin-angle.svg"
    },
    {
      "hash": "sha256-iUajEaCK13sDh64fE9sOU3ub7HJJnrH9MVShJPm5wlA=",
      "url": "lib/bootstrap-icons/icons/pin-fill.svg"
    },
    {
      "hash": "sha256-/hW8FdJsYdUViaXn5hNqVL2zM9A2/VNTxONICrlSQ2Q=",
      "url": "lib/bootstrap-icons/icons/pin-map-fill.svg"
    },
    {
      "hash": "sha256-mE0emnttKzJvQBo5dl6FonlKwOtrnoadYhRJwlToKe0=",
      "url": "lib/bootstrap-icons/icons/pin-map.svg"
    },
    {
      "hash": "sha256-kA/YkQtHk/ejifMIlMD8/Q8cn3L0o0pZneGG6sccn44=",
      "url": "lib/bootstrap-icons/icons/pin.svg"
    },
    {
      "hash": "sha256-iMCiUqdLljbVPJfpkQYQDbmyLu2MuQKcQEgRt3B36SQ=",
      "url": "lib/bootstrap-icons/icons/pinterest.svg"
    },
    {
      "hash": "sha256-uqWyudAnikXd73ciN1OFQrX7TSJvG7+4ROepdS8aABA=",
      "url": "lib/bootstrap-icons/icons/pip-fill.svg"
    },
    {
      "hash": "sha256-XjwVpTgXGTNEqVB00JYIPweckKCtF9SRgQq3LYgcG90=",
      "url": "lib/bootstrap-icons/icons/pip.svg"
    },
    {
      "hash": "sha256-APc0vzqC0VZOgmMtCzkxihFkGv+dWBbfGm72LP0fk94=",
      "url": "lib/bootstrap-icons/icons/play-btn-fill.svg"
    },
    {
      "hash": "sha256-OyO51yJCTmFISZpTsGpJZQuUvP4fE3uRQflmjGl/XXw=",
      "url": "lib/bootstrap-icons/icons/play-btn.svg"
    },
    {
      "hash": "sha256-l6Kiy1R+qXgzv9bLwUba7cOVwAnk3biyg/Jin0UwB8Q=",
      "url": "lib/bootstrap-icons/icons/play-circle-fill.svg"
    },
    {
      "hash": "sha256-FyWqxX23yQ5bVfMFnJYunJwx87r61QN6WJLE6GnaRb0=",
      "url": "lib/bootstrap-icons/icons/play-circle.svg"
    },
    {
      "hash": "sha256-0vpn7/ydaRUCAWyp7xi9EAsaXJ39bjo+1nSOUNRpNS4=",
      "url": "lib/bootstrap-icons/icons/play-fill.svg"
    },
    {
      "hash": "sha256-IhiqMgjBA0WgKAv35lHfUJUXgeKcz8KoOp1IDzKi0Bg=",
      "url": "lib/bootstrap-icons/icons/play.svg"
    },
    {
      "hash": "sha256-kDzW2Xm+BxGfJtCf4WnLJpByOi+hZN90LC9BzJpQ5Ig=",
      "url": "lib/bootstrap-icons/icons/playstation.svg"
    },
    {
      "hash": "sha256-a528J0g6gNVxPHEr2eY3M0zlvtQmH7FMND3dpwh5nAI=",
      "url": "lib/bootstrap-icons/icons/plug-fill.svg"
    },
    {
      "hash": "sha256-i024IFBVRWXcwymhgHCyBPdQ8rl1eLwwMg2LWuPgxMU=",
      "url": "lib/bootstrap-icons/icons/plug.svg"
    },
    {
      "hash": "sha256-MJ2RbU8g+zw5xWmaZlhki09xt/WSPhz2EytSjyw6OG0=",
      "url": "lib/bootstrap-icons/icons/plugin.svg"
    },
    {
      "hash": "sha256-r41oxrSpFEFwWGN5z9ldNFIXgBDxo5LzcfQ/YFWGYZg=",
      "url": "lib/bootstrap-icons/icons/plus-circle-dotted.svg"
    },
    {
      "hash": "sha256-UIIFGrZ2478UX7sLeb9Y2jTXkBvL/b0zsVwmrNe5Rfw=",
      "url": "lib/bootstrap-icons/icons/plus-circle-fill.svg"
    },
    {
      "hash": "sha256-KrV3IGTt0mpkGOMjsuGLLvaZsaPW5XrMCSB18aeZvHA=",
      "url": "lib/bootstrap-icons/icons/plus-circle.svg"
    },
    {
      "hash": "sha256-jTlUOH4Utpa4h/8wEd0jIbXxOtWVDqFv9mKPAZ9cAdQ=",
      "url": "lib/bootstrap-icons/icons/plus-lg.svg"
    },
    {
      "hash": "sha256-mmjHW+IbxXkV8ETWQVTi3km/rGOl201priXoYQDNQH8=",
      "url": "lib/bootstrap-icons/icons/plus-slash-minus.svg"
    },
    {
      "hash": "sha256-0utPhOQoo8r8OaJcAFzPSEpnniCoGic0agL/8J2fhyo=",
      "url": "lib/bootstrap-icons/icons/plus-square-dotted.svg"
    },
    {
      "hash": "sha256-W6jJnFuAENhoDDebPiQoj9LfvAVqdZwohtv42GFkN3I=",
      "url": "lib/bootstrap-icons/icons/plus-square-fill.svg"
    },
    {
      "hash": "sha256-UnnaRS/sFTHUzw/bzQFDxLh7w5odKrDN4Un7Sj8pb8I=",
      "url": "lib/bootstrap-icons/icons/plus-square.svg"
    },
    {
      "hash": "sha256-+sDQzLElOj7BJLnKP2Q0A2NT37AureKeUA4TY3tvWAE=",
      "url": "lib/bootstrap-icons/icons/plus.svg"
    },
    {
      "hash": "sha256-Ar2QXpy3pdSxcqbY9XUpM8ahzYTMmdGjI+yNhc7S5aE=",
      "url": "lib/bootstrap-icons/icons/postage-fill.svg"
    },
    {
      "hash": "sha256-nQXcKDeNI3S2Oc/8DYn/E4J6lZgk+2vu/rASYvRl13k=",
      "url": "lib/bootstrap-icons/icons/postage-heart-fill.svg"
    },
    {
      "hash": "sha256-zOEmFVPm1FFDtVMcQjRX9fAfDpQBb+gpBhxkr6RmMH4=",
      "url": "lib/bootstrap-icons/icons/postage-heart.svg"
    },
    {
      "hash": "sha256-3YA7yja24TK93LBIFYu06Va82w1PN6MA9qp/vJciVFM=",
      "url": "lib/bootstrap-icons/icons/postage.svg"
    },
    {
      "hash": "sha256-R87v5oXU8DhAVlnfZE/zy6Ezv2Y2DUYl+sDNHWMN5qc=",
      "url": "lib/bootstrap-icons/icons/postcard-fill.svg"
    },
    {
      "hash": "sha256-NFcAvpRXbqFt61yW/stPQ87L00ATMpM3MiiLGyJDxG4=",
      "url": "lib/bootstrap-icons/icons/postcard-heart-fill.svg"
    },
    {
      "hash": "sha256-V1KTwkwXhA7O4m3SF+tGMaiLFQzVsgPQUFrW/fH2Hg4=",
      "url": "lib/bootstrap-icons/icons/postcard-heart.svg"
    },
    {
      "hash": "sha256-31B7LqmUl6FpI9U/JutqfMYUsmCvHgUAbL5dFQr1c8E=",
      "url": "lib/bootstrap-icons/icons/postcard.svg"
    },
    {
      "hash": "sha256-KyCeQVaetJIgdNFhjb0gjpZKBtZNLuO7rykwQM3mj/0=",
      "url": "lib/bootstrap-icons/icons/power.svg"
    },
    {
      "hash": "sha256-LBAQW0l/NQHT5t+y6jkfXCyZRgrsOv3rPH3pu+4Hl90=",
      "url": "lib/bootstrap-icons/icons/prescription.svg"
    },
    {
      "hash": "sha256-SySMez562nkQo9vzYV7vhxm3bu17tzaCHeXoI8aJMnY=",
      "url": "lib/bootstrap-icons/icons/prescription2.svg"
    },
    {
      "hash": "sha256-HNWY/eGub5j+VOh5Dp5oG898VB8a2h0MfSb3/5/7mNo=",
      "url": "lib/bootstrap-icons/icons/printer-fill.svg"
    },
    {
      "hash": "sha256-V4uWNsuQV6qV0xkzxdkx62iW+M9NftoW4pPqeS6OKHg=",
      "url": "lib/bootstrap-icons/icons/printer.svg"
    },
    {
      "hash": "sha256-P8G//9AgQs6US9NCiPaq0wDZUe6yvUW/eMqxV5kSa8E=",
      "url": "lib/bootstrap-icons/icons/projector-fill.svg"
    },
    {
      "hash": "sha256-AI7LFPk4GcVHkSM7+GPqzFne4p5I3ucH9+GbsHzzmn4=",
      "url": "lib/bootstrap-icons/icons/projector.svg"
    },
    {
      "hash": "sha256-JIXVF7Ur/Q32Sy51Dl/wI2r0THvJ87ZMAYf+/jeQRkw=",
      "url": "lib/bootstrap-icons/icons/puzzle-fill.svg"
    },
    {
      "hash": "sha256-D3PtZU/odMXmffXz6TAtWYtqSYqvI6CAHBbWBtfb7kw=",
      "url": "lib/bootstrap-icons/icons/puzzle.svg"
    },
    {
      "hash": "sha256-uYWzdwcfZr13cqTBXZrHc+27A/vRreiraPV0eSi2pns=",
      "url": "lib/bootstrap-icons/icons/qr-code-scan.svg"
    },
    {
      "hash": "sha256-c49AJhoMyxYAuyEFvo1aYX95GjwXTAHfpJPD5BpgSFg=",
      "url": "lib/bootstrap-icons/icons/qr-code.svg"
    },
    {
      "hash": "sha256-KFSsbjaMOFe/5ZHBYhD3Rx01cB/pXAtZqG6NPjzgGP8=",
      "url": "lib/bootstrap-icons/icons/question-circle-fill.svg"
    },
    {
      "hash": "sha256-1OlufOb1mKnp/ePn7AGaLLQSTJwSbOXI3I3aRFDNEC4=",
      "url": "lib/bootstrap-icons/icons/question-circle.svg"
    },
    {
      "hash": "sha256-wrtOBQCBWCbnflRk3yznRFnVUSsH0dihTcK0QF4DmuI=",
      "url": "lib/bootstrap-icons/icons/question-diamond-fill.svg"
    },
    {
      "hash": "sha256-rncX/YzHgUfhG64RJ4HmgSNV3gFHhpiirr4ur1tyIvE=",
      "url": "lib/bootstrap-icons/icons/question-diamond.svg"
    },
    {
      "hash": "sha256-vCORrVke/YamIOceoNo4+mh/ZqleF1fDGlAQZ+k7tXA=",
      "url": "lib/bootstrap-icons/icons/question-lg.svg"
    },
    {
      "hash": "sha256-o6soVR+GfDpiUkIIDbd6Mbgp/IofnatnGUKqTxwftwY=",
      "url": "lib/bootstrap-icons/icons/question-octagon-fill.svg"
    },
    {
      "hash": "sha256-OxJA3gYtgswJpgmAFU6JYj+drxVNihL67uoTiUxeEpQ=",
      "url": "lib/bootstrap-icons/icons/question-octagon.svg"
    },
    {
      "hash": "sha256-1FHHfJQo78xr7uBi2mGbKKMvGhPQwR0mvJMzlo5Kvy4=",
      "url": "lib/bootstrap-icons/icons/question-square-fill.svg"
    },
    {
      "hash": "sha256-iW37AD6QeEPyPbuP51Kx7M2cHIfk9lQ4gfF8CU9A5Aw=",
      "url": "lib/bootstrap-icons/icons/question-square.svg"
    },
    {
      "hash": "sha256-+rB/BmStDRPggO/oZ/xg1VIHkwmFKS352LekxuYszx8=",
      "url": "lib/bootstrap-icons/icons/question.svg"
    },
    {
      "hash": "sha256-d9OKVaGxfTGNYwesxJLPdK9Y0Q96MnCtThnb/gAvydk=",
      "url": "lib/bootstrap-icons/icons/quora.svg"
    },
    {
      "hash": "sha256-wHBIkIHVdWy6tZkjSY9u75l0ipswOJGmFW/zf02ID2U=",
      "url": "lib/bootstrap-icons/icons/quote.svg"
    },
    {
      "hash": "sha256-80K2vIVzM1MjGI/ikBeFcb0KaoGvkO6Xqg/cNVuq+y8=",
      "url": "lib/bootstrap-icons/icons/r-circle-fill.svg"
    },
    {
      "hash": "sha256-EJtRrIH1VLolkgGSl98/DjvpvBDm9yxVN72P0y3eroY=",
      "url": "lib/bootstrap-icons/icons/r-circle.svg"
    },
    {
      "hash": "sha256-VGchRxFJw/fasUAu3sckRMbiEXq2KDIzx/jj9an0STM=",
      "url": "lib/bootstrap-icons/icons/r-square-fill.svg"
    },
    {
      "hash": "sha256-GKf1vvspmJfM4+rg6BFeUAdGaVVwtpum6IXAx+WEYQo=",
      "url": "lib/bootstrap-icons/icons/r-square.svg"
    },
    {
      "hash": "sha256-0B9+Y+19UEynmlQIkUyi0Ruaxa3oMUcN2wjh3q6V7uU=",
      "url": "lib/bootstrap-icons/icons/radar.svg"
    },
    {
      "hash": "sha256-lZoItXFMLgN2WQ1PFVVHEOvB+sg7XPZ6Lzmqo7zYbM0=",
      "url": "lib/bootstrap-icons/icons/radioactive.svg"
    },
    {
      "hash": "sha256-rjF+9n2ERZVJQ33uLsx9MnCQfgwzJV07OWmEzsVpSwo=",
      "url": "lib/bootstrap-icons/icons/rainbow.svg"
    },
    {
      "hash": "sha256-b5SQGLSLMTo6FuWgyqRyhiUbCkGVgQZemNi8ipXhwc0=",
      "url": "lib/bootstrap-icons/icons/receipt-cutoff.svg"
    },
    {
      "hash": "sha256-5XzgorzIn0cIYsLZJG0VgdubkayMTc8G5a8TEa7GTv0=",
      "url": "lib/bootstrap-icons/icons/receipt.svg"
    },
    {
      "hash": "sha256-95wbX1ZPZS9ilsWDZUxVltvenLDb9MGIxlYHpTK/Kmc=",
      "url": "lib/bootstrap-icons/icons/reception-0.svg"
    },
    {
      "hash": "sha256-thAx4J+IKnwIywFAr4kE1+U631UTLorjYe1S6cysnZQ=",
      "url": "lib/bootstrap-icons/icons/reception-1.svg"
    },
    {
      "hash": "sha256-IKWGEGl6C0VYRq8ljm/2wpmZU96fHDWi2K3kSEz1yLs=",
      "url": "lib/bootstrap-icons/icons/reception-2.svg"
    },
    {
      "hash": "sha256-MuNg4yCRLDW89RHQcZwOjJW/WVi6TpDcMOujqqLKndU=",
      "url": "lib/bootstrap-icons/icons/reception-3.svg"
    },
    {
      "hash": "sha256-lwFwdPCaiQ5F+5mFY808DvRGxN0rI+2fjjnTPR26Nhw=",
      "url": "lib/bootstrap-icons/icons/reception-4.svg"
    },
    {
      "hash": "sha256-QGGllYtkdMtUBO02oqSS2SVE0v+YQsHBSyczX7KOI7E=",
      "url": "lib/bootstrap-icons/icons/record-btn-fill.svg"
    },
    {
      "hash": "sha256-sV63j75apAn5YCn+VIhqdI2PJzehCTpbRCPzo2QDfvQ=",
      "url": "lib/bootstrap-icons/icons/record-btn.svg"
    },
    {
      "hash": "sha256-Ql3tm1eCM9K9vNG9eEeagyQV5qmP/naQ0796GJ1elTA=",
      "url": "lib/bootstrap-icons/icons/record-circle-fill.svg"
    },
    {
      "hash": "sha256-GCZZajly8N1wCvXUc8qxEp1HUV/PvJtC6oFD+8H+WIM=",
      "url": "lib/bootstrap-icons/icons/record-circle.svg"
    },
    {
      "hash": "sha256-g12iB2mxqfe9gTiVbIjSBArNBneUwyJf1RWrx1QyGj4=",
      "url": "lib/bootstrap-icons/icons/record-fill.svg"
    },
    {
      "hash": "sha256-jnooaYAdWMGZ7IDcJkTVybb6ijaEpAOOT0cu1eeX9UQ=",
      "url": "lib/bootstrap-icons/icons/record.svg"
    },
    {
      "hash": "sha256-bgn/FOkVfIaVkXusv9odo93XovoCKg47LhJD+m7EQxI=",
      "url": "lib/bootstrap-icons/icons/record2-fill.svg"
    },
    {
      "hash": "sha256-WKM6O1HYZi3eLlzsGRt1sQDPhIXEDFoTn33A+Rgedcg=",
      "url": "lib/bootstrap-icons/icons/record2.svg"
    },
    {
      "hash": "sha256-sKtGqCQeA2JYEw0q2YosGfIx1Kr07ATLGfW5YSTfsCY=",
      "url": "lib/bootstrap-icons/icons/recycle.svg"
    },
    {
      "hash": "sha256-EW4L8QElBM1uXlCyLwegm7gG+fQHG2bdYuBKdv+8LEo=",
      "url": "lib/bootstrap-icons/icons/reddit.svg"
    },
    {
      "hash": "sha256-BUK8KuQoN2shfbphVerzvMC4HUtSQaB4MnS5XQOhtOE=",
      "url": "lib/bootstrap-icons/icons/regex.svg"
    },
    {
      "hash": "sha256-oIRhWqz+XU67QkP4KVlNvxl520Jh1Rc6H0uARGfvT9k=",
      "url": "lib/bootstrap-icons/icons/repeat-1.svg"
    },
    {
      "hash": "sha256-JEwiB7VNShUy9yBEpKwPt88AMWKVS72KFYUpCWg5Yik=",
      "url": "lib/bootstrap-icons/icons/repeat.svg"
    },
    {
      "hash": "sha256-UHWnk6V9wV/95bE7ysRjJ4q1PvBtPMZnh4ts1PE1Muc=",
      "url": "lib/bootstrap-icons/icons/reply-all-fill.svg"
    },
    {
      "hash": "sha256-O8dfGGnrJyubx1NfdBuFi7+HBSzzLdqMzyVDDB4bpCU=",
      "url": "lib/bootstrap-icons/icons/reply-all.svg"
    },
    {
      "hash": "sha256-vHFDONvL462C69jWEtdTKivoBwQ3n5U4ZSQft+P0Ra4=",
      "url": "lib/bootstrap-icons/icons/reply-fill.svg"
    },
    {
      "hash": "sha256-f5yigcNpdnzTTSDwKtEgbUpt84VzFnDXPbDgJefPVxU=",
      "url": "lib/bootstrap-icons/icons/reply.svg"
    },
    {
      "hash": "sha256-O1/P98BcHHXqgZ5kJdmgSpG5X/O1fNHciXnibCgbTyI=",
      "url": "lib/bootstrap-icons/icons/rewind-btn-fill.svg"
    },
    {
      "hash": "sha256-3OghZgUhav41wgrYcAwIHAcYJaZd6X4Ldj2U913GIlI=",
      "url": "lib/bootstrap-icons/icons/rewind-btn.svg"
    },
    {
      "hash": "sha256-E1N0+5PlfAK5F9U2NQGElOCiiytXUWXt1pap9xuRjxQ=",
      "url": "lib/bootstrap-icons/icons/rewind-circle-fill.svg"
    },
    {
      "hash": "sha256-WzkwnG745i7v37mSDLwHPyca33X9YBAfVyjJWaZW8xw=",
      "url": "lib/bootstrap-icons/icons/rewind-circle.svg"
    },
    {
      "hash": "sha256-cdj41eqYRedFk4n/d6T72n0Ae/gmT5M0vPkx1CWJvcQ=",
      "url": "lib/bootstrap-icons/icons/rewind-fill.svg"
    },
    {
      "hash": "sha256-0znapg9IOWSysX5Q4nhpMLw/AIJ5e+6tZ0S+BkEZ8Js=",
      "url": "lib/bootstrap-icons/icons/rewind.svg"
    },
    {
      "hash": "sha256-34z9YWqRlGKOJg5tQ5JET8ytHLoXekT+jiD3rzi3FVA=",
      "url": "lib/bootstrap-icons/icons/robot.svg"
    },
    {
      "hash": "sha256-YGtAg5z8Od6o8rWJ6XBGnCoKuXXUxkUU7kWqqwRhnvY=",
      "url": "lib/bootstrap-icons/icons/rocket-fill.svg"
    },
    {
      "hash": "sha256-f5Yz6H2JUhHJ1CxlwZW0NkW4PLZ+EYYvAztNTaN/bzk=",
      "url": "lib/bootstrap-icons/icons/rocket-takeoff-fill.svg"
    },
    {
      "hash": "sha256-BJQ0nJmvQEksLCthf8EBJGQVMH3ovfJjhqX3TmB5lSY=",
      "url": "lib/bootstrap-icons/icons/rocket-takeoff.svg"
    },
    {
      "hash": "sha256-Z3mP5FeLv5cU5tfSbUApqIMSpeG4iHY/4GT4vRcFvEI=",
      "url": "lib/bootstrap-icons/icons/rocket.svg"
    },
    {
      "hash": "sha256-2n2uU4wXmXyQ3RGH124z/UGh0IO9Q8zohCtJxOzQoM4=",
      "url": "lib/bootstrap-icons/icons/router-fill.svg"
    },
    {
      "hash": "sha256-kn7+o68l64hDFufFx0S5JI4/c7MkKMUcbrqx/sWT3Y4=",
      "url": "lib/bootstrap-icons/icons/router.svg"
    },
    {
      "hash": "sha256-mPeFK7cbOi2/S38WoM4S8wsW7/avDp8ohPp81W0Gsj0=",
      "url": "lib/bootstrap-icons/icons/rss-fill.svg"
    },
    {
      "hash": "sha256-VwAw3AgS6UZD4qseHzGN+LrxJSuqWlWCiL08+PMDq9E=",
      "url": "lib/bootstrap-icons/icons/rss.svg"
    },
    {
      "hash": "sha256-UfKGidDaYh7jYF+0xAZHvOLWRqWPp5qSrGnUWeL3xPo=",
      "url": "lib/bootstrap-icons/icons/rulers.svg"
    },
    {
      "hash": "sha256-v0229slHY+d0I7Shon4AH9/77x9HnYHPcc8BYikkm8s=",
      "url": "lib/bootstrap-icons/icons/safe-fill.svg"
    },
    {
      "hash": "sha256-1ryGVxKV1HnuwRAPqwSd1XTGohwW5j2auYiwHDePXxI=",
      "url": "lib/bootstrap-icons/icons/safe.svg"
    },
    {
      "hash": "sha256-Dt2PEDm4j3kOWIJquXjtnBlrhk7BIQtxMmPDBY5y1Mg=",
      "url": "lib/bootstrap-icons/icons/safe2-fill.svg"
    },
    {
      "hash": "sha256-1zkl8eo12qTsC+d2Es9kMAuefSnEk/JigFk1Iq8Gzoc=",
      "url": "lib/bootstrap-icons/icons/safe2.svg"
    },
    {
      "hash": "sha256-YLAGd/88gOsCIojrgJnXJeJhThTOObf0cwxbRX+s2JI=",
      "url": "lib/bootstrap-icons/icons/save-fill.svg"
    },
    {
      "hash": "sha256-Om3Dybj7+F9jj1eSWS52sgxThf2ARD29k8YHvcfd+4k=",
      "url": "lib/bootstrap-icons/icons/save.svg"
    },
    {
      "hash": "sha256-4RcxZWN4JQ6jkROzewKdc0RNnlCH4uPh67/o2nHQS+E=",
      "url": "lib/bootstrap-icons/icons/save2-fill.svg"
    },
    {
      "hash": "sha256-W3GwP2QxZPslKPQ+j+eUwtoXrlSrH3Vv2eiFTf5VghA=",
      "url": "lib/bootstrap-icons/icons/save2.svg"
    },
    {
      "hash": "sha256-+EieVPiibZnJnxUMmkmLCgk5PdnVqK1KwBD4RM5lXtA=",
      "url": "lib/bootstrap-icons/icons/scissors.svg"
    },
    {
      "hash": "sha256-+MKyi27bo57i4JZ6tNEJadHQtTUxAHI6/qLKowLxDlg=",
      "url": "lib/bootstrap-icons/icons/scooter.svg"
    },
    {
      "hash": "sha256-t0A7gnZCFs64KZHEXG8E9HFV50lJKriPYxtLpBGHmmI=",
      "url": "lib/bootstrap-icons/icons/screwdriver.svg"
    },
    {
      "hash": "sha256-SZtdrSg6lVrKbEZQxYfDHt7gWlDZwZxZ/sJRbBwAduk=",
      "url": "lib/bootstrap-icons/icons/sd-card-fill.svg"
    },
    {
      "hash": "sha256-7oLdOlQWJPYnr8peVwJJiYwhm08xFuk6dwfJKZmDb1c=",
      "url": "lib/bootstrap-icons/icons/sd-card.svg"
    },
    {
      "hash": "sha256-05Z8wWioWlZDzNMQZZs1RkgmLn9TCxHZHXjtfrWmjzg=",
      "url": "lib/bootstrap-icons/icons/search-heart-fill.svg"
    },
    {
      "hash": "sha256-/LVLQ8GpSF6Alt445ECkOhE/T7TmyGd7AgBS8KMofWg=",
      "url": "lib/bootstrap-icons/icons/search-heart.svg"
    },
    {
      "hash": "sha256-sLhtzItHMZlbz3HTzoAJF0L/sJdqn+VrKpovIDImYcA=",
      "url": "lib/bootstrap-icons/icons/search.svg"
    },
    {
      "hash": "sha256-q2sNF2Fcg95NN3a5SU7700fgASS1sJ/IJ8Oahs3ZclQ=",
      "url": "lib/bootstrap-icons/icons/segmented-nav.svg"
    },
    {
      "hash": "sha256-6MoFNW+mTSsWzeWxL/dJYun5edSCxeHrYW0XXoKfTt8=",
      "url": "lib/bootstrap-icons/icons/send-arrow-down-fill.svg"
    },
    {
      "hash": "sha256-3V3qtepNqqTjtJ9zAggehar8NS6+Curg9KumNpAZeVo=",
      "url": "lib/bootstrap-icons/icons/send-arrow-down.svg"
    },
    {
      "hash": "sha256-ksNEEG+hUanAkCcehswBjBZcpT3ZHpn/sQ0tgHloXrQ=",
      "url": "lib/bootstrap-icons/icons/send-arrow-up-fill.svg"
    },
    {
      "hash": "sha256-RvBT9mR42VxzyZuv1nOIoTNMFryXgPBxtNjOnVPKsFY=",
      "url": "lib/bootstrap-icons/icons/send-arrow-up.svg"
    },
    {
      "hash": "sha256-oHxkmo/q+FDwGI4AS6zaDdn91BsqqckAwXo3HQE8h3w=",
      "url": "lib/bootstrap-icons/icons/send-check-fill.svg"
    },
    {
      "hash": "sha256-uywHqApOyIzDhUuZNTb/M/KXQ+QlKhE1OkhiyexkjTk=",
      "url": "lib/bootstrap-icons/icons/send-check.svg"
    },
    {
      "hash": "sha256-ELJcbsV01QgQacHD0u/awad+h2Qo8ieDDSni/MSEsHY=",
      "url": "lib/bootstrap-icons/icons/send-dash-fill.svg"
    },
    {
      "hash": "sha256-kye9ZtixfTRN2BDVM9c5+2Mrmi5QJJE5sW/ODB/yD9w=",
      "url": "lib/bootstrap-icons/icons/send-dash.svg"
    },
    {
      "hash": "sha256-egLaqvRmjwsZeRAUQDAsMePIc61n3WaXrp2zupreO6Y=",
      "url": "lib/bootstrap-icons/icons/send-exclamation-fill.svg"
    },
    {
      "hash": "sha256-OW5pzIeOTPUiaARU8up+GaPxFTyEHXUlFEOsTihW+Eg=",
      "url": "lib/bootstrap-icons/icons/send-exclamation.svg"
    },
    {
      "hash": "sha256-8OK1s/BZa0NrzcyS1PvwHVwbvDVtvU+m7PkHIeJD9l8=",
      "url": "lib/bootstrap-icons/icons/send-fill.svg"
    },
    {
      "hash": "sha256-eLcUdfQxy55WGNqhvzgfPhTo6McMhov/vs++oZRXLrg=",
      "url": "lib/bootstrap-icons/icons/send-plus-fill.svg"
    },
    {
      "hash": "sha256-di/t+paGawyuSDBrvDIVfoqwHA1vk1k1Nttur3njzBs=",
      "url": "lib/bootstrap-icons/icons/send-plus.svg"
    },
    {
      "hash": "sha256-t3tpSd+wdpIePmQfifsFXomZ0LEBCGBUHLGwLSaUB0g=",
      "url": "lib/bootstrap-icons/icons/send-slash-fill.svg"
    },
    {
      "hash": "sha256-Tjkw8pinYEvAz+9JjtWJ4fxXeq39JErEp1hZ33dzbAg=",
      "url": "lib/bootstrap-icons/icons/send-slash.svg"
    },
    {
      "hash": "sha256-uG9YYp9skQMSNVgLTsm4VO8YAV+jNvIt4Hx7KbcCAfs=",
      "url": "lib/bootstrap-icons/icons/send-x-fill.svg"
    },
    {
      "hash": "sha256-dqcF2aQGv20qUcGDm9X8nq+7M/NQjYfkfG1XNnNgYZU=",
      "url": "lib/bootstrap-icons/icons/send-x.svg"
    },
    {
      "hash": "sha256-UZxyx54xJCM3IhQ20Bf/mPAu5sBnB3Vbmiv2GkEgiTk=",
      "url": "lib/bootstrap-icons/icons/send.svg"
    },
    {
      "hash": "sha256-d9P6dOOc/rR9ayoQfk/I7qYrFM4KswO/tz47ScFO+AA=",
      "url": "lib/bootstrap-icons/icons/server.svg"
    },
    {
      "hash": "sha256-Cj/7oyFXWsDfN1DGmMd9iBOQjYSVodJ/vXjdddcgiPo=",
      "url": "lib/bootstrap-icons/icons/shadows.svg"
    },
    {
      "hash": "sha256-MY30t1Xb8nYLMwRVHygAL6h3mQmozo4S7qlmqrk5Y7I=",
      "url": "lib/bootstrap-icons/icons/share-fill.svg"
    },
    {
      "hash": "sha256-FC3TfHjrr3r/3pSXnhnWnIya4J1QfK+eh+jsI2R0UGM=",
      "url": "lib/bootstrap-icons/icons/share.svg"
    },
    {
      "hash": "sha256-oFl/pG5SKg7FgjjMQRgpaLdwYvlDPCBdbRpN/eBfzvk=",
      "url": "lib/bootstrap-icons/icons/shield-check.svg"
    },
    {
      "hash": "sha256-ZR5ChVyt3ZC+qDhi4qRjYNZnuKiD8IE3UZeQSrshYH8=",
      "url": "lib/bootstrap-icons/icons/shield-exclamation.svg"
    },
    {
      "hash": "sha256-97NG0g/f3mvfZifqhqiOLgJm6g7mvXqwPvlpI8/Vp5s=",
      "url": "lib/bootstrap-icons/icons/shield-fill-check.svg"
    },
    {
      "hash": "sha256-j3xw9TXa4Ckumpty7piq946OiuMwQVPXkia0cgPPbl8=",
      "url": "lib/bootstrap-icons/icons/shield-fill-exclamation.svg"
    },
    {
      "hash": "sha256-sSP1GMBhe5qO7pLs91yAO4pUmjdVeCdpN3eNRnRxYfk=",
      "url": "lib/bootstrap-icons/icons/shield-fill-minus.svg"
    },
    {
      "hash": "sha256-vTfK7FALzhNaUxMentIIpHZA18tsbdnI5ewKi4/4gHU=",
      "url": "lib/bootstrap-icons/icons/shield-fill-plus.svg"
    },
    {
      "hash": "sha256-uzJXH50r5fyifK/mWjFM/86MdWZeyA/pFCnE1v5GHLg=",
      "url": "lib/bootstrap-icons/icons/shield-fill-x.svg"
    },
    {
      "hash": "sha256-WtEJ2cNyti1Q5ZCZl0DBwvJr/PkXke0BGJesUpGKBZE=",
      "url": "lib/bootstrap-icons/icons/shield-fill.svg"
    },
    {
      "hash": "sha256-pW5ViuP/A/XS2p7QFDttyqD/xpedumB1BY1mbZuHouE=",
      "url": "lib/bootstrap-icons/icons/shield-lock-fill.svg"
    },
    {
      "hash": "sha256-9MyX/zAXek+veafgxD23Dvn/czrtEqVsUKLZUJR1lqM=",
      "url": "lib/bootstrap-icons/icons/shield-lock.svg"
    },
    {
      "hash": "sha256-WbJVqD6hEk4XJL5LMNjvCzhrU7Ojnqy20BTjpjr0N0I=",
      "url": "lib/bootstrap-icons/icons/shield-minus.svg"
    },
    {
      "hash": "sha256-8wWTYZRHx6RAuxLnzbfa9+GKAkgkU5jye50uNfXUSJU=",
      "url": "lib/bootstrap-icons/icons/shield-plus.svg"
    },
    {
      "hash": "sha256-I8IdKykdiaNOkuVA89UReCZPtQ60lOdS7sTnJlVWKuc=",
      "url": "lib/bootstrap-icons/icons/shield-shaded.svg"
    },
    {
      "hash": "sha256-xBeL7glxmYIAVlfsiG003njJ2NJG2AQcxwAUGy9Mjuc=",
      "url": "lib/bootstrap-icons/icons/shield-slash-fill.svg"
    },
    {
      "hash": "sha256-RXi0qoLEio1QI7OyVVSchZmBjzrSU1tosXHLU8PBotc=",
      "url": "lib/bootstrap-icons/icons/shield-slash.svg"
    },
    {
      "hash": "sha256-2ByGmo9OQZhr34nnuD87Gh4gM3sg7rmkhGGnG0ilgQI=",
      "url": "lib/bootstrap-icons/icons/shield-x.svg"
    },
    {
      "hash": "sha256-LpvsRBkVtcjtzJtLlWZeNHfg1hXOQZqnf8sNJT0tFRY=",
      "url": "lib/bootstrap-icons/icons/shield.svg"
    },
    {
      "hash": "sha256-+ABBAyHcyCwjwOHAt4rNK+nC4FrECu1/8lcIAveGjwM=",
      "url": "lib/bootstrap-icons/icons/shift-fill.svg"
    },
    {
      "hash": "sha256-b7dkg47jXfQEiuPgrEmIm/xh4JOJF/Aot2uNfpvNf5s=",
      "url": "lib/bootstrap-icons/icons/shift.svg"
    },
    {
      "hash": "sha256-mlVYFrzz+AMT8ieqqNpJ08UkSiZmxQjrBebeaUlF36k=",
      "url": "lib/bootstrap-icons/icons/shop-window.svg"
    },
    {
      "hash": "sha256-MrtO8buSI4pLFGqdaJjHkdvpICwnOoJp/zxhbaQm6aE=",
      "url": "lib/bootstrap-icons/icons/shop.svg"
    },
    {
      "hash": "sha256-zrzrDfTvsOnyCMxvY+i5sS9DazfOL/FxaA+A5CQm3KE=",
      "url": "lib/bootstrap-icons/icons/shuffle.svg"
    },
    {
      "hash": "sha256-UaH82M+bA8OFWgSxgdGi5eBKSLYTPK+QC7WEbM8L4MQ=",
      "url": "lib/bootstrap-icons/icons/sign-dead-end-fill.svg"
    },
    {
      "hash": "sha256-DseAC1Q2OqBVL7T0RAiYNuDCYib/muMLLsIHySZ0vmA=",
      "url": "lib/bootstrap-icons/icons/sign-dead-end.svg"
    },
    {
      "hash": "sha256-xTYRE5bBP/T4odw1uM6WL4NrLx+r9dTLfcYmZ20xcfM=",
      "url": "lib/bootstrap-icons/icons/sign-do-not-enter-fill.svg"
    },
    {
      "hash": "sha256-r1gbDD3bz7D6kiVlQosBnADVscxhBy5t4Zl3z3LaJ2I=",
      "url": "lib/bootstrap-icons/icons/sign-do-not-enter.svg"
    },
    {
      "hash": "sha256-0dd0r3X4xuFBXlrngsZcq5UPXQtjKE3gQyshrxSH/pY=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-fill.svg"
    },
    {
      "hash": "sha256-u/sH3GSuIRsUX9YMt5hAOgAIy00QyUFQqcrdAdu5Xlg=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-side-fill.svg"
    },
    {
      "hash": "sha256-qqJg3yKxEAzFnwJG833F18JpjAxFWRLoM9NRFhhiMLk=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-side.svg"
    },
    {
      "hash": "sha256-geS360X6Qw48BRc+Ji/BtkGzCNu0KiKDPXOsTMT/BTg=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-t-fill.svg"
    },
    {
      "hash": "sha256-+P1yyIJNUe/AONHAGkqagRBTsrTcJc3skgFPGAw3zbI=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-t.svg"
    },
    {
      "hash": "sha256-O73kppSrta6viWvp+qiumjroHg8yct0z+D7HbsGVdUo=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-y-fill.svg"
    },
    {
      "hash": "sha256-E4lvlviwH4/eaywd9xfPhZGv8/MIudUPvigUaUbmxEg=",
      "url": "lib/bootstrap-icons/icons/sign-intersection-y.svg"
    },
    {
      "hash": "sha256-xOnVf141fR9BDX5PNlp0Fjz5fISQQjfN5PTEs+k/N9w=",
      "url": "lib/bootstrap-icons/icons/sign-intersection.svg"
    },
    {
      "hash": "sha256-4N5YMrX5rhwcQg9MFYmK6sJgc+zOJmkoUDXe2Dwnn9w=",
      "url": "lib/bootstrap-icons/icons/sign-merge-left-fill.svg"
    },
    {
      "hash": "sha256-hDo4hDIM1O85GwNePM9ejh1TK/WX+EV+49d5z2BD1QI=",
      "url": "lib/bootstrap-icons/icons/sign-merge-left.svg"
    },
    {
      "hash": "sha256-GXsnYj2hA2M5sifDV4HfPeYFQD5S0ticHtpTKS9zBUs=",
      "url": "lib/bootstrap-icons/icons/sign-merge-right-fill.svg"
    },
    {
      "hash": "sha256-YXnupEWXcDXKiRxJj4CL9moBbg5x/eYBGVvpvWjDDNI=",
      "url": "lib/bootstrap-icons/icons/sign-merge-right.svg"
    },
    {
      "hash": "sha256-BSmoq7h/kFR3yhzfSmpkmR6d4CnsYjeHKmebAWVE5l4=",
      "url": "lib/bootstrap-icons/icons/sign-no-left-turn-fill.svg"
    },
    {
      "hash": "sha256-rnv6ya52NEszDfEswVOQliQwJ3fmX7FREIE2os3yPpU=",
      "url": "lib/bootstrap-icons/icons/sign-no-left-turn.svg"
    },
    {
      "hash": "sha256-tDb8qSne1BtFeyGMinm0VhGlFXi4Z/56f/CFFeCjPOw=",
      "url": "lib/bootstrap-icons/icons/sign-no-parking-fill.svg"
    },
    {
      "hash": "sha256-iTge2nog6rtz4gA0rhOW2jEAUeoY/M3CgQCWN73KMHU=",
      "url": "lib/bootstrap-icons/icons/sign-no-parking.svg"
    },
    {
      "hash": "sha256-WlTf1sZHImEJhI0EcRmsG+czW7UeQjzGR1Iih3ttdHU=",
      "url": "lib/bootstrap-icons/icons/sign-no-right-turn-fill.svg"
    },
    {
      "hash": "sha256-jSm7vZKhMKU9BVYxJpUkyRJm8LGW58WobUEDswcCBGk=",
      "url": "lib/bootstrap-icons/icons/sign-no-right-turn.svg"
    },
    {
      "hash": "sha256-yily3tU0CWkXolLUl0k0fwO9dHGlezdFuOs0wMzoyQU=",
      "url": "lib/bootstrap-icons/icons/sign-railroad-fill.svg"
    },
    {
      "hash": "sha256-ZrOrPEygPhmrApcMRtHyOAAghuEL7bGusFr/KsGU82w=",
      "url": "lib/bootstrap-icons/icons/sign-railroad.svg"
    },
    {
      "hash": "sha256-xwwV+K/yIuwoiQRVwE7GLcB9UWGDPMuduMDK9B0vkLA=",
      "url": "lib/bootstrap-icons/icons/sign-stop-fill.svg"
    },
    {
      "hash": "sha256-cGmC+ajxpBH8fHmNFDpUryD0hBaT1txnqsrUI5bAjy0=",
      "url": "lib/bootstrap-icons/icons/sign-stop-lights-fill.svg"
    },
    {
      "hash": "sha256-Uj9XSwd9LnE9QQ6u+4G+FyKjdgDadG03n92r8Rv074g=",
      "url": "lib/bootstrap-icons/icons/sign-stop-lights.svg"
    },
    {
      "hash": "sha256-Uw/f/lDBM1FDgqusXW2TDPTvckej7IbhE25YkoDLOe8=",
      "url": "lib/bootstrap-icons/icons/sign-stop.svg"
    },
    {
      "hash": "sha256-rgkmbJB5Xd5mpoqEF5DOgOd7KZUR2DaptfffXuFtz+4=",
      "url": "lib/bootstrap-icons/icons/sign-turn-left-fill.svg"
    },
    {
      "hash": "sha256-Dk7hvfuDg16mWAXLsp05OYMYeiTUxXfPFo4F6//l22Q=",
      "url": "lib/bootstrap-icons/icons/sign-turn-left.svg"
    },
    {
      "hash": "sha256-gR/MaVCMOQQghC0igOi8FujRn21NsgbzSZwV0zS5V4Q=",
      "url": "lib/bootstrap-icons/icons/sign-turn-right-fill.svg"
    },
    {
      "hash": "sha256-MyGyvts0Y21/FQL1XaE+3FbZuJTlUO5ccmZ93LnCE+8=",
      "url": "lib/bootstrap-icons/icons/sign-turn-right.svg"
    },
    {
      "hash": "sha256-Gbk/BxQg2cjcv3z7Pt0Qkdk7PsAuqQXin+IpRVSjyks=",
      "url": "lib/bootstrap-icons/icons/sign-turn-slight-left-fill.svg"
    },
    {
      "hash": "sha256-kX+WOkaiPbU6237ICRqDgajwtDz7FQmdHouixzUYUIM=",
      "url": "lib/bootstrap-icons/icons/sign-turn-slight-left.svg"
    },
    {
      "hash": "sha256-uVFJ4lmhys5Biz/L3k/HtpHFE4ulN9Q6zEHpn0FPjqc=",
      "url": "lib/bootstrap-icons/icons/sign-turn-slight-right-fill.svg"
    },
    {
      "hash": "sha256-875UM9Bf6zfjba4ODjuWTm+T3MIbJPIV5ApNDvIGs4Q=",
      "url": "lib/bootstrap-icons/icons/sign-turn-slight-right.svg"
    },
    {
      "hash": "sha256-KEzZdJmFNkmphSl9Go/i8OEtiEXBQfYL+Jld19d7yRs=",
      "url": "lib/bootstrap-icons/icons/sign-yield-fill.svg"
    },
    {
      "hash": "sha256-a+CCQMMN+XmA0PqCWkaR/kZZA/uMczfG81QqvUSoB3M=",
      "url": "lib/bootstrap-icons/icons/sign-yield.svg"
    },
    {
      "hash": "sha256-/rZaIknprd1725X+zsfpdZ264xBTnP376s5bHuZ8owE=",
      "url": "lib/bootstrap-icons/icons/signal.svg"
    },
    {
      "hash": "sha256-p6yjc3OM1mOTPBnC3DR41e7TuFyph+mcEDRav2qIdcI=",
      "url": "lib/bootstrap-icons/icons/signpost-2-fill.svg"
    },
    {
      "hash": "sha256-PbZ686r+gVHOD11bZYgqt17tNqUd03pyXKp295pUoPk=",
      "url": "lib/bootstrap-icons/icons/signpost-2.svg"
    },
    {
      "hash": "sha256-3zMJ54tKxqbZe5ISfEU6UT2lyEkcGBtwBw0pSunzmO4=",
      "url": "lib/bootstrap-icons/icons/signpost-fill.svg"
    },
    {
      "hash": "sha256-RZAO7QlBTwvARszVtLXQvhTu88GAJ+trc7YT/t5oc9U=",
      "url": "lib/bootstrap-icons/icons/signpost-split-fill.svg"
    },
    {
      "hash": "sha256-6TTmyMj20LxPDsR/7q4WZzVxQRqx00gzZZtngwH60/k=",
      "url": "lib/bootstrap-icons/icons/signpost-split.svg"
    },
    {
      "hash": "sha256-fPKb/xnwOHCKwI3wfJ8QlAg1BuQ4D94+54rWC5vDkFU=",
      "url": "lib/bootstrap-icons/icons/signpost.svg"
    },
    {
      "hash": "sha256-bMFVuT/TK1tu513h8KdvJAYGeHJ4yT3CIVn2YRxIkHg=",
      "url": "lib/bootstrap-icons/icons/sim-fill.svg"
    },
    {
      "hash": "sha256-jeiU/IcSKFX7HxxCYEIkTIVXHK8x3I1vsO2U8Wy8tNg=",
      "url": "lib/bootstrap-icons/icons/sim-slash-fill.svg"
    },
    {
      "hash": "sha256-qWgsAffMZOT9R6n5Mv4u8wYB/rRkFBV1jMtqYI3+BCg=",
      "url": "lib/bootstrap-icons/icons/sim-slash.svg"
    },
    {
      "hash": "sha256-3qmwFqjen9jkVx9xPjjw8NTQFnA5Dq7ZAmJDA9/yOlg=",
      "url": "lib/bootstrap-icons/icons/sim.svg"
    },
    {
      "hash": "sha256-s8Uhrsjznx/aDyrm9sHnHmZQOtXqNDxYfHAQ8lElAds=",
      "url": "lib/bootstrap-icons/icons/sina-weibo.svg"
    },
    {
      "hash": "sha256-6q+uWHY4zEWsQkw3Q8eahUDtZ88IeT/JTjs1pVXTto0=",
      "url": "lib/bootstrap-icons/icons/skip-backward-btn-fill.svg"
    },
    {
      "hash": "sha256-eZb7wQYGAy9sr6x7zeMAZFRUKRYOKji/etGR7JbohCM=",
      "url": "lib/bootstrap-icons/icons/skip-backward-btn.svg"
    },
    {
      "hash": "sha256-18m9jOQhSjCHAOrcKBIKTcRU9xez1jeV6KhAzShj+LA=",
      "url": "lib/bootstrap-icons/icons/skip-backward-circle-fill.svg"
    },
    {
      "hash": "sha256-JO3CpShGn1q+UmYuDHDRG+knKcsPPTS2LqaFz4q4OAs=",
      "url": "lib/bootstrap-icons/icons/skip-backward-circle.svg"
    },
    {
      "hash": "sha256-VYDytdlRJkU6cwk1WRB8KgHtC7QPIxzjTHlHNUkBmZI=",
      "url": "lib/bootstrap-icons/icons/skip-backward-fill.svg"
    },
    {
      "hash": "sha256-aQFWUXLrK5JtEM7biBIr78oTxCzGsfvBcQjva3HIQU8=",
      "url": "lib/bootstrap-icons/icons/skip-backward.svg"
    },
    {
      "hash": "sha256-f9aRzZwghb03LWGGRpMi0hCfDyXpv2zQ+R8+D9e5MEA=",
      "url": "lib/bootstrap-icons/icons/skip-end-btn-fill.svg"
    },
    {
      "hash": "sha256-VN31PF1RLgL9xDKPVCXCSGrsG3XsbQn5mVTCBqsI4RQ=",
      "url": "lib/bootstrap-icons/icons/skip-end-btn.svg"
    },
    {
      "hash": "sha256-N59+kneDAALJkMBz1sIa08dS8FKwNz1/oBpBV1KCuIA=",
      "url": "lib/bootstrap-icons/icons/skip-end-circle-fill.svg"
    },
    {
      "hash": "sha256-tKCy2ABDN/EA6/5HZ7dYDugbJKZ+ehP4E+mj9XFGVMw=",
      "url": "lib/bootstrap-icons/icons/skip-end-circle.svg"
    },
    {
      "hash": "sha256-fNLhlU9lV4awX5bEEAEozlrzWcxhOJ6qd8xxynrlULg=",
      "url": "lib/bootstrap-icons/icons/skip-end-fill.svg"
    },
    {
      "hash": "sha256-qzSdrnmdEULJylQPq4v6niB3D1XKU3S5RF2MU/8Bijo=",
      "url": "lib/bootstrap-icons/icons/skip-end.svg"
    },
    {
      "hash": "sha256-6Vd2DKJZrpHTcRii1YT6om2qrc52w6JTRaXCNCHyolQ=",
      "url": "lib/bootstrap-icons/icons/skip-forward-btn-fill.svg"
    },
    {
      "hash": "sha256-kF/zEEbgLZ8glxQ0L19Y4i9taezKZemqu3Mp2M4BaUQ=",
      "url": "lib/bootstrap-icons/icons/skip-forward-btn.svg"
    },
    {
      "hash": "sha256-0aIE8uy3W92JsLQNNcx3ecjGak8xxDylX2DC+4OOrIA=",
      "url": "lib/bootstrap-icons/icons/skip-forward-circle-fill.svg"
    },
    {
      "hash": "sha256-e2n4vzK6hE/ChqW/u8Ze1q92gjBwlkw4MXw5D1ial4M=",
      "url": "lib/bootstrap-icons/icons/skip-forward-circle.svg"
    },
    {
      "hash": "sha256-6ohf+ueF/PEnN6IAMbFraXr0ymiuo7i2d7gqDXZcE1Q=",
      "url": "lib/bootstrap-icons/icons/skip-forward-fill.svg"
    },
    {
      "hash": "sha256-GFmzSwGVWwF5YxRk04aKnL34NfNWBy5nxMlz0tbS33A=",
      "url": "lib/bootstrap-icons/icons/skip-forward.svg"
    },
    {
      "hash": "sha256-X/dsKurgGG/iQtvV38xTbbBQgOxPNAgTEJ2c6oWVCmA=",
      "url": "lib/bootstrap-icons/icons/skip-start-btn-fill.svg"
    },
    {
      "hash": "sha256-lm03W2wyUxQQ8zgce6dMGwOpSOCd/Xi/1dVGG8vwfpI=",
      "url": "lib/bootstrap-icons/icons/skip-start-btn.svg"
    },
    {
      "hash": "sha256-d81aFoG4d1jq5QxzcGYReikpFGWL8Ue/N2z0xNg2tRI=",
      "url": "lib/bootstrap-icons/icons/skip-start-circle-fill.svg"
    },
    {
      "hash": "sha256-TxXRpso9LhbZ94hdUjH6XluZF2qxg5dH+zIVadEn04o=",
      "url": "lib/bootstrap-icons/icons/skip-start-circle.svg"
    },
    {
      "hash": "sha256-+AmIFaUPr8+HgqdrdhOmSW+QehVpQrobINvuLUPwmV0=",
      "url": "lib/bootstrap-icons/icons/skip-start-fill.svg"
    },
    {
      "hash": "sha256-4AM/QQK83YXCjQhzGtUv9Th5kd1NCpeAUTybF4G2Ec4=",
      "url": "lib/bootstrap-icons/icons/skip-start.svg"
    },
    {
      "hash": "sha256-jCH1e2t3p6qeJkUaFVUQeHumy/3NKJohXioL30Ych0M=",
      "url": "lib/bootstrap-icons/icons/skype.svg"
    },
    {
      "hash": "sha256-NJNEdFQkPJI2lAfe/pfAH/qHtr/KxdHscBdeixwv5YY=",
      "url": "lib/bootstrap-icons/icons/slack.svg"
    },
    {
      "hash": "sha256-KbPRftAAH0KaudDsVMQOM3OfFrqTg2amCOkt/FWF/3o=",
      "url": "lib/bootstrap-icons/icons/slash-circle-fill.svg"
    },
    {
      "hash": "sha256-oYOK+YXh5azEQNw5A3r4iBlBaQLI/urqeEyz9LQ7LFU=",
      "url": "lib/bootstrap-icons/icons/slash-circle.svg"
    },
    {
      "hash": "sha256-SKd7SByMIs8dvVytOpIX4JY5SxMZAxQQ3/tR4A3Eik8=",
      "url": "lib/bootstrap-icons/icons/slash-lg.svg"
    },
    {
      "hash": "sha256-obyC/bwIgMJ10azKijqlsLdREhxtjM4vs7htE1GAihI=",
      "url": "lib/bootstrap-icons/icons/slash-square-fill.svg"
    },
    {
      "hash": "sha256-NfdMwHnUVp9kKHAwjhhI6u777AKCQdgcxLRrjg+FLH4=",
      "url": "lib/bootstrap-icons/icons/slash-square.svg"
    },
    {
      "hash": "sha256-ZRZKcqFfBS43ORY8N852QYCgx+WFO5Fn+YlKTnINnNg=",
      "url": "lib/bootstrap-icons/icons/slash.svg"
    },
    {
      "hash": "sha256-/Yu56erFMOsMdGgc0AXCRWwXbIO85PoyhEL6BELBbAc=",
      "url": "lib/bootstrap-icons/icons/sliders.svg"
    },
    {
      "hash": "sha256-v/HV9C3gi0CjV49EBvG4NHMhPU1E4os3GWcQk21PhiI=",
      "url": "lib/bootstrap-icons/icons/sliders2-vertical.svg"
    },
    {
      "hash": "sha256-yE9uxnp+jBwn6/6wtKnYwgL7dqrmR1f5kP1G48Fj6fw=",
      "url": "lib/bootstrap-icons/icons/sliders2.svg"
    },
    {
      "hash": "sha256-Yz9Oq5jfkb75f1L4jDLVUFjrKhSYKjDXgcYb0sp2q88=",
      "url": "lib/bootstrap-icons/icons/smartwatch.svg"
    },
    {
      "hash": "sha256-ReUlNpctn4km+A1+kon8EQoP+TXt7IpD5ngwiVn042Q=",
      "url": "lib/bootstrap-icons/icons/snapchat.svg"
    },
    {
      "hash": "sha256-9FWh5PJi5v5UsLvYOzb23oq4ZmE2+24N1viJPheaEvs=",
      "url": "lib/bootstrap-icons/icons/snow.svg"
    },
    {
      "hash": "sha256-Qoh5iyICgsM0iVgmxYgiuH4019tzDf2VkGk3Oy0BRB8=",
      "url": "lib/bootstrap-icons/icons/snow2.svg"
    },
    {
      "hash": "sha256-t0fBcYC6bMrkQ3IWxeEIv9158dHBBqBzgQiQg48ODQo=",
      "url": "lib/bootstrap-icons/icons/snow3.svg"
    },
    {
      "hash": "sha256-i6tz6vssecwHq5wk4vVs353Q4KUH4cDvRR0MHxh4SbA=",
      "url": "lib/bootstrap-icons/icons/sort-alpha-down-alt.svg"
    },
    {
      "hash": "sha256-ewd91MlSS2qF8DgReLq668LGs++GeLMWbktYg70+n3c=",
      "url": "lib/bootstrap-icons/icons/sort-alpha-down.svg"
    },
    {
      "hash": "sha256-UcsS7gun0/zov+ZAUPkqqckLLFFOU/zI6Jzi9H3pu/g=",
      "url": "lib/bootstrap-icons/icons/sort-alpha-up-alt.svg"
    },
    {
      "hash": "sha256-9CyMZAom3lOvjBqeJG45snJJKvuXrRcvQ85ZA/TQByw=",
      "url": "lib/bootstrap-icons/icons/sort-alpha-up.svg"
    },
    {
      "hash": "sha256-ydl2gKxhoMFx742d29Uyj2vWC3q+NMMY6Zzec7J2oGg=",
      "url": "lib/bootstrap-icons/icons/sort-down-alt.svg"
    },
    {
      "hash": "sha256-fiDemU/e88LrapKPldaVa2JQwU6HH4/DS7tqX4qvvdc=",
      "url": "lib/bootstrap-icons/icons/sort-down.svg"
    },
    {
      "hash": "sha256-hEay9BX+hnegKOMGKIm4FGzuL7LpOTEvQVgoaAEG8lw=",
      "url": "lib/bootstrap-icons/icons/sort-numeric-down-alt.svg"
    },
    {
      "hash": "sha256-fBtyQLuiDB4mMJsy6uEWegirG5+c72Rl5BbkrznncEI=",
      "url": "lib/bootstrap-icons/icons/sort-numeric-down.svg"
    },
    {
      "hash": "sha256-5lW604P70LWDcKaiXxdsOcNT6iT8Lft5uYNpZnEiHBk=",
      "url": "lib/bootstrap-icons/icons/sort-numeric-up-alt.svg"
    },
    {
      "hash": "sha256-wxBvFB3X5Vk+3e5RDzAbXkoI13lOcthXhH9Rps6JjsY=",
      "url": "lib/bootstrap-icons/icons/sort-numeric-up.svg"
    },
    {
      "hash": "sha256-ELAu7VXwKNDMvYNcP2F2YcizDs9+hLjs3oI19zIM6lA=",
      "url": "lib/bootstrap-icons/icons/sort-up-alt.svg"
    },
    {
      "hash": "sha256-Bc7mDZ0hYWOkEcx08DiTjnb96CuOxNVi0zdBvoRZYOI=",
      "url": "lib/bootstrap-icons/icons/sort-up.svg"
    },
    {
      "hash": "sha256-SnSCuTcBnKEZbCQoLA43Cdwa3u1xXVVBZ7VzOATYxR4=",
      "url": "lib/bootstrap-icons/icons/soundwave.svg"
    },
    {
      "hash": "sha256-SsGwh4o2VT7njEzCfoMDzMJf4EQzSG/81Ewl3h3Gprs=",
      "url": "lib/bootstrap-icons/icons/sourceforge.svg"
    },
    {
      "hash": "sha256-8XiCDrrxG7ZAv15btdq7fKawQG/Bgppgk4DVzrvcSHE=",
      "url": "lib/bootstrap-icons/icons/speaker-fill.svg"
    },
    {
      "hash": "sha256-wt5010+1PqVwGs0IJiqAKsWuCMWTKYMfb0a5NQm8Rlw=",
      "url": "lib/bootstrap-icons/icons/speaker.svg"
    },
    {
      "hash": "sha256-VfJhPIIVbUoQd9gwpf0JhRJQGbh274svOs2JErU57v0=",
      "url": "lib/bootstrap-icons/icons/speedometer.svg"
    },
    {
      "hash": "sha256-yysvweVSqFSB0vMM+J426s4vTndINqmA8cvK9iHEb4s=",
      "url": "lib/bootstrap-icons/icons/speedometer2.svg"
    },
    {
      "hash": "sha256-5Ad0IPGk1ikqB+/7RdLrYlAKAibIIdMwLyB0I7DXB14=",
      "url": "lib/bootstrap-icons/icons/spellcheck.svg"
    },
    {
      "hash": "sha256-sSkhs3Y43CMDxHelVZxsXQN5kX7dJAies26EjRjEhRk=",
      "url": "lib/bootstrap-icons/icons/spotify.svg"
    },
    {
      "hash": "sha256-z834Lnp9sOGdhr6CJr14pEjm+YWkljL9XLcFbVcnJ4E=",
      "url": "lib/bootstrap-icons/icons/square-fill.svg"
    },
    {
      "hash": "sha256-A4LZFx/B2QwhBj1/OH8zfYs0Vm6Cohpr8OFFrcaRwx0=",
      "url": "lib/bootstrap-icons/icons/square-half.svg"
    },
    {
      "hash": "sha256-aEEXeTquvm2Ya5ig+K3DpXJT5zW3DjQT7tppEfw0n0o=",
      "url": "lib/bootstrap-icons/icons/square.svg"
    },
    {
      "hash": "sha256-wdEDExYNgLsIRYKTY6wS1UCAuOlXZ5cwjvZeBHKYI6E=",
      "url": "lib/bootstrap-icons/icons/stack-overflow.svg"
    },
    {
      "hash": "sha256-0/8+R6kbD+60troWvfRMW+DB7UqezfdXwqUvWFNZ+k8=",
      "url": "lib/bootstrap-icons/icons/stack.svg"
    },
    {
      "hash": "sha256-j61+SdRmcopG07HOP8x2PAYSeGFEvO1wsdqCBUDJ3hM=",
      "url": "lib/bootstrap-icons/icons/star-fill.svg"
    },
    {
      "hash": "sha256-K4IJgHuMmSvCS26xwbhTjy8pcl5nSDRTyL2sxg5ry9g=",
      "url": "lib/bootstrap-icons/icons/star-half.svg"
    },
    {
      "hash": "sha256-tKDAPhZZlegQksZyeMeehmNnVAgZRFiyUd4ipu1sHRU=",
      "url": "lib/bootstrap-icons/icons/star.svg"
    },
    {
      "hash": "sha256-T35SwJKf5pi1ovLldF3ADmw3TUtec/Av/Kg/RxS2qWE=",
      "url": "lib/bootstrap-icons/icons/stars.svg"
    },
    {
      "hash": "sha256-lHp0NAYrmtfrtsF3M85rp47eq04HzXR9cT25yPR+EbM=",
      "url": "lib/bootstrap-icons/icons/steam.svg"
    },
    {
      "hash": "sha256-1zCWkYuytpybIkIkzHDC/gLU4X+CAfH3xxF7JgGR/tU=",
      "url": "lib/bootstrap-icons/icons/stickies-fill.svg"
    },
    {
      "hash": "sha256-GojHIeAsVDv3NEBqqIA0MQHks0cU1q6YLQhrX+HlebI=",
      "url": "lib/bootstrap-icons/icons/stickies.svg"
    },
    {
      "hash": "sha256-N1gLWbYGVj3gKI7pP94enLW+bAgtilLeWWaoey95r0Q=",
      "url": "lib/bootstrap-icons/icons/sticky-fill.svg"
    },
    {
      "hash": "sha256-atk40b5zhgovZGgaYUZxFpQrDS1EVKITCyHP+N56VVM=",
      "url": "lib/bootstrap-icons/icons/sticky.svg"
    },
    {
      "hash": "sha256-cwVTqm6k+BKRWjuD+k1peCZ5MUxnareQ/HHLzBuM9Hs=",
      "url": "lib/bootstrap-icons/icons/stop-btn-fill.svg"
    },
    {
      "hash": "sha256-ewkhKmZyS4GRoRjXDBv/z7CK+sVewjBwKNiL9XjXW+Y=",
      "url": "lib/bootstrap-icons/icons/stop-btn.svg"
    },
    {
      "hash": "sha256-6tpT7TupNfWRGyqEyKHSAWdV2uSpNrgWmCsExoEpHvc=",
      "url": "lib/bootstrap-icons/icons/stop-circle-fill.svg"
    },
    {
      "hash": "sha256-cAbfVMiqGAuPVsDU5Yd7nQgyzlhYf1HoBgSHURIqu/M=",
      "url": "lib/bootstrap-icons/icons/stop-circle.svg"
    },
    {
      "hash": "sha256-5Re/MMuKoLgD776L3q7K8gzTWY8kxqHMoH1Rqa+JJUw=",
      "url": "lib/bootstrap-icons/icons/stop-fill.svg"
    },
    {
      "hash": "sha256-eBEV+lzgl7IOKUyUNsc8ercVa6Y5l7vs11Ksd29Hpgg=",
      "url": "lib/bootstrap-icons/icons/stop.svg"
    },
    {
      "hash": "sha256-6WtoB5ltA8HN43nudTDn9uKWuagT/YOx7EnjiL8mzuY=",
      "url": "lib/bootstrap-icons/icons/stoplights-fill.svg"
    },
    {
      "hash": "sha256-91Ni/JPd206SMfo1Jfo0oIUWgOYTZTQYsyD0kiulfWc=",
      "url": "lib/bootstrap-icons/icons/stoplights.svg"
    },
    {
      "hash": "sha256-NJEEoJbA8LCr1MRqiKiiinS8VN+ji/tHf9qxh8WEfDE=",
      "url": "lib/bootstrap-icons/icons/stopwatch-fill.svg"
    },
    {
      "hash": "sha256-euDGbKpfqXp8WKpiAsyLk61Z5vAQt55l8kCcHAYwdCM=",
      "url": "lib/bootstrap-icons/icons/stopwatch.svg"
    },
    {
      "hash": "sha256-tK9GRVX8YY3//AtneI3CE/yTkBpU1fZm4Awt/3rA/DA=",
      "url": "lib/bootstrap-icons/icons/strava.svg"
    },
    {
      "hash": "sha256-XJXPoxF4KabrZ0pspvE8RX5pefJyQNbngAeU++JtmcA=",
      "url": "lib/bootstrap-icons/icons/stripe.svg"
    },
    {
      "hash": "sha256-JOnzv7Hc8FL67ic0HPEP+S71bXJjDHRlEvmPa7p9rqs=",
      "url": "lib/bootstrap-icons/icons/subscript.svg"
    },
    {
      "hash": "sha256-UE+Xvr5Dsvp/ISsJfjHt+086qVnNp5aJShP2rKkYyuk=",
      "url": "lib/bootstrap-icons/icons/substack.svg"
    },
    {
      "hash": "sha256-p81SUACXF/GgMuox2c7EAHvCf04J2jA9oN2Fwj8+MNA=",
      "url": "lib/bootstrap-icons/icons/subtract.svg"
    },
    {
      "hash": "sha256-qzCEris/EJokJkg7Y3H8uxODvq60KLBOkqPoLW5MoiM=",
      "url": "lib/bootstrap-icons/icons/suit-club-fill.svg"
    },
    {
      "hash": "sha256-b6z/YDHBOom4zNkLnWUOv9wS9DkozKpx0xrteno4Enk=",
      "url": "lib/bootstrap-icons/icons/suit-club.svg"
    },
    {
      "hash": "sha256-1pB/x4j6D86S+zZe3hQ4NM7iTDpXkfkmwJ4xSI6RsBE=",
      "url": "lib/bootstrap-icons/icons/suit-diamond-fill.svg"
    },
    {
      "hash": "sha256-1N9QcpxYu3lNQCz5BH0Se4HHQwI/mA8SURUiUZ5V88U=",
      "url": "lib/bootstrap-icons/icons/suit-diamond.svg"
    },
    {
      "hash": "sha256-9mWyvI+ehLWk2lvUB8/4to05eobFEyChkFXVIidGdiM=",
      "url": "lib/bootstrap-icons/icons/suit-heart-fill.svg"
    },
    {
      "hash": "sha256-PO1+1APW/SrPs2JnHmhVdz5Zh3qu1AymVjNj/N2+fHw=",
      "url": "lib/bootstrap-icons/icons/suit-heart.svg"
    },
    {
      "hash": "sha256-stVvHB+S3DXSyIx2ngzTBQYb6SyFcbXYRKJTABuHuzA=",
      "url": "lib/bootstrap-icons/icons/suit-spade-fill.svg"
    },
    {
      "hash": "sha256-f9L5i+0rtMqys8p7FMxIRJN5/QZeRbGSpHMOOxtZo2Y=",
      "url": "lib/bootstrap-icons/icons/suit-spade.svg"
    },
    {
      "hash": "sha256-FhHM/6iLuOrzklhu/APEG9IYaQaSvWHDMbnoPymkGq8=",
      "url": "lib/bootstrap-icons/icons/suitcase-fill.svg"
    },
    {
      "hash": "sha256-fDnvpt63zfoN03/pAiKRXPtUH77iLGe0XmsPNES4zhg=",
      "url": "lib/bootstrap-icons/icons/suitcase-lg-fill.svg"
    },
    {
      "hash": "sha256-TkGHiCE8hNmwaxl//LTfykp1bDtCP93deEXBwEUeEfs=",
      "url": "lib/bootstrap-icons/icons/suitcase-lg.svg"
    },
    {
      "hash": "sha256-oqYVzLLcq92z5KGBUIyxoOW19ScUl6kOClZAilybTeg=",
      "url": "lib/bootstrap-icons/icons/suitcase.svg"
    },
    {
      "hash": "sha256-baFTN61ttLb6P/ac3ojhX8G1tmPK0tekt5KM590WOfs=",
      "url": "lib/bootstrap-icons/icons/suitcase2-fill.svg"
    },
    {
      "hash": "sha256-maI61baY1n5tQ0CjO6jzum+Dqmu/BCmmOCI7xXBvsuQ=",
      "url": "lib/bootstrap-icons/icons/suitcase2.svg"
    },
    {
      "hash": "sha256-CbzDIFNudT/O97vi1LP+UdT+NiKIViH2STlgFHNhZzQ=",
      "url": "lib/bootstrap-icons/icons/sun-fill.svg"
    },
    {
      "hash": "sha256-dllVZO38oNWtsajfaABelZUu3BmJ0lcPAZqjVcs1qKQ=",
      "url": "lib/bootstrap-icons/icons/sun.svg"
    },
    {
      "hash": "sha256-8vVoqZAuXB4d0AH8FQYHhI5oGunVMexMq7sd3HRg/ds=",
      "url": "lib/bootstrap-icons/icons/sunglasses.svg"
    },
    {
      "hash": "sha256-/AGfD254zMhx4F1kA5sDIGggsZnYSsJn0SbBv17yTgQ=",
      "url": "lib/bootstrap-icons/icons/sunrise-fill.svg"
    },
    {
      "hash": "sha256-XDt/622e4WFWDYfYC2gE4bZdv5nIoa7sDRBZcnbcUzI=",
      "url": "lib/bootstrap-icons/icons/sunrise.svg"
    },
    {
      "hash": "sha256-MYMnW8c4utkTn6YWBlM8UkIxBCei9cxrNpyZlEQCqNs=",
      "url": "lib/bootstrap-icons/icons/sunset-fill.svg"
    },
    {
      "hash": "sha256-71MnVL8NPfWNjRWFP4qbykWYUT+PObI6FywJbwMvwMc=",
      "url": "lib/bootstrap-icons/icons/sunset.svg"
    },
    {
      "hash": "sha256-pT/0nazgTXxopoRisCfCXCvkFnMOtQ7gXXqUc/B0Lyg=",
      "url": "lib/bootstrap-icons/icons/superscript.svg"
    },
    {
      "hash": "sha256-cXR+hbceOsL5WjP8fM7BWXLlU0n37pJB3o4j3j0S2xk=",
      "url": "lib/bootstrap-icons/icons/symmetry-horizontal.svg"
    },
    {
      "hash": "sha256-Q25qSbPnj7yX/mNPGDlpB73XvMDohJYmn5CSCVYKzUQ=",
      "url": "lib/bootstrap-icons/icons/symmetry-vertical.svg"
    },
    {
      "hash": "sha256-a6f4QHKjlqmjPkcbgid5eBHPyYOCzuGxxgA4Z0oupD4=",
      "url": "lib/bootstrap-icons/icons/table.svg"
    },
    {
      "hash": "sha256-nwvbkP7ODTTeXsLXlShHDheLcgwzNs803rK6FA1CtAY=",
      "url": "lib/bootstrap-icons/icons/tablet-fill.svg"
    },
    {
      "hash": "sha256-Dc/3Q5ewaA2eBRvikdhr0KOe1TeQxE9r+XnObEclZkM=",
      "url": "lib/bootstrap-icons/icons/tablet-landscape-fill.svg"
    },
    {
      "hash": "sha256-mJD80zprXDNzqvwiMvh5QXg6ekpYAm5mIHZZdAfRVkg=",
      "url": "lib/bootstrap-icons/icons/tablet-landscape.svg"
    },
    {
      "hash": "sha256-JESVPk+pyRPATwi4B4evHZOQwwtPXUi0McUlctzGjgw=",
      "url": "lib/bootstrap-icons/icons/tablet.svg"
    },
    {
      "hash": "sha256-6tcyrgdT/pP3FaFgbdY/vU1slzwXTE2jLTF8tWcCBOg=",
      "url": "lib/bootstrap-icons/icons/tag-fill.svg"
    },
    {
      "hash": "sha256-uGC6BbCLGh7FqMQBVlNS7GVg/uT1r1mzehnLADQ9Q2A=",
      "url": "lib/bootstrap-icons/icons/tag.svg"
    },
    {
      "hash": "sha256-BkMdXlukBl/9rO0RmNFw4xtAt1cqJpue/5kdOR2Vj2Y=",
      "url": "lib/bootstrap-icons/icons/tags-fill.svg"
    },
    {
      "hash": "sha256-M1HYMCrwIFUPk1WCJyw6RtLdyAyE1+V9Vg+LhGVs6lk=",
      "url": "lib/bootstrap-icons/icons/tags.svg"
    },
    {
      "hash": "sha256-EcE0A8o9GjA+DvUoxkYyHyC5LVYcHUA2i7Kr0IEqdak=",
      "url": "lib/bootstrap-icons/icons/taxi-front-fill.svg"
    },
    {
      "hash": "sha256-4BoEIBpceqPXGJzJ8zSCf09oHuSaHQ7GoCkPO8TOmqU=",
      "url": "lib/bootstrap-icons/icons/taxi-front.svg"
    },
    {
      "hash": "sha256-c1nfuhaJ1FaQrrkInOihgDckrSS3Kib1vzc6yDXLUzU=",
      "url": "lib/bootstrap-icons/icons/telegram.svg"
    },
    {
      "hash": "sha256-35kbeXgYi/pFmvT4QcPdQIcJhuhf6/JRDIPV2PBdoMs=",
      "url": "lib/bootstrap-icons/icons/telephone-fill.svg"
    },
    {
      "hash": "sha256-HuTvuhcobiXorg0pW1V3ZFhymcCqE1zd1szuMOvbTJs=",
      "url": "lib/bootstrap-icons/icons/telephone-forward-fill.svg"
    },
    {
      "hash": "sha256-5QuS+h8GUTdgkz7R8kHsXf2Tt1JpmhDCBayArRIXNU4=",
      "url": "lib/bootstrap-icons/icons/telephone-forward.svg"
    },
    {
      "hash": "sha256-K466Rn+n6BdiX/8y2RT4y5La64uoOJoQd+SklS+lUu8=",
      "url": "lib/bootstrap-icons/icons/telephone-inbound-fill.svg"
    },
    {
      "hash": "sha256-H0JRaU2toAmT9SvBRhgNbesENYOxrmRuQgdsLse5ldQ=",
      "url": "lib/bootstrap-icons/icons/telephone-inbound.svg"
    },
    {
      "hash": "sha256-Gh5Wx+qqFBxYV9aR3piOR0EXbHWCaQC9LEP3S0FQlq4=",
      "url": "lib/bootstrap-icons/icons/telephone-minus-fill.svg"
    },
    {
      "hash": "sha256-ybuCZW0RVwpuyYW3j3CL6g98LVvZl4BvqQY3pdXAzQg=",
      "url": "lib/bootstrap-icons/icons/telephone-minus.svg"
    },
    {
      "hash": "sha256-6sWx+Ci7ZkqVSkR+IbqrgME/wyQoxnW28VmtF3/s/Uk=",
      "url": "lib/bootstrap-icons/icons/telephone-outbound-fill.svg"
    },
    {
      "hash": "sha256-Lg8zbSZOr2riN54KJCjmbgdlPduUlNSdMLT067rJDiU=",
      "url": "lib/bootstrap-icons/icons/telephone-outbound.svg"
    },
    {
      "hash": "sha256-4L2r/5UKKzogNmoYC+H/GM1YGyYFdreWJObXzS1Pq6w=",
      "url": "lib/bootstrap-icons/icons/telephone-plus-fill.svg"
    },
    {
      "hash": "sha256-i8/1y2yXNq/cXwzq0hh93AoJafo+wgG/Dd3mJ/bNch8=",
      "url": "lib/bootstrap-icons/icons/telephone-plus.svg"
    },
    {
      "hash": "sha256-syFPJmD0iG/pyxTYtkQrdFl4Mmj5b/NFXBXih/C/I2c=",
      "url": "lib/bootstrap-icons/icons/telephone-x-fill.svg"
    },
    {
      "hash": "sha256-QuqX/UhcC+9JchJHBUACidbsNPp2L+IyUZDCf6GvTNU=",
      "url": "lib/bootstrap-icons/icons/telephone-x.svg"
    },
    {
      "hash": "sha256-mdmIiDql9G5ootpShop57pLhqDLSAPCnx05amwVdnEo=",
      "url": "lib/bootstrap-icons/icons/telephone.svg"
    },
    {
      "hash": "sha256-y37wTkYDLb9FedlrJNtZAzA7CSIheV2v8rxuM2bCHKU=",
      "url": "lib/bootstrap-icons/icons/tencent-qq.svg"
    },
    {
      "hash": "sha256-KtEYBmiFSo4tIJHenmT4hkbbmWv7fqBZjcoCMeQ/x+8=",
      "url": "lib/bootstrap-icons/icons/terminal-dash.svg"
    },
    {
      "hash": "sha256-8DDgR3ckKVjyxLl3ugnHeqSr+RZqxYuUqkoosUjQXJg=",
      "url": "lib/bootstrap-icons/icons/terminal-fill.svg"
    },
    {
      "hash": "sha256-gmawsQ7f3MbEheUqnxDnN55OAftCTVQcrFsr+si4jxA=",
      "url": "lib/bootstrap-icons/icons/terminal-plus.svg"
    },
    {
      "hash": "sha256-WBalm7lpq/LAEw5LdST2j6ZofoogEXhqUax5luHQULY=",
      "url": "lib/bootstrap-icons/icons/terminal-split.svg"
    },
    {
      "hash": "sha256-uhBK4TBzCi87z5fVo8V7kD7J6VD+tpimgeq0O0pTb4Q=",
      "url": "lib/bootstrap-icons/icons/terminal-x.svg"
    },
    {
      "hash": "sha256-sahcC+MipRBDbV87YU2gFGWemmtcnS9Xy0VL2zAmTaU=",
      "url": "lib/bootstrap-icons/icons/terminal.svg"
    },
    {
      "hash": "sha256-jU1PFA2DJWoyAgirWxdX/gwmKRa0nM0mNKcxsA52oGk=",
      "url": "lib/bootstrap-icons/icons/text-center.svg"
    },
    {
      "hash": "sha256-vPzPnoPoQdCHTICXwF8eWvqQ7PcUX0PbHfx5+oW2B4g=",
      "url": "lib/bootstrap-icons/icons/text-indent-left.svg"
    },
    {
      "hash": "sha256-IVuXAt4/EzeeFhA4KWbd60707LgdB5BsTnF87WLomAA=",
      "url": "lib/bootstrap-icons/icons/text-indent-right.svg"
    },
    {
      "hash": "sha256-CLoXr7vZH24LyBdqzgdPBYeASuKvrepCBbr0djJa77w=",
      "url": "lib/bootstrap-icons/icons/text-left.svg"
    },
    {
      "hash": "sha256-0o7MRIEyMHlcRXMkxtQ81cEtD2dHM7t+krQ3P6uHl54=",
      "url": "lib/bootstrap-icons/icons/text-paragraph.svg"
    },
    {
      "hash": "sha256-CzmaducX+ZybScxUVqqR+EqCn5PKqkBYF7k+xzJuB4U=",
      "url": "lib/bootstrap-icons/icons/text-right.svg"
    },
    {
      "hash": "sha256-eRtcXg3cDNoNUV20STEE+xNuAzfII0SxlHj7DHOfoNM=",
      "url": "lib/bootstrap-icons/icons/text-wrap.svg"
    },
    {
      "hash": "sha256-OuaiSnUYb/ta8Xw4X3ieCLi4kD5P2sLjHwkPkfb8mXE=",
      "url": "lib/bootstrap-icons/icons/textarea-resize.svg"
    },
    {
      "hash": "sha256-UQLO8V4xD3Gz6QjTb32xdwgQe59ipieRlvc1ExKA1gA=",
      "url": "lib/bootstrap-icons/icons/textarea-t.svg"
    },
    {
      "hash": "sha256-erPr+VoGTInUAnSi7AHcy4vbGaIqhCmg/Ii8EYvPYns=",
      "url": "lib/bootstrap-icons/icons/textarea.svg"
    },
    {
      "hash": "sha256-uNxll1gcwWwslbdZEgZKg4WkEwJGpBVgjEAi03s5xvs=",
      "url": "lib/bootstrap-icons/icons/thermometer-half.svg"
    },
    {
      "hash": "sha256-HK7wFlB69zY+MVTwJdbf7hmt7Px2iXRf2KdlfTnS1Ag=",
      "url": "lib/bootstrap-icons/icons/thermometer-high.svg"
    },
    {
      "hash": "sha256-WqTZliEr6F/nGcqp5SZqe9p7MdXLTN3iXs0Q2MNySG0=",
      "url": "lib/bootstrap-icons/icons/thermometer-low.svg"
    },
    {
      "hash": "sha256-/WvwlCznP3OstCGyNSLVCrUMzUyQHuWqhLU1YD6LGY4=",
      "url": "lib/bootstrap-icons/icons/thermometer-snow.svg"
    },
    {
      "hash": "sha256-OPS3xPRb4Ybshdp/Y/wtNUTiUapqWShm4PLI9r+MaRk=",
      "url": "lib/bootstrap-icons/icons/thermometer-sun.svg"
    },
    {
      "hash": "sha256-vMLzgbsaGO9Kv+dw9zRPXz60p8irSSUZVRYh+k5iYbk=",
      "url": "lib/bootstrap-icons/icons/thermometer.svg"
    },
    {
      "hash": "sha256-nKP5Dfos1KfgQK/tEeugnZx5PIF73hBp+A5P7Ydtf44=",
      "url": "lib/bootstrap-icons/icons/threads-fill.svg"
    },
    {
      "hash": "sha256-Rg4mvP3ZaOxPYlXUpRnwzJ3uHAZZwWKomk3cpZvopLQ=",
      "url": "lib/bootstrap-icons/icons/threads.svg"
    },
    {
      "hash": "sha256-qhpqFWq1QAuyQ33uvBENh2lchuNjHf94LP5FHX2hQRs=",
      "url": "lib/bootstrap-icons/icons/three-dots-vertical.svg"
    },
    {
      "hash": "sha256-YXR21+YfDeajqA7biVW8sDv+6s6JEnOsf8VFLWcAieM=",
      "url": "lib/bootstrap-icons/icons/three-dots.svg"
    },
    {
      "hash": "sha256-REJeiUZJAXuIUxowDUgealaVzr/y6eQSbNox3/U0fm4=",
      "url": "lib/bootstrap-icons/icons/thunderbolt-fill.svg"
    },
    {
      "hash": "sha256-KRc4vcVFzYPMrlcSPPK+45RbPwlifnFXpqtkJRiN2Oo=",
      "url": "lib/bootstrap-icons/icons/thunderbolt.svg"
    },
    {
      "hash": "sha256-vUGLTW5Zg7X4l6fiMx9uP/OtYKkhintMTYO+5mJd4r4=",
      "url": "lib/bootstrap-icons/icons/ticket-detailed-fill.svg"
    },
    {
      "hash": "sha256-lTz0M9ewTWl5HmOJwUUAmCSKOBaW56XZV4G/Z+j30Dk=",
      "url": "lib/bootstrap-icons/icons/ticket-detailed.svg"
    },
    {
      "hash": "sha256-S9fTKCAhl5vk9fDF3nQoGQxFYAN25solv/GkvADYz6o=",
      "url": "lib/bootstrap-icons/icons/ticket-fill.svg"
    },
    {
      "hash": "sha256-2F1UgFjg7eOmKigrSWfO9WDyacnVj8LzjzgJtxx0A10=",
      "url": "lib/bootstrap-icons/icons/ticket-perforated-fill.svg"
    },
    {
      "hash": "sha256-vFBKsarmROtY1EZ8OF8LRC6/n8EUbrlvaWq/HCaxYJc=",
      "url": "lib/bootstrap-icons/icons/ticket-perforated.svg"
    },
    {
      "hash": "sha256-4FtxehJuGY6O1U3xYzVI7GBfbN42eUM+mt3nTIy5Thg=",
      "url": "lib/bootstrap-icons/icons/ticket.svg"
    },
    {
      "hash": "sha256-ZbrFQqscSanh22hbEHiiyylD/yUdw9g0N8TYpH8aetE=",
      "url": "lib/bootstrap-icons/icons/tiktok.svg"
    },
    {
      "hash": "sha256-QkgDW0CWALSPUKBMNXwxC8yz6lMItAKLoZU2v+bdass=",
      "url": "lib/bootstrap-icons/icons/toggle-off.svg"
    },
    {
      "hash": "sha256-GTtSQxVKCOMk55Gzk/kx4Cl7nqUgBZzVRv4ZKGVlveI=",
      "url": "lib/bootstrap-icons/icons/toggle-on.svg"
    },
    {
      "hash": "sha256-4kdc+FvIJ8QfoakjWBrENMkPUaee/fFgO5BO5Jl18xg=",
      "url": "lib/bootstrap-icons/icons/toggle2-off.svg"
    },
    {
      "hash": "sha256-H3ACi2Oe/+kAMkKy4qWaGD+WyUfJJ/jv2wcliIdPbcM=",
      "url": "lib/bootstrap-icons/icons/toggle2-on.svg"
    },
    {
      "hash": "sha256-X79tbt+LH5Dz/aJ/LQWuPmxEHMeiYqQSxruBDc6yCnU=",
      "url": "lib/bootstrap-icons/icons/toggles.svg"
    },
    {
      "hash": "sha256-hVEYjVvsEHf02fnoCMckA6cJElgJqRD5nHd/t4nlGqY=",
      "url": "lib/bootstrap-icons/icons/toggles2.svg"
    },
    {
      "hash": "sha256-/iuQxNJzBmTKYVvNIIJW0h5NaWf8Qph7ekIhjIxT0Ow=",
      "url": "lib/bootstrap-icons/icons/tools.svg"
    },
    {
      "hash": "sha256-3HFzh1HaNZMtJ/GXz045/m2MIYXP9SMWA3SCKFzf8Mw=",
      "url": "lib/bootstrap-icons/icons/tornado.svg"
    },
    {
      "hash": "sha256-bHnUrJQVWNjhZamKAopxzYAS4/wa9HFI0g4AcwZDxKU=",
      "url": "lib/bootstrap-icons/icons/train-freight-front-fill.svg"
    },
    {
      "hash": "sha256-WiFC7J8Ngmvci68v8AUCjbbd+cNTfaGgJUHubuvTCK0=",
      "url": "lib/bootstrap-icons/icons/train-freight-front.svg"
    },
    {
      "hash": "sha256-uF/b7UPP+KZJE76a6pxueZO76QGijKaGYSmupoYHmu4=",
      "url": "lib/bootstrap-icons/icons/train-front-fill.svg"
    },
    {
      "hash": "sha256-svXz2wNjyzrfBSfoM1FZa5E6+y/jKcUoEln0c6gEt9g=",
      "url": "lib/bootstrap-icons/icons/train-front.svg"
    },
    {
      "hash": "sha256-Jpd6psECmgSlvObso63pHp2Wn0TMoGeMibDXoSoGh/E=",
      "url": "lib/bootstrap-icons/icons/train-lightrail-front-fill.svg"
    },
    {
      "hash": "sha256-rclXzmPGRTUYyLFov3fDiilJEKzjfewPDUT5PrhXEPY=",
      "url": "lib/bootstrap-icons/icons/train-lightrail-front.svg"
    },
    {
      "hash": "sha256-CAfZ46XkmgNhcGgio7Jd2kvItPfdCHw1RfK2cEZO0xY=",
      "url": "lib/bootstrap-icons/icons/translate.svg"
    },
    {
      "hash": "sha256-gLp3RT+UWaeZ4Vr3CiPicU0V+nWI1qfRstKsWjSnMak=",
      "url": "lib/bootstrap-icons/icons/transparency.svg"
    },
    {
      "hash": "sha256-uHZoltTHZmtqse4pj+6DbkKxQuFBPP2JCcT/gUp7H0w=",
      "url": "lib/bootstrap-icons/icons/trash-fill.svg"
    },
    {
      "hash": "sha256-rLuhaHe/h4SmBQU4n5iznLc/CwGNV21NZucQWzhnyzs=",
      "url": "lib/bootstrap-icons/icons/trash.svg"
    },
    {
      "hash": "sha256-gU27J7iYjxAbihjWnYchc2YqRj9Sq2bx674ITT2D5tA=",
      "url": "lib/bootstrap-icons/icons/trash2-fill.svg"
    },
    {
      "hash": "sha256-JIdELM1qAO22tU4F5qc3KN9T0kmSHIJxEPlj3uE2ktY=",
      "url": "lib/bootstrap-icons/icons/trash2.svg"
    },
    {
      "hash": "sha256-rkEWpzTPiNtV6lRzGyN4ZXeofOJHeZcEROWU1gmLVGI=",
      "url": "lib/bootstrap-icons/icons/trash3-fill.svg"
    },
    {
      "hash": "sha256-i0N/41UZ3bPwwVMWfM3aV9uxR2SoatG0sZoTOzTtblk=",
      "url": "lib/bootstrap-icons/icons/trash3.svg"
    },
    {
      "hash": "sha256-seAp6cL2ejhtk8Zs2BUM6Ji2avonWUFHu2U25AWwAc4=",
      "url": "lib/bootstrap-icons/icons/tree-fill.svg"
    },
    {
      "hash": "sha256-LfFsjBh7CfAj/30d15GhCa8qlf91FBi5VAgyuZCnkPY=",
      "url": "lib/bootstrap-icons/icons/tree.svg"
    },
    {
      "hash": "sha256-WxRpVx7Vyxjle00kjXbbER0EWfr1VAfebsnezVz6WKI=",
      "url": "lib/bootstrap-icons/icons/trello.svg"
    },
    {
      "hash": "sha256-JUJhHwezlodzvsIBqiVQ/9+B+rRJfwmjQJrvk8WE69c=",
      "url": "lib/bootstrap-icons/icons/triangle-fill.svg"
    },
    {
      "hash": "sha256-eq7Z/yVFw0a5GZx9U38j8GlePDyVSME97V9KfPIlCdA=",
      "url": "lib/bootstrap-icons/icons/triangle-half.svg"
    },
    {
      "hash": "sha256-OWWbKlklGY+Z3anTsVfrk5OTGriPeQEEBaO6gvD6HxM=",
      "url": "lib/bootstrap-icons/icons/triangle.svg"
    },
    {
      "hash": "sha256-k06gPOSNletRadEsHh632YMptX0qTkZAT/pDhhzWT3A=",
      "url": "lib/bootstrap-icons/icons/trophy-fill.svg"
    },
    {
      "hash": "sha256-Yj3po5trbsRELExejTxQ8wFo6vtWymQwGSL6pTMBd/Q=",
      "url": "lib/bootstrap-icons/icons/trophy.svg"
    },
    {
      "hash": "sha256-+E3KRDUyIbt5upe6AFhF9xfvqPAd5YlhmE3UG3YSa28=",
      "url": "lib/bootstrap-icons/icons/tropical-storm.svg"
    },
    {
      "hash": "sha256-vE5MCWfes2ZjEdOLUN8fMh1jpMrZrfaLa4kiijsJonM=",
      "url": "lib/bootstrap-icons/icons/truck-flatbed.svg"
    },
    {
      "hash": "sha256-LEajAyBW0YR1yk4bocUQ+nMrO+aAWjzYbDTmiRtn+4w=",
      "url": "lib/bootstrap-icons/icons/truck-front-fill.svg"
    },
    {
      "hash": "sha256-szqal6ksDlyLCyPgw1DfZyehOEKQUKxNMoE0vNxWObA=",
      "url": "lib/bootstrap-icons/icons/truck-front.svg"
    },
    {
      "hash": "sha256-Hct6MsGSdyNd+097RVqpr5eKT7IWf7S0PhaSyh3OFGI=",
      "url": "lib/bootstrap-icons/icons/truck.svg"
    },
    {
      "hash": "sha256-GBAPZuMziDq6Jq2wm8eldn1PCZKrncDI2nSgngLno2A=",
      "url": "lib/bootstrap-icons/icons/tsunami.svg"
    },
    {
      "hash": "sha256-67rwyUcN+gSQqsV5/RjatJFloJaBNKerX33+vDc6gJk=",
      "url": "lib/bootstrap-icons/icons/tv-fill.svg"
    },
    {
      "hash": "sha256-wtrdWK0Cxg6fPAy0NugCJxkttmzLs+dAcvQirxzFDJ8=",
      "url": "lib/bootstrap-icons/icons/tv.svg"
    },
    {
      "hash": "sha256-9ZbogWb481I52uRiCLr1526aupX/bkwhGeZ3Id4nyYk=",
      "url": "lib/bootstrap-icons/icons/twitch.svg"
    },
    {
      "hash": "sha256-J1cO2/8CxKF3ZstcXMoM9/PYTnQ4Q0etVzbiM0PyLYw=",
      "url": "lib/bootstrap-icons/icons/twitter-x.svg"
    },
    {
      "hash": "sha256-4EGzsRDfIkiFOT5FCuNDtAnlPuYvi5sO4e0285TcKys=",
      "url": "lib/bootstrap-icons/icons/twitter.svg"
    },
    {
      "hash": "sha256-D0XG5+GQA4O5eBbuImqLXLf4NtlI1QO8mARnhMOv/bg=",
      "url": "lib/bootstrap-icons/icons/type-bold.svg"
    },
    {
      "hash": "sha256-yx0G7rPSgpas+lQsYUhXFgU/L80SfHWzmO7HK3Bv2lI=",
      "url": "lib/bootstrap-icons/icons/type-h1.svg"
    },
    {
      "hash": "sha256-7XObZy+kIcMpsRyv8kZF7dYEH80krBztP8aueaKwKZo=",
      "url": "lib/bootstrap-icons/icons/type-h2.svg"
    },
    {
      "hash": "sha256-rqn2+fO52ef9oCZegUdNBnJdw07NBHZ1aYfRY5Jayvw=",
      "url": "lib/bootstrap-icons/icons/type-h3.svg"
    },
    {
      "hash": "sha256-Uuzzotequ7aTDuL7vpfY9KWg5pH47Wour5olbaSv0sE=",
      "url": "lib/bootstrap-icons/icons/type-h4.svg"
    },
    {
      "hash": "sha256-xccEbJmyDMFlDFmJXhkTxA0ZQxwHURjUnmppq8SO3xU=",
      "url": "lib/bootstrap-icons/icons/type-h5.svg"
    },
    {
      "hash": "sha256-n/uTi0s/p91VW/H8Jj+/BiMUu+RmLjoleQbqBnQlL5w=",
      "url": "lib/bootstrap-icons/icons/type-h6.svg"
    },
    {
      "hash": "sha256-EcTBPRq6/fMfoV94wB3yqnwrOgJ3pPDjB/TxfGCmZi8=",
      "url": "lib/bootstrap-icons/icons/type-italic.svg"
    },
    {
      "hash": "sha256-RwISjLSKTLPENF7JNWHq2wwCqGVpwAPfczvM1MKTw24=",
      "url": "lib/bootstrap-icons/icons/type-strikethrough.svg"
    },
    {
      "hash": "sha256-9yEfHndamHYYhBJvyv5DXQW6QV089VHvth0b3ISUNk0=",
      "url": "lib/bootstrap-icons/icons/type-underline.svg"
    },
    {
      "hash": "sha256-+NgcC+vxW/Uve7f1Tgj0pyBxjDzpNRvTNCmA4IPBRWc=",
      "url": "lib/bootstrap-icons/icons/type.svg"
    },
    {
      "hash": "sha256-pobKUzze2qrn6iWdy9MPoLodYtkgTuu+gmJqgO3l1QA=",
      "url": "lib/bootstrap-icons/icons/ubuntu.svg"
    },
    {
      "hash": "sha256-0ZmA1xalmFYcbqAUNnXwxfBw7Y6HhmAqG9phwNqI+2E=",
      "url": "lib/bootstrap-icons/icons/ui-checks-grid.svg"
    },
    {
      "hash": "sha256-3Vsn6V8e9qKYUbcf+nqDVqD4UVntIK8IAtDbzaBFk6A=",
      "url": "lib/bootstrap-icons/icons/ui-checks.svg"
    },
    {
      "hash": "sha256-lmwClvO1mH5bbSvqLy8ny+R10OiG7JTIfKcc7R0KpG4=",
      "url": "lib/bootstrap-icons/icons/ui-radios-grid.svg"
    },
    {
      "hash": "sha256-vpbCX3TE4iiAwIj8ACM8/vOjcrjOx3BS8vPO/MMfIGA=",
      "url": "lib/bootstrap-icons/icons/ui-radios.svg"
    },
    {
      "hash": "sha256-BVTJpYmge/bKiS/0BooqSIPdRoGV40WLj5XRv/jGP0c=",
      "url": "lib/bootstrap-icons/icons/umbrella-fill.svg"
    },
    {
      "hash": "sha256-K6dTT0NJJVXsgF61piAqy52vtO5mM3ynnAe7W+bREis=",
      "url": "lib/bootstrap-icons/icons/umbrella.svg"
    },
    {
      "hash": "sha256-hbcEpDvUEZGTCxHP/Hj62RlLOeaSgIS4h/wCG76e2M8=",
      "url": "lib/bootstrap-icons/icons/unindent.svg"
    },
    {
      "hash": "sha256-1sg1F4RE2jKICcZRB24BgRIGeNM7CORA6wdLJ9dBYpY=",
      "url": "lib/bootstrap-icons/icons/union.svg"
    },
    {
      "hash": "sha256-F5eYFoI4g8YFD5JJv9P8lN+emG1M9oS9WR0i8jRSezk=",
      "url": "lib/bootstrap-icons/icons/unity.svg"
    },
    {
      "hash": "sha256-HYz3qmiv1EX2YffFiTTuUsazZrsBJSjyhMhnehfsTdc=",
      "url": "lib/bootstrap-icons/icons/universal-access-circle.svg"
    },
    {
      "hash": "sha256-zYdrTLmwKJ5loOEbO0IYQ+M1zm+S1YVmexsHiuHFqqg=",
      "url": "lib/bootstrap-icons/icons/universal-access.svg"
    },
    {
      "hash": "sha256-DRd+ni6qzsNiIP2C429Ul3ZSvU8VLj39WdacfXopaoY=",
      "url": "lib/bootstrap-icons/icons/unlock-fill.svg"
    },
    {
      "hash": "sha256-IL/VQuptXwPeYUCFIHT0XfNGeZgybwM4Ral8zOPjNKA=",
      "url": "lib/bootstrap-icons/icons/unlock.svg"
    },
    {
      "hash": "sha256-sWNtM/sSq4NN2BPoBlSWijEbRwg+pxTGa2h+8C6dHnc=",
      "url": "lib/bootstrap-icons/icons/upc-scan.svg"
    },
    {
      "hash": "sha256-ZI6ytRRAg9FzMkolwEGwfF+zguyr/xwyr0+UwN7haVY=",
      "url": "lib/bootstrap-icons/icons/upc.svg"
    },
    {
      "hash": "sha256-x7U62J34Fv1Hyo0wyL5NBCNJY1nHbny7arm9USJOKlA=",
      "url": "lib/bootstrap-icons/icons/upload.svg"
    },
    {
      "hash": "sha256-UfvFQeXcs3P0wXVcAfukGlBDiVpEh5/jnR8YWWzoF2E=",
      "url": "lib/bootstrap-icons/icons/usb-c-fill.svg"
    },
    {
      "hash": "sha256-olniQgXloLgzZmTawcKzWy3XtQNcDnPLfaJWQRCDlLc=",
      "url": "lib/bootstrap-icons/icons/usb-c.svg"
    },
    {
      "hash": "sha256-ie20UE3sPUWghhj+l/RbglfTVg5D0a0+PJJNABOnhcs=",
      "url": "lib/bootstrap-icons/icons/usb-drive-fill.svg"
    },
    {
      "hash": "sha256-SXwCgxlhekl3rTJob5zN+8+A0zERK8yPn2dqi+esLm4=",
      "url": "lib/bootstrap-icons/icons/usb-drive.svg"
    },
    {
      "hash": "sha256-CBPgeF0N/X6trzaLJU5bw4RLnoUm2c5YsH9vZGw7lqE=",
      "url": "lib/bootstrap-icons/icons/usb-fill.svg"
    },
    {
      "hash": "sha256-O6ShPdu1HrvT7P86ove2aDjOpHI/nq686/y+oeWWI1g=",
      "url": "lib/bootstrap-icons/icons/usb-micro-fill.svg"
    },
    {
      "hash": "sha256-i7XgiViTexREVnIQ8TCT4iib48GZbJxIHW6YDjyY4Kg=",
      "url": "lib/bootstrap-icons/icons/usb-micro.svg"
    },
    {
      "hash": "sha256-HEDi+wQbhH/khh3HGL4aHLW0BfhVTKNRrdvdLJSJ0Ns=",
      "url": "lib/bootstrap-icons/icons/usb-mini-fill.svg"
    },
    {
      "hash": "sha256-cV33VnJ2KIYo0ULKlT96TgSSAevJqq3Mi1CqM4vjnqM=",
      "url": "lib/bootstrap-icons/icons/usb-mini.svg"
    },
    {
      "hash": "sha256-hDHAcOmO3YOprrwpc/6MpHY/RiH0ayxdV/N3eOnItp8=",
      "url": "lib/bootstrap-icons/icons/usb-plug-fill.svg"
    },
    {
      "hash": "sha256-WXNF9/UpxFsbg+ruptbiqy5x/8nFS0gfcHAe/3UwZ8g=",
      "url": "lib/bootstrap-icons/icons/usb-plug.svg"
    },
    {
      "hash": "sha256-EGJonfv6QKbcxYDb1SJtGO60+EndLKW1fbIrZuai3E8=",
      "url": "lib/bootstrap-icons/icons/usb-symbol.svg"
    },
    {
      "hash": "sha256-Oxsg6xBSs5MiUXr9r/qCwAHzXo5Ybn/lh/SCqJqK4Zo=",
      "url": "lib/bootstrap-icons/icons/usb.svg"
    },
    {
      "hash": "sha256-Az9JPFutaJfQBhxfBCoYTdE896zjxhHI3DGZBjD4FrU=",
      "url": "lib/bootstrap-icons/icons/valentine.svg"
    },
    {
      "hash": "sha256-4+v7JNcQdTMhieS7LUL0VK0l5XaDEu0dlEEM7VI04/U=",
      "url": "lib/bootstrap-icons/icons/valentine2.svg"
    },
    {
      "hash": "sha256-BtScWDiIedC2kw87ypmMjg/S/JaUGFiBKRWu6XdO/8c=",
      "url": "lib/bootstrap-icons/icons/vector-pen.svg"
    },
    {
      "hash": "sha256-uuhCIPU+SdXZ+uZAEsF2O0YEvrWGDYoMVXLWhHUN0Sc=",
      "url": "lib/bootstrap-icons/icons/view-list.svg"
    },
    {
      "hash": "sha256-SFSloIYLpgsWKBpjURpSaCWx8dezLCKyosuIk3gcK/k=",
      "url": "lib/bootstrap-icons/icons/view-stacked.svg"
    },
    {
      "hash": "sha256-5p9HZSSDgkdNrKNL8hfbXMA5zrlhoXWxdjFafRv5pyM=",
      "url": "lib/bootstrap-icons/icons/vignette.svg"
    },
    {
      "hash": "sha256-RjiT+Nf1zEjjbOCt8P7uytlHVMrdYm4b5lGAwuBFsZU=",
      "url": "lib/bootstrap-icons/icons/vimeo.svg"
    },
    {
      "hash": "sha256-euWqJyXW5hnZiuuoX5oqub7+OWx5eILH6Ab+O/JjQGQ=",
      "url": "lib/bootstrap-icons/icons/vinyl-fill.svg"
    },
    {
      "hash": "sha256-0TSa5UtgNO2fsabNxzVYkH1RXrAh+GLqPlm1DyHR2Ng=",
      "url": "lib/bootstrap-icons/icons/vinyl.svg"
    },
    {
      "hash": "sha256-t8m/mgAsomUMhkiFMtIQzoHed+xwgj0x9QT6UQ0mW9o=",
      "url": "lib/bootstrap-icons/icons/virus.svg"
    },
    {
      "hash": "sha256-qERd4ZP/eU4r8+EFuXopLWZj89uXCjmNN3+YQ5tnyx0=",
      "url": "lib/bootstrap-icons/icons/virus2.svg"
    },
    {
      "hash": "sha256-jUCk+xr5S2mv7A7qKfHeJ1/VfksE6dtSIgu1MSI6gGc=",
      "url": "lib/bootstrap-icons/icons/voicemail.svg"
    },
    {
      "hash": "sha256-TQAA3OEPsrXHyh0ttDKzsZpKn3sGdx3o+YqqnEIIX70=",
      "url": "lib/bootstrap-icons/icons/volume-down-fill.svg"
    },
    {
      "hash": "sha256-wCGiG2GHnf5xrtqiyLXnVROg+O0roK7J7ohpdkkBCE8=",
      "url": "lib/bootstrap-icons/icons/volume-down.svg"
    },
    {
      "hash": "sha256-dCQwsYu8G/p7cBDmOwmraQWl0opD1jE9NVBgNzExf40=",
      "url": "lib/bootstrap-icons/icons/volume-mute-fill.svg"
    },
    {
      "hash": "sha256-3SZJRrWKISGalwhMpQKO2L09fPPp1rGWRxS4bxG8Ac0=",
      "url": "lib/bootstrap-icons/icons/volume-mute.svg"
    },
    {
      "hash": "sha256-xF+glghCa3O3WVR9La5oKIk9DSuvP+KRbPxiugQ+bIY=",
      "url": "lib/bootstrap-icons/icons/volume-off-fill.svg"
    },
    {
      "hash": "sha256-tZ64/evIqBpxdzDLq5p0UTAxoVGCV8sM2J2duGQ3v20=",
      "url": "lib/bootstrap-icons/icons/volume-off.svg"
    },
    {
      "hash": "sha256-gV5+BBt9oFBOG0zV3JxLCafWMiapPcfnraTwnDGb7ug=",
      "url": "lib/bootstrap-icons/icons/volume-up-fill.svg"
    },
    {
      "hash": "sha256-NY8s4svd330QeTBP5zHPrr0NZOBhD62XoSkCRvgFeq0=",
      "url": "lib/bootstrap-icons/icons/volume-up.svg"
    },
    {
      "hash": "sha256-yRMKBzMaX4AU3tZNwGITpp/v5RbJp6dkROSY5KcqgXU=",
      "url": "lib/bootstrap-icons/icons/vr.svg"
    },
    {
      "hash": "sha256-ROqYmO5nkmyPb43vuHiyJW2UD/Y/lrQXf1pgzsN0dPU=",
      "url": "lib/bootstrap-icons/icons/wallet-fill.svg"
    },
    {
      "hash": "sha256-sHyEEhx6xnk3cS+TyZHXruQAP3ypzrR3s6Tnq+ApZwM=",
      "url": "lib/bootstrap-icons/icons/wallet.svg"
    },
    {
      "hash": "sha256-z5DIQiFMCIEoK4YR8Ga7IM8uOutc+6q+WtNDyLxueZE=",
      "url": "lib/bootstrap-icons/icons/wallet2.svg"
    },
    {
      "hash": "sha256-+uB0pU8EaVTpFUH79djTrrLrqlAp05LCQjN6gZXAdDo=",
      "url": "lib/bootstrap-icons/icons/watch.svg"
    },
    {
      "hash": "sha256-O7pqFjHgrrkw6ercxPryStTGwFnJOynQoXl7n2AZgQQ=",
      "url": "lib/bootstrap-icons/icons/water.svg"
    },
    {
      "hash": "sha256-79l/YFxX6ZsXDNDdxfBhVucrPYor+FdRbLABRL+mr50=",
      "url": "lib/bootstrap-icons/icons/webcam-fill.svg"
    },
    {
      "hash": "sha256-3f0DR4jT0h0fw8UdKLzDMbnoDEWU0veiRupJlsLhl8w=",
      "url": "lib/bootstrap-icons/icons/webcam.svg"
    },
    {
      "hash": "sha256-Ed0pc2pWhHVulfi7JeAOSCUDmff7Akuldug56AY5TgQ=",
      "url": "lib/bootstrap-icons/icons/wechat.svg"
    },
    {
      "hash": "sha256-uVD9ujDjX6kSlcZK7rndxFzQG4+wzq26Hk4SN5UOcpg=",
      "url": "lib/bootstrap-icons/icons/whatsapp.svg"
    },
    {
      "hash": "sha256-d0BdsYQvSCmHlM70lBsStjQt3UocYKRWdLd4CRjoiiQ=",
      "url": "lib/bootstrap-icons/icons/wifi-1.svg"
    },
    {
      "hash": "sha256-CRn3N0FofapL5BJHEYAmWHngPo695lSsGHJXaf5sUTM=",
      "url": "lib/bootstrap-icons/icons/wifi-2.svg"
    },
    {
      "hash": "sha256-vhOsoc4J44zVoAxNOD7d7mTxNeCqvxlUvg/18NrOPoU=",
      "url": "lib/bootstrap-icons/icons/wifi-off.svg"
    },
    {
      "hash": "sha256-5h1zCGetLpEkIrH2bIAWO7eNtL2HOiCyxfqokCl57CQ=",
      "url": "lib/bootstrap-icons/icons/wifi.svg"
    },
    {
      "hash": "sha256-ggZlvjXtdxF4ciLZ4ibf0BrcQyRGDB7tfAxx2JpcbLg=",
      "url": "lib/bootstrap-icons/icons/wikipedia.svg"
    },
    {
      "hash": "sha256-bp1uc0AXvg4lQ/pM/gNcjCGtXjtbev9dr7reYiCVKPA=",
      "url": "lib/bootstrap-icons/icons/wind.svg"
    },
    {
      "hash": "sha256-AJjUA/PpXv5b1bpcx64ZlDNUYIF0X77zsHmZ9dZg5tc=",
      "url": "lib/bootstrap-icons/icons/window-dash.svg"
    },
    {
      "hash": "sha256-mS36PVoFCDBsQoIriJjrX5dTcmwbK02ll5JCrohn7E8=",
      "url": "lib/bootstrap-icons/icons/window-desktop.svg"
    },
    {
      "hash": "sha256-+PF9iMZIGmWIZL6HEEX5/Mly13I1lo2D7+hSnDLHELs=",
      "url": "lib/bootstrap-icons/icons/window-dock.svg"
    },
    {
      "hash": "sha256-VsLXiuDEpqZ9OtNQnTXzgOkrxE5t6AS/xQ0aY7qcRkE=",
      "url": "lib/bootstrap-icons/icons/window-fullscreen.svg"
    },
    {
      "hash": "sha256-dWiqI1dI6MJ8gMJWqJJnPK2kvY3xi90ZdxOnmo8fbn0=",
      "url": "lib/bootstrap-icons/icons/window-plus.svg"
    },
    {
      "hash": "sha256-ot2RYFRNm69tvzE2ljTA4vaBQjxEnvK/8Bp9PgZNJn4=",
      "url": "lib/bootstrap-icons/icons/window-sidebar.svg"
    },
    {
      "hash": "sha256-BOOB8IxIJG9Qo4MCoX6KiuSoOH9Hjqc2LuzTL5/9PjE=",
      "url": "lib/bootstrap-icons/icons/window-split.svg"
    },
    {
      "hash": "sha256-eqvFGG8vp1rsvmidhfB0tOvdH6WcsanlOsDw8fRxVvo=",
      "url": "lib/bootstrap-icons/icons/window-stack.svg"
    },
    {
      "hash": "sha256-mvySLOOTxm5I5+up5BqENQsdDit4WZhxacfH7ZcqbyE=",
      "url": "lib/bootstrap-icons/icons/window-x.svg"
    },
    {
      "hash": "sha256-EH6hRIAb2OxaA7VUlH0ZRekyved8VRQxAGQjQm8dKU4=",
      "url": "lib/bootstrap-icons/icons/window.svg"
    },
    {
      "hash": "sha256-6qEutxDz59hAMlQG4UkGwQNIOUfxN58Fz7TKp/NlZLg=",
      "url": "lib/bootstrap-icons/icons/windows.svg"
    },
    {
      "hash": "sha256-IDOYa3s93muJwNglF+8wUjbY82EIRSCCSqvMLWl+RpU=",
      "url": "lib/bootstrap-icons/icons/wordpress.svg"
    },
    {
      "hash": "sha256-4En6N0Ihy6w3gxUCorD81U8mPoezaQ0G06K7QUfqAdU=",
      "url": "lib/bootstrap-icons/icons/wrench-adjustable-circle-fill.svg"
    },
    {
      "hash": "sha256-00TjWzVynBhN6Z9KuiF0oyUMIP/LFaQXWc6ldB7DuiM=",
      "url": "lib/bootstrap-icons/icons/wrench-adjustable-circle.svg"
    },
    {
      "hash": "sha256-I8xi0Q9t+gBeAlBedOT9UiQRQLfad/Wtfc2/jffChgo=",
      "url": "lib/bootstrap-icons/icons/wrench-adjustable.svg"
    },
    {
      "hash": "sha256-wt7cFJIVIjzJBZHhFfPFTMzhORPaIq9l8YHf4jCeyrQ=",
      "url": "lib/bootstrap-icons/icons/wrench.svg"
    },
    {
      "hash": "sha256-4vEe8JvQiySsfzaNtQJs6zQNHGRjW8tNutekWzwyL0s=",
      "url": "lib/bootstrap-icons/icons/x-circle-fill.svg"
    },
    {
      "hash": "sha256-XWvW0kTT8AJr8AYZ1d/Gu8UrTwNP5HukFHcUve12Gvk=",
      "url": "lib/bootstrap-icons/icons/x-circle.svg"
    },
    {
      "hash": "sha256-RiNCwSBfkSeDp8y7U+Goq/2HL70phEC4MbHOBvDfKqo=",
      "url": "lib/bootstrap-icons/icons/x-diamond-fill.svg"
    },
    {
      "hash": "sha256-I7aXDF4mPCIyTcqwYNJYmldr33XgsxxdnkjPod8NLZA=",
      "url": "lib/bootstrap-icons/icons/x-diamond.svg"
    },
    {
      "hash": "sha256-X6FTA+AaaayZywB2Zxkd63ahMNBam2rQV8ZDSJ1jkRs=",
      "url": "lib/bootstrap-icons/icons/x-lg.svg"
    },
    {
      "hash": "sha256-Ex6Bb0fPWfEua8KG2FxUMGFM8ZfSrDdoK0ZD5TMgylY=",
      "url": "lib/bootstrap-icons/icons/x-octagon-fill.svg"
    },
    {
      "hash": "sha256-BUtAmvZ6v9bCmfnV6EGBeQD4iOTxbABxjBPVacFPJQE=",
      "url": "lib/bootstrap-icons/icons/x-octagon.svg"
    },
    {
      "hash": "sha256-8IOET/r6RXoZHwBJTry8CeiasS1rjzZliP0RoFh7/iE=",
      "url": "lib/bootstrap-icons/icons/x-square-fill.svg"
    },
    {
      "hash": "sha256-qWudnWsCWTnjV1fJbXHK8/D57Vzl2km2a8wOaDLHP/g=",
      "url": "lib/bootstrap-icons/icons/x-square.svg"
    },
    {
      "hash": "sha256-repqt++9yJvSrgvrNKyersUyx7G7Jn0Tn7qTzP6ao7s=",
      "url": "lib/bootstrap-icons/icons/x.svg"
    },
    {
      "hash": "sha256-GCoiC4KjFXKXsalCQMIqREWDS8XFOJWTKODgU+YvZGI=",
      "url": "lib/bootstrap-icons/icons/xbox.svg"
    },
    {
      "hash": "sha256-7YHRfFcrxISOYe1O8nhGNOtSQmIK/U49eVEheFORw1Q=",
      "url": "lib/bootstrap-icons/icons/yelp.svg"
    },
    {
      "hash": "sha256-PHpWjZMlT8NG2ZEkmFBXSI/ixQhw9Njfj9Am+lDDIx0=",
      "url": "lib/bootstrap-icons/icons/yin-yang.svg"
    },
    {
      "hash": "sha256-byIXc0Nm2SCnHH1gZTUE14Y2WhXA5d3b1TgdW5qCils=",
      "url": "lib/bootstrap-icons/icons/youtube.svg"
    },
    {
      "hash": "sha256-wcdfWBE63xSmwElAKH2sX88z8wV5XDE4lVnCuoXRtbg=",
      "url": "lib/bootstrap-icons/icons/zoom-in.svg"
    },
    {
      "hash": "sha256-DEnEcAyBEqUF+ZrWUAfM/D5d1bWOT6sClMtIu144yD8=",
      "url": "lib/bootstrap-icons/icons/zoom-out.svg"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-yqJbuxDFmwL0oupMEH6c1Q3OCRO8qw4WSHvlQRlb4KY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-r+iDum4jijP2np52WwFnkwAtvsf5vg46dwDEl+CDZL4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-rgXh27bIoUwMbWXiM1GrISJJYqaSSgW0tLabxR76pxs=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-gPiOfBh4niooXVDg7bqWQ73OU3VDJSBaYls14ZdUHaI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-7oKWiOae9WVSZBYW2WJC+kp7H0A7ub1LDuu0aAsHKnI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-VK7d6Or2uduKYXysDWKzSqRF4KKzG3NxsbUB5l6xGYc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-E5FuxjQMWBtXqld0VP54vDsS7TojaklkAiuFhqDOt7E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-XHwOVjHGSkZaX1Av2q6My93E3o9tjp04sK4z3pJd7/c=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-e0Z07ryp1j8UeY00pm/7gDWavwOirnGmDRXuB/V3SEg=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-bNojyBU9M3Cv/K4YqdKkq4xeaAkchkkS7HXP7554z9Y=",
      "url": "lib/bootstrap/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-Wq4aWW1rQdJ+6oAgy1JQc9IBjHL9T3MKfXTBNqOv02c=",
      "url": "lib/bootstrap/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-Xj4HYxZBQ7qqHKBwa2EAugRS+RHWzpcTtI49vgezUSU=",
      "url": "lib/bootstrap/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-idJzCWndWIhl4ZZvXbuLRTe5wquRfykXbEiDpO7ZsFk=",
      "url": "lib/bootstrap/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-EPRLgpqWkahLxEn6CUjdM76RIYIw1xdHwTbeHssuj/4=",
      "url": "lib/bootstrap/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Tsbv8z6VlNgVET8xvz/yLo/v5iJHTAj2J4hkhjP1rHM=",
      "url": "lib/bootstrap/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-vqK8KwEVuWidx0Ddm5m5LyBriPDPl9TcjrKZQhkFSVA=",
      "url": "lib/bootstrap/js/bootstrap.js"
    },
    {
      "hash": "sha256-9Wr7Hxe8gCJDoIHh5xP29ldXvC3kN2GkifQj9c8vYx4=",
      "url": "lib/bootstrap/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-ZI01e/ns473GKvACG4McggJdxvFfFIw4xspwQiG8Ye4=",
      "url": "lib/bootstrap/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-cx/Bp0z4F3TuBpK7NQ4T1F59Eyr9oOhzFq8Z1yClEKg=",
      "url": "lib/bootstrap/scss/_accordion.scss"
    },
    {
      "hash": "sha256-0/mEckNhK2o/TTMSzC8o7hguVITb9RqsW932mV2HS7U=",
      "url": "lib/bootstrap/scss/_alert.scss"
    },
    {
      "hash": "sha256-6W0FGDImRRolMBZ8roPSxzAZytRerq5rZZmij7K0QXI=",
      "url": "lib/bootstrap/scss/_badge.scss"
    },
    {
      "hash": "sha256-J//dL7QpVH9SVIElSWfKF5NBHHFSJ6RSnypbf9oDd1c=",
      "url": "lib/bootstrap/scss/_breadcrumb.scss"
    },
    {
      "hash": "sha256-kSy6qJ6uyh8XXV3isUW/jzsCE1hiyiM9P78CayxBD7w=",
      "url": "lib/bootstrap/scss/_button-group.scss"
    },
    {
      "hash": "sha256-XFs4qVbkObBqIvUJsL2CkZ6utlWNxzcbt189q8nX0kk=",
      "url": "lib/bootstrap/scss/_buttons.scss"
    },
    {
      "hash": "sha256-nI+vrbqw1892CKe0B/klWJK7lQ7HoQn9IK5/FrNuIf8=",
      "url": "lib/bootstrap/scss/_card.scss"
    },
    {
      "hash": "sha256-QU6aDCIzUft2XsSyUGbxm/llU6F12odCe04lwEKzY/o=",
      "url": "lib/bootstrap/scss/_carousel.scss"
    },
    {
      "hash": "sha256-x41iesxtbRfWEhFLqN1LFye6r3xfHnC9j4rho6joK58=",
      "url": "lib/bootstrap/scss/_close.scss"
    },
    {
      "hash": "sha256-JQl05Z+i3fW4c+EhBtVhPmosgSjZLzdNz5rETSFBoMU=",
      "url": "lib/bootstrap/scss/_containers.scss"
    },
    {
      "hash": "sha256-ZSHg5iUWLDbwYZprRKSWOTmseuI3MKZ0WSrUQSSZAno=",
      "url": "lib/bootstrap/scss/_dropdown.scss"
    },
    {
      "hash": "sha256-AvUsGh+Z9V0R0LCjBVGPCmUnEoCHAZllo0gtrgFcrkg=",
      "url": "lib/bootstrap/scss/_forms.scss"
    },
    {
      "hash": "sha256-rsPX9rxJFprxcPlfv8ptPrsZzXjCWgutTpj0Cx0kldw=",
      "url": "lib/bootstrap/scss/_functions.scss"
    },
    {
      "hash": "sha256-J7lAh+brKn3+KtC5GlIiIq+XYwd+pObpnG/g+YqGtNw=",
      "url": "lib/bootstrap/scss/_grid.scss"
    },
    {
      "hash": "sha256-hA+dFAYHd/01bQ91rhtK0yowUDnncRJcM31kb0/w5b8=",
      "url": "lib/bootstrap/scss/_helpers.scss"
    },
    {
      "hash": "sha256-JyvseLe8A93FtxPzOEPqKtiElB31vaA8SunDmWeN8J0=",
      "url": "lib/bootstrap/scss/_images.scss"
    },
    {
      "hash": "sha256-AYfUz0pLr9TOSgvH+RNcNGsFeiYra3Xs9I9dsxYFuKg=",
      "url": "lib/bootstrap/scss/_list-group.scss"
    },
    {
      "hash": "sha256-Ey4ltFp8iVROLtsCDlewEyOuXeR9CR5g7Qdca4seJGM=",
      "url": "lib/bootstrap/scss/_maps.scss"
    },
    {
      "hash": "sha256-o1eo6Y9NkK/1uDDu+ZcwoTK3taplcEb/poNn19+Oh+4=",
      "url": "lib/bootstrap/scss/_mixins.scss"
    },
    {
      "hash": "sha256-W1Igs+fHPro/BnbP4/eTX7lDmjj+LELLUX728oGBdpo=",
      "url": "lib/bootstrap/scss/_modal.scss"
    },
    {
      "hash": "sha256-iAfO7m7wrHDT/fuPGmwFtRXFP30+LIoJU+p8gcuO67g=",
      "url": "lib/bootstrap/scss/_nav.scss"
    },
    {
      "hash": "sha256-CXyZFJxjV5CCO84sSCaILAyA9JsnCGUblDXNwrniLII=",
      "url": "lib/bootstrap/scss/_navbar.scss"
    },
    {
      "hash": "sha256-khpc3ku1INF5xSDCvCHb63KYVuarkqJVe/XTt8y0zvU=",
      "url": "lib/bootstrap/scss/_offcanvas.scss"
    },
    {
      "hash": "sha256-xoHiBtf43m8M66AJYScdOiXhb5eiR5j21e3GEk4+260=",
      "url": "lib/bootstrap/scss/_pagination.scss"
    },
    {
      "hash": "sha256-sK2zq5Gk7FBiktiVXCf12WMGYI2eZm4jBgc9H7cVc/s=",
      "url": "lib/bootstrap/scss/_placeholders.scss"
    },
    {
      "hash": "sha256-35FXE4mCbcXIwmqtzj6QWPdMAAibj7XvNk2WVhSUYp8=",
      "url": "lib/bootstrap/scss/_popover.scss"
    },
    {
      "hash": "sha256-4mg5x40lxBR6QHKbHF1S5ORaHNdZUD6C0m5tzGubZvw=",
      "url": "lib/bootstrap/scss/_progress.scss"
    },
    {
      "hash": "sha256-PtsBsteAiXrbcUPbwbxXq6ckM+BctrWbPL2wG2ZDH0o=",
      "url": "lib/bootstrap/scss/_reboot.scss"
    },
    {
      "hash": "sha256-R35xHKV6cvrRw092okAwWIlhDI5hiuVFzgcUGm7qx1A=",
      "url": "lib/bootstrap/scss/_root.scss"
    },
    {
      "hash": "sha256-5GDzB0gH27iJR+s3b612wpXq8tdXDv3TtbcAWS3Og+M=",
      "url": "lib/bootstrap/scss/_spinners.scss"
    },
    {
      "hash": "sha256-mz/V+Mt0sfcaDeFROZL/OGUjzzJW3whkipRH7sZ5G7I=",
      "url": "lib/bootstrap/scss/_tables.scss"
    },
    {
      "hash": "sha256-T3xYbYlt7SJd7eQhSCRXofygx/803WJNGjtCtnDD3X0=",
      "url": "lib/bootstrap/scss/_toasts.scss"
    },
    {
      "hash": "sha256-8LSRQuYVv9nS8JSs3qkfHWHtDnZB+BJLBh+YBGGb8jA=",
      "url": "lib/bootstrap/scss/_tooltip.scss"
    },
    {
      "hash": "sha256-1Z/VGUCaOYFgxvB4DY/2hQ7P5lZE21ds/fxc/P1u8OY=",
      "url": "lib/bootstrap/scss/_transitions.scss"
    },
    {
      "hash": "sha256-EwOmjPzITcZ2icNrWihy+M6yygFRxuLh0nhRTpifK3M=",
      "url": "lib/bootstrap/scss/_type.scss"
    },
    {
      "hash": "sha256-wa0xjTU9pBp1j4UhD0R57jlBcSpWy02WPhpfmIqIZVE=",
      "url": "lib/bootstrap/scss/_utilities.scss"
    },
    {
      "hash": "sha256-YgCyd/S3+nP9LnDQKkwPl4QTe2cjFvNRgvyLgPsVYzs=",
      "url": "lib/bootstrap/scss/_variables-dark.scss"
    },
    {
      "hash": "sha256-xTVl362rsvNFkaRWPC3IC+YgYTCd507jlI7CDWeRG6o=",
      "url": "lib/bootstrap/scss/_variables.scss"
    },
    {
      "hash": "sha256-WjxWx625nNgcJt/5Q2x6Z5PIXhIyMJdky33zidW7KRQ=",
      "url": "lib/bootstrap/scss/bootstrap-grid.scss"
    },
    {
      "hash": "sha256-5ZzszWbMHfNJObM7zVF6pGpLQaVDbNw05Wuv0W/shd4=",
      "url": "lib/bootstrap/scss/bootstrap-reboot.scss"
    },
    {
      "hash": "sha256-J8WS8dnQ4D1LDPBk6FVVb6VLuX3WM/ecf5c0k6V3klY=",
      "url": "lib/bootstrap/scss/bootstrap-utilities.scss"
    },
    {
      "hash": "sha256-pKjLZTXCuLCovj2ZY18qEy+Qazlt06JOHebb/mbvVpo=",
      "url": "lib/bootstrap/scss/bootstrap.scss"
    },
    {
      "hash": "sha256-zQkJEZkhLDMI+E7vG9923tain/zCz+QQAJGjY4N28lw=",
      "url": "lib/bootstrap/scss/forms/_floating-labels.scss"
    },
    {
      "hash": "sha256-atTOzCOMO5Wv+sPEH7yKYWYUke3TWEoHIWbwVYOX1IE=",
      "url": "lib/bootstrap/scss/forms/_form-check.scss"
    },
    {
      "hash": "sha256-qeJWiLHb44ssUfy6z+b8ZOdL5CBEq/5/RQfvpkBLEkg=",
      "url": "lib/bootstrap/scss/forms/_form-control.scss"
    },
    {
      "hash": "sha256-03z26wKY58mHnT4vu36NL8dsaIQ6Z7jNB+DU79nZoqE=",
      "url": "lib/bootstrap/scss/forms/_form-range.scss"
    },
    {
      "hash": "sha256-hwzEWjk81cJ5EEAmsZqQK/eo6IWhYnJKrMWASlPB2Q0=",
      "url": "lib/bootstrap/scss/forms/_form-select.scss"
    },
    {
      "hash": "sha256-W0hSmtJ0UIYEQo24nkTKyUiiLEZLKa6wiJ/96QFBcu0=",
      "url": "lib/bootstrap/scss/forms/_form-text.scss"
    },
    {
      "hash": "sha256-uVTkrOjiMSvHyTtGnkqiRSxQ/p5af6AoiBNVJD6xzAA=",
      "url": "lib/bootstrap/scss/forms/_input-group.scss"
    },
    {
      "hash": "sha256-pbBNVjkKsG97ZXE+w80q0rbISF4tokPXmodG880yrlM=",
      "url": "lib/bootstrap/scss/forms/_labels.scss"
    },
    {
      "hash": "sha256-S14gaOzeyOBTJZEW1Or+Eh2mb62u0yOWYqZZUFS/xew=",
      "url": "lib/bootstrap/scss/forms/_validation.scss"
    },
    {
      "hash": "sha256-+UYxtwTkfGhCLNQ5AidubhXVeBaJ4b62X0B4QZUn+og=",
      "url": "lib/bootstrap/scss/helpers/_clearfix.scss"
    },
    {
      "hash": "sha256-jy2v1cr2zr2ERaO/ouHPFkIvjzLRr46FrHox0s6jxwY=",
      "url": "lib/bootstrap/scss/helpers/_color-bg.scss"
    },
    {
      "hash": "sha256-eSreuJZ6y9HzZjXnqTY3rLt75pN1jXE8DfG3fPXzJsY=",
      "url": "lib/bootstrap/scss/helpers/_colored-links.scss"
    },
    {
      "hash": "sha256-fZz4jZW3XHRbmZ/evhAprNFRBNy9sgfzYwOyloU2W6c=",
      "url": "lib/bootstrap/scss/helpers/_focus-ring.scss"
    },
    {
      "hash": "sha256-vWyoZRZVRYE61dtCz1HZbkB+H+pdk34C3DrfrWz4u8k=",
      "url": "lib/bootstrap/scss/helpers/_icon-link.scss"
    },
    {
      "hash": "sha256-47z/U0QeozIgQKINSCIosX0Ka38LPu8Zoe6DqAB4xJk=",
      "url": "lib/bootstrap/scss/helpers/_position.scss"
    },
    {
      "hash": "sha256-dnigijK+aVeGZ6olj90AchdvchWgGOkV6oHb2RdGbmo=",
      "url": "lib/bootstrap/scss/helpers/_ratio.scss"
    },
    {
      "hash": "sha256-39HuJNiK7L5RliaXLveT2lS3Ft/wDNGPfA55h+dkWjw=",
      "url": "lib/bootstrap/scss/helpers/_stacks.scss"
    },
    {
      "hash": "sha256-oApgKK2+2GwoWogCS6K7GJZUe7ryjkVHYyY4AR+14lM=",
      "url": "lib/bootstrap/scss/helpers/_stretched-link.scss"
    },
    {
      "hash": "sha256-3x2S9ExDjTCncNtWcN2LFWf9lpigbuvS4WaWJUP3Amk=",
      "url": "lib/bootstrap/scss/helpers/_text-truncation.scss"
    },
    {
      "hash": "sha256-oKbIMq9bLQPhS+86kuL5CGarREA4gsGeJEnlRCt4/HI=",
      "url": "lib/bootstrap/scss/helpers/_visually-hidden.scss"
    },
    {
      "hash": "sha256-cfZE1m2rwZ2jMmxwKYVQqQk3KRo7eqOAkx99okr0Cpw=",
      "url": "lib/bootstrap/scss/helpers/_vr.scss"
    },
    {
      "hash": "sha256-ju+Ybss0Fj7xC8IuLfLoeppLnvvM8Fg7RzCRpqSiTCE=",
      "url": "lib/bootstrap/scss/mixins/_alert.scss"
    },
    {
      "hash": "sha256-eEBPeclijk6nhwOXlKUn7g7S9Zc7z6YAOr9OMrzL41A=",
      "url": "lib/bootstrap/scss/mixins/_backdrop.scss"
    },
    {
      "hash": "sha256-MUKdWFICc29bAjiN/wqWQHvshdD5ez0P5dN7B7YTwkc=",
      "url": "lib/bootstrap/scss/mixins/_banner.scss"
    },
    {
      "hash": "sha256-O4eHfMq+iPZRBvWzNCWuBWwrypKxs486ooFMUZiHHbk=",
      "url": "lib/bootstrap/scss/mixins/_border-radius.scss"
    },
    {
      "hash": "sha256-hZVcetQftFG0J+rKbsr2gDUadBUkoCShJNGtUmvc2zc=",
      "url": "lib/bootstrap/scss/mixins/_box-shadow.scss"
    },
    {
      "hash": "sha256-PKllyCZhpDn79yy9E04Nwc8eGtyXMjV3yZ5eVASUU14=",
      "url": "lib/bootstrap/scss/mixins/_breakpoints.scss"
    },
    {
      "hash": "sha256-qDbAn2FFN3x6MmJCt3oHKeoz7sJm28WwKVflpM7eppw=",
      "url": "lib/bootstrap/scss/mixins/_buttons.scss"
    },
    {
      "hash": "sha256-uTwP8iLYIQzP1GCHEk+MqE4O2oWnigqnXc3f0A0CfXU=",
      "url": "lib/bootstrap/scss/mixins/_caret.scss"
    },
    {
      "hash": "sha256-Ce8UtK/wWv0zokoe6eagwFCxZ8SUIrH1P/SMWoNsQys=",
      "url": "lib/bootstrap/scss/mixins/_clearfix.scss"
    },
    {
      "hash": "sha256-IKAl5kj4zDNSc9HrMUMuhzO5PqdzoLarkt4V1SphGXs=",
      "url": "lib/bootstrap/scss/mixins/_color-mode.scss"
    },
    {
      "hash": "sha256-QrV0wLsv5CQsd62lHLyGxgLfPklQQj+8fAOMOI1Hw9U=",
      "url": "lib/bootstrap/scss/mixins/_color-scheme.scss"
    },
    {
      "hash": "sha256-Hfe5Tm69W2/KDpupq34AJugO63sWO3maejT4WWqNQpM=",
      "url": "lib/bootstrap/scss/mixins/_container.scss"
    },
    {
      "hash": "sha256-NZVOv1dTXwIhd3X4Hki59M/21gcbQf/xZtVNOqb+owE=",
      "url": "lib/bootstrap/scss/mixins/_deprecate.scss"
    },
    {
      "hash": "sha256-EPoBo36UgrGw4ouOv0VgPJ+9Lgp8W4QtnjBd60zIndc=",
      "url": "lib/bootstrap/scss/mixins/_forms.scss"
    },
    {
      "hash": "sha256-ixcLsmSUVCGIKOO0u8YxzEaHk5YNo6vS19DfsgKM8dU=",
      "url": "lib/bootstrap/scss/mixins/_gradients.scss"
    },
    {
      "hash": "sha256-LnE10lyVDJMPAcc3YRIRfou/c9U5pyMWSte0SQj7I/o=",
      "url": "lib/bootstrap/scss/mixins/_grid.scss"
    },
    {
      "hash": "sha256-x1sIoaSr8rr7XsVff4MzoS4/6CXHl6oxFGxwcwQzR2s=",
      "url": "lib/bootstrap/scss/mixins/_image.scss"
    },
    {
      "hash": "sha256-TkTEvIHkDm8SkbtAssiAZeOgW0H4W32/zFsZp9UAOGQ=",
      "url": "lib/bootstrap/scss/mixins/_list-group.scss"
    },
    {
      "hash": "sha256-ZbcBJtaGzE1FZihA4MeVhvoDnKp/gFnrE4FZDrLBus8=",
      "url": "lib/bootstrap/scss/mixins/_lists.scss"
    },
    {
      "hash": "sha256-IDcwZxcOXUNMlGs16UtYrDUQ5CHd3N9dWRRzl7JDrdw=",
      "url": "lib/bootstrap/scss/mixins/_pagination.scss"
    },
    {
      "hash": "sha256-H28UtP8gqll7LH5fqHEyqqlROsPeKIzR7MaT2qjp/q4=",
      "url": "lib/bootstrap/scss/mixins/_reset-text.scss"
    },
    {
      "hash": "sha256-nwniJt31zGMsuK+jSQhCZrVpjGTKcxrYtlPh9LdK7SQ=",
      "url": "lib/bootstrap/scss/mixins/_resize.scss"
    },
    {
      "hash": "sha256-34gVRhZjwACqPrrfFRXWQ1mUFoGgD2yb/3JnzHAcwPU=",
      "url": "lib/bootstrap/scss/mixins/_table-variants.scss"
    },
    {
      "hash": "sha256-rR2kTNbQv3kFSOiwxIZ5nQjYH4zVUXQdgIsIo8LMAXg=",
      "url": "lib/bootstrap/scss/mixins/_text-truncate.scss"
    },
    {
      "hash": "sha256-JruZ24+CnW25z5sLoWzlLrBCX14FOFGo9lRYD7WB7A0=",
      "url": "lib/bootstrap/scss/mixins/_transition.scss"
    },
    {
      "hash": "sha256-R5/K1XXe5jgSsA8DZeJwyjxwKxyt9S8qoRvlYRb8bx0=",
      "url": "lib/bootstrap/scss/mixins/_utilities.scss"
    },
    {
      "hash": "sha256-BeESxf4bseLRuxP3JzPxJq5mZoIizsf62+fNxnLEJes=",
      "url": "lib/bootstrap/scss/mixins/_visually-hidden.scss"
    },
    {
      "hash": "sha256-HkXHAAjYfH8FsjGvEQS0wQBSOMUr6z5fsuc3mi2VznI=",
      "url": "lib/bootstrap/scss/utilities/_api.scss"
    },
    {
      "hash": "sha256-nugTddld9zXpl2h5Zgh+0zahj9p1C3jOUjoeVjRuciU=",
      "url": "lib/bootstrap/scss/vendor/_rfs.scss"
    },
    {
      "hash": "sha256-gW4G6wcDgUGX64W7gpLMYegi3JcIe+hXM1XF4/3rd4g=",
      "url": "lib/font-awesome/css/all.css"
    },
    {
      "hash": "sha256-bR9Z4j2eAj5DmVg0rQhWxW1elvT0pTa2L1jiocCUhik=",
      "url": "lib/font-awesome/css/all.min.css"
    },
    {
      "hash": "sha256-RSFhBcqXBRlDXQYQ0kkEGBxbMRNOuB7Vxv21NFPrzrI=",
      "url": "lib/font-awesome/css/brands.css"
    },
    {
      "hash": "sha256-Ru5tQ3E463lOubSl+tWBSzqFtRUgFWliWasc+BQvVhM=",
      "url": "lib/font-awesome/css/brands.min.css"
    },
    {
      "hash": "sha256-hO05WHbv1ZIQ1NHS0zjpEEBP9zRiab3XjmgPBrebY2U=",
      "url": "lib/font-awesome/css/fontawesome.css"
    },
    {
      "hash": "sha256-zLlT2zwpZ3l8rgCaOK9sRRl9qJexS4Ke4aQPjWLWKME=",
      "url": "lib/font-awesome/css/fontawesome.min.css"
    },
    {
      "hash": "sha256-mczWbgS4W6vcWdfooagKyD63ocr3847jwTdu0BrTnEE=",
      "url": "lib/font-awesome/css/regular.css"
    },
    {
      "hash": "sha256-nwSD8ojaBwHreOMCbPwumcSdYvGWsJ+zF3JCCwtxjdE=",
      "url": "lib/font-awesome/css/regular.min.css"
    },
    {
      "hash": "sha256-C/Ef75D5+uSL2arcoMNHBmYuffoB0m9Cmg63rM3p6bg=",
      "url": "lib/font-awesome/css/solid.css"
    },
    {
      "hash": "sha256-Mqo3bISkTKOA5aPhCBt3wTDImFXCe71qEUjDeFXmR2A=",
      "url": "lib/font-awesome/css/solid.min.css"
    },
    {
      "hash": "sha256-xsulS9mTk1DycLpUR4vpBXAqglbjv1an2Hi8/9pR09E=",
      "url": "lib/font-awesome/css/svg-with-js.css"
    },
    {
      "hash": "sha256-SgZTtvZfRe/VfWcRPgOQQt/qZu3CSY1IXefpvs0spyo=",
      "url": "lib/font-awesome/css/svg-with-js.min.css"
    },
    {
      "hash": "sha256-RENa3IhOzcI38JXkD6sbGDIqJkRKky6vIbV2q0i2h5I=",
      "url": "lib/font-awesome/css/v4-font-face.css"
    },
    {
      "hash": "sha256-0Tj317fYNYwIoW2g/+uwP9VSbl4rqGBIPNQoAsrABDE=",
      "url": "lib/font-awesome/css/v4-font-face.min.css"
    },
    {
      "hash": "sha256-zyl2Tcca9mvCFy9FZyTi4JqJV2hb8uRHdWgUK74BLVQ=",
      "url": "lib/font-awesome/css/v4-shims.css"
    },
    {
      "hash": "sha256-NenkrayirgAPNJ9MoFBhLyoMnuMPKn1acE9Ea7mmCU8=",
      "url": "lib/font-awesome/css/v4-shims.min.css"
    },
    {
      "hash": "sha256-wnhEE9PW+N6R6RO0GEfGr8y+gSqR7apesDBDhDTIvhA=",
      "url": "lib/font-awesome/css/v5-font-face.css"
    },
    {
      "hash": "sha256-7kujB3S58VbVnoBENczyy49S13GgFV2YQjho/BkYC6o=",
      "url": "lib/font-awesome/css/v5-font-face.min.css"
    },
    {
      "hash": "sha256-e05UO9K/RH7LNssztovjK6SOex4OzxDEhFdo1iPWvMw=",
      "url": "lib/font-awesome/js/all.js"
    },
    {
      "hash": "sha256-JmqsqK+WCTutosShNPzEsqSeOgNhFjBw0ZHgX0jLDHU=",
      "url": "lib/font-awesome/js/all.min.js"
    },
    {
      "hash": "sha256-BWyQc21mYHj9qSk+bVn4bYLjntYL+YaQVcu8+R/Ks8E=",
      "url": "lib/font-awesome/js/brands.js"
    },
    {
      "hash": "sha256-wjlpg5z2aiUgyB3NxCsPCuPNJMrBA3BR+5ebDwunNzo=",
      "url": "lib/font-awesome/js/brands.min.js"
    },
    {
      "hash": "sha256-jJtt6WUAvY2IaX9IeKFpiZy9jbBeSuGqRnEgZbJlQZo=",
      "url": "lib/font-awesome/js/conflict-detection.js"
    },
    {
      "hash": "sha256-Zt++udqhkUkfT+c7/fUOksWB4tjbBv3pJ2v69b/f/WE=",
      "url": "lib/font-awesome/js/conflict-detection.min.js"
    },
    {
      "hash": "sha256-lU+0AqIXRYjZw/FcJOQatVQaJi7b5H5BMMUgkx0il48=",
      "url": "lib/font-awesome/js/fontawesome.js"
    },
    {
      "hash": "sha256-H/9sNusNcxdIfhl2DsRgwWG7haXOOmNKjns4EF9OFpU=",
      "url": "lib/font-awesome/js/fontawesome.min.js"
    },
    {
      "hash": "sha256-b/oQ1rjGqoSOH91dj+TqmEoysKr0+IUMFtIf2z2NSEI=",
      "url": "lib/font-awesome/js/regular.js"
    },
    {
      "hash": "sha256-WCVkU7bSzVzdSzqvWUGOvzz5qb8FGGPnYLrx33784ko=",
      "url": "lib/font-awesome/js/regular.min.js"
    },
    {
      "hash": "sha256-RhsdOhiPGN2rYmsr5iTRE35Ye8UAbr7TprNTs7z4VbM=",
      "url": "lib/font-awesome/js/solid.js"
    },
    {
      "hash": "sha256-mnXIyLjCxP01W+jeTAk5N7/NAVAIG3BISp9BcCdP0OI=",
      "url": "lib/font-awesome/js/solid.min.js"
    },
    {
      "hash": "sha256-QY8o2c7S8ChtlohOVIcQ+vJIDhe/OzKk4MRqQWLRa3Y=",
      "url": "lib/font-awesome/js/v4-shims.js"
    },
    {
      "hash": "sha256-KZCZy+CnjXO92XEs0WcqRA6onAbHMR2j87rCTVbHydk=",
      "url": "lib/font-awesome/js/v4-shims.min.js"
    },
    {
      "hash": "sha256-7DYXyyKibApzcQ/lDvzDS9uQ8VqVPU/VMhMoUWoeghs=",
      "url": "lib/font-awesome/sprites/brands.svg"
    },
    {
      "hash": "sha256-iyy/DI6FN509aXukfk2OmfGR6u3PbnKTnudEIVlPRbE=",
      "url": "lib/font-awesome/sprites/regular.svg"
    },
    {
      "hash": "sha256-i8lj2RKmQpJGwEeIUTJ3WHob3OvaZKyf71NvVY+DBcc=",
      "url": "lib/font-awesome/sprites/solid.svg"
    },
    {
      "hash": "sha256-HV5ebMkQvbrJyNT+JcmCGHpXvpjl6Z9+yqBlPEg3fRw=",
      "url": "lib/font-awesome/webfonts/fa-brands-400.ttf"
    },
    {
      "hash": "sha256-kzdwlXSHMGd9f0ElQs8J8slhLjgpv4L9vV05Khj6MAA=",
      "url": "lib/font-awesome/webfonts/fa-brands-400.woff2"
    },
    {
      "hash": "sha256-FeKH3ZaU7JzdnLaWT74xIPtilYr/rsjNgrLEUR+0vnw=",
      "url": "lib/font-awesome/webfonts/fa-regular-400.ttf"
    },
    {
      "hash": "sha256-A72qlfoJJYudM4iqoVipbbKH+VTbjWhqN1a0BXuz0LA=",
      "url": "lib/font-awesome/webfonts/fa-regular-400.woff2"
    },
    {
      "hash": "sha256-ny3yCMTLWM8uGEugof1auQzZsz0VsmBn7wApMeDY6/I=",
      "url": "lib/font-awesome/webfonts/fa-solid-900.ttf"
    },
    {
      "hash": "sha256-ZQX5+/Z3revAZ9ZQSX/adO0kYiYyweLRPU8PiaRupTY=",
      "url": "lib/font-awesome/webfonts/fa-solid-900.woff2"
    },
    {
      "hash": "sha256-F+QUGJBWlx8hKzWBqAa516iXhwPvuTogse5O/RbrpbQ=",
      "url": "lib/font-awesome/webfonts/fa-v4compatibility.ttf"
    },
    {
      "hash": "sha256-71zGbMbD6o/ssp8IYXz5BZUoY8lT28igH860r0IIC5w=",
      "url": "lib/font-awesome/webfonts/fa-v4compatibility.woff2"
    },
    {
      "hash": "sha256-ymZGER7gVnRwS5EYUBfVB7ArwR7AVCXCcWcZ994qi8w=",
      "url": "lib/tinymce/icons/default/icons.js"
    },
    {
      "hash": "sha256-xW7OXh/LTbtGx/i8c7UXjjnZw3N8AKMcP3btucv+WKs=",
      "url": "lib/tinymce/icons/default/icons.min.js"
    },
    {
      "hash": "sha256-4xiiJe9jKU26gAZ4m19HabfPz6jvGu1zlV2Z4+eBD9Q=",
      "url": "lib/tinymce/langs/README.md"
    },
    {
      "hash": "sha256-L8047Owb7c8SyPx7bYdFNwKK42oDzp1OmiQ+qDcf5+o=",
      "url": "lib/tinymce/license.md"
    },
    {
      "hash": "sha256-zVDue2UEu+zNDddOxHU932DIaTIxIiUuh2KXSjUUrDM=",
      "url": "lib/tinymce/models/dom/model.js"
    },
    {
      "hash": "sha256-l5+D4jTiH4dl9OHUgc6IudrFKCTXf/7b6EXCgIVRklI=",
      "url": "lib/tinymce/models/dom/model.min.js"
    },
    {
      "hash": "sha256-kuYq0D/tDtwhSpvQWfZDLxC2AD2HBHj3TvUGZscxGWc=",
      "url": "lib/tinymce/plugins/accordion/plugin.js"
    },
    {
      "hash": "sha256-LmYZsMweBpN+yC0nuOqJFxK46dHdUjsZCUmtlNmiTks=",
      "url": "lib/tinymce/plugins/accordion/plugin.min.js"
    },
    {
      "hash": "sha256-pNpksFgXBPgUIBDt7KpHGBSeTiPsMEA9ZXvSdkqQoBY=",
      "url": "lib/tinymce/plugins/advlist/plugin.js"
    },
    {
      "hash": "sha256-xR/kh2BMJHd32S4F1T0K3v21zJiwoPM59mmS39lqA5A=",
      "url": "lib/tinymce/plugins/advlist/plugin.min.js"
    },
    {
      "hash": "sha256-SOVdxqae5Cgani5mH/45azXumakmjTOftYz9TqSw/2o=",
      "url": "lib/tinymce/plugins/anchor/plugin.js"
    },
    {
      "hash": "sha256-nxAV2wlvu5KF0zwKdRSqfCnGeDgttnCWzLruXbnwe+I=",
      "url": "lib/tinymce/plugins/anchor/plugin.min.js"
    },
    {
      "hash": "sha256-RKDfjBzVrU7rUToX4OApblu1EasmW3YPzKEvqYyeOtM=",
      "url": "lib/tinymce/plugins/autolink/plugin.js"
    },
    {
      "hash": "sha256-maXRldEfT4ioUiJwzF7Q+9fS/ovUNxrk4fcAiW41m0Y=",
      "url": "lib/tinymce/plugins/autolink/plugin.min.js"
    },
    {
      "hash": "sha256-b0z9wtu2F9Fc/dgc8Yelz8dzENaum6jY+hxOgQnainQ=",
      "url": "lib/tinymce/plugins/autoresize/plugin.js"
    },
    {
      "hash": "sha256-83YukjTAJzPUStFH56+qpKsRlR7Odwpw1dYh/FnJLpc=",
      "url": "lib/tinymce/plugins/autoresize/plugin.min.js"
    },
    {
      "hash": "sha256-x3tk/E7GYH6l6GrnJ8TRrnLkHKt/WzJARVa+1k/v/3g=",
      "url": "lib/tinymce/plugins/autosave/plugin.js"
    },
    {
      "hash": "sha256-i+XtKX2ESd5KNGRHJQO7/i+kEPTt06at04uwpmUKDVo=",
      "url": "lib/tinymce/plugins/autosave/plugin.min.js"
    },
    {
      "hash": "sha256-/DFNlvDpuifO8XZn11sBRBIaiqp2O+lts+St8Uu1xvU=",
      "url": "lib/tinymce/plugins/charmap/plugin.js"
    },
    {
      "hash": "sha256-N92xligblrS3ECpkuIAluubG1FN8BwG3SGPUUt1Wfus=",
      "url": "lib/tinymce/plugins/charmap/plugin.min.js"
    },
    {
      "hash": "sha256-pmZJclr25k7fs4swo4gvuKusT0P6ElLlpvRO4V9KjnE=",
      "url": "lib/tinymce/plugins/code/plugin.js"
    },
    {
      "hash": "sha256-H6AGSnRxpRPjN3c2IqCecPC66fCo+d/KcQQS3KJoPFM=",
      "url": "lib/tinymce/plugins/code/plugin.min.js"
    },
    {
      "hash": "sha256-NOLM/msw1vUhwbV9mGJsvHAi7FcnCXrt8svJ+hcWU1c=",
      "url": "lib/tinymce/plugins/codesample/plugin.js"
    },
    {
      "hash": "sha256-iEgIVKwLgq4JRLgiHIiFeWQ1BG9UmsEjv7BuC0NQtCo=",
      "url": "lib/tinymce/plugins/codesample/plugin.min.js"
    },
    {
      "hash": "sha256-wjWCs+q0lakd8dIg7dR1c3PupW8XwymymD7dYYWj4BU=",
      "url": "lib/tinymce/plugins/directionality/plugin.js"
    },
    {
      "hash": "sha256-BFbEp8pjtwrAQSORC9RvZWj663QmxjwzxFp/cBHi4bg=",
      "url": "lib/tinymce/plugins/directionality/plugin.min.js"
    },
    {
      "hash": "sha256-HUSrMDE/gPFhzb1KoZuCEGxbRLDTVw7EK0xrnLV2MLw=",
      "url": "lib/tinymce/plugins/emoticons/js/emojiimages.js"
    },
    {
      "hash": "sha256-Yi8+3XiEXXJBg306XlIlzIlkaaU8oAExSfOkX/mUxiw=",
      "url": "lib/tinymce/plugins/emoticons/js/emojiimages.min.js"
    },
    {
      "hash": "sha256-cd/Y1gLoV++Ss2+uK/pBed5ezvmZvvkKUbiNZlAfeNg=",
      "url": "lib/tinymce/plugins/emoticons/js/emojis.js"
    },
    {
      "hash": "sha256-30BB3MnYALk580yLGNxMi7Vc5UZhXFSw1ni/0MSode8=",
      "url": "lib/tinymce/plugins/emoticons/js/emojis.min.js"
    },
    {
      "hash": "sha256-7psgWavepLjis90H3cMojhf/vkzzd8jBhJomsPwYHrQ=",
      "url": "lib/tinymce/plugins/emoticons/plugin.js"
    },
    {
      "hash": "sha256-O3FbdHoLDP0Xptj40hRWAVICZs6++FrQ4AouFNggqQQ=",
      "url": "lib/tinymce/plugins/emoticons/plugin.min.js"
    },
    {
      "hash": "sha256-kTKP0G2wXs+Ygr2wIrmwVEfhxtlDDCckUA+Obk3OnHU=",
      "url": "lib/tinymce/plugins/fullscreen/plugin.js"
    },
    {
      "hash": "sha256-A3yyhvG2sAQEefWk8LrvaFd2sdancO9yfXlNXCh/6l0=",
      "url": "lib/tinymce/plugins/fullscreen/plugin.min.js"
    },
    {
      "hash": "sha256-quh66B5nWLsTSRKwSISYBUyzT5gJzGvvpzw3/jXrxxQ=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ar.js"
    },
    {
      "hash": "sha256-Ttjq9S2AQqWwb24BeUvsnFJKOF/lTXZekom4RxMyxHY=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/bg_BG.js"
    },
    {
      "hash": "sha256-zz778ZGHiKVtx9lnLWRPdZ9V2KZbZtf6r1wQk8YMkVI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ca.js"
    },
    {
      "hash": "sha256-Ceq9VfcatLpT4Kxb8L96iSlthVtw8eAasrGfyj/lJqM=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/cs.js"
    },
    {
      "hash": "sha256-IoV7J1x5M5z/E1EiVNRtmhm4G85RxU/0z7h/HSWjzcc=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/da.js"
    },
    {
      "hash": "sha256-NTzqj+9LLEqvQoILB1JFmmvZNkEzgVVFRABrhc8eZa0=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/de.js"
    },
    {
      "hash": "sha256-sSD7hqwCAL7c+vpUcAkP0arfTTlmzzuLAqso7n0nc30=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/el.js"
    },
    {
      "hash": "sha256-dMOYzk0QsIvB5BZjkpZchkHIhqNufPZThph9RoWkTkY=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/en.js"
    },
    {
      "hash": "sha256-YhdytiC7ZG75z5o7ChofcjT7pFry/hs1DE36LIkKelA=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/es.js"
    },
    {
      "hash": "sha256-CD/SqbEAcgNsFEUukQqWX022Q+CKlYDXtJm7iJY1mCc=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/eu.js"
    },
    {
      "hash": "sha256-4Etz6wcA5CtwlcnjIlDo0xjSlyv7t52uxZeFX3iPIYI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/fa.js"
    },
    {
      "hash": "sha256-xx7aqunXdLs0mkOyvaqw4AqDFEp6s9zzWmEM1cIsQ2s=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/fi.js"
    },
    {
      "hash": "sha256-0LOtcD51DipxTzvK5uUXdhTBVhR72rBEoj0ZQEd8rQs=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/fr_FR.js"
    },
    {
      "hash": "sha256-YXj6rApTwjrwl5Ro0gF14gIRz1R/dNb6vbXdx1h3k7A=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/he_IL.js"
    },
    {
      "hash": "sha256-dKGUfUVYlvJXOwDrgRiZa2hRk/s2hMsbIwsZlCWVoSw=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/hi.js"
    },
    {
      "hash": "sha256-oD5ZoN1lx1Kf0WcwCzHbTrHTTe7NSYI6RiGaxlgxJhw=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/hr.js"
    },
    {
      "hash": "sha256-kJLj3oqTZU+ZunPmXKdalFmlRxJQNtYRvqn7hLdNY7E=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/hu_HU.js"
    },
    {
      "hash": "sha256-DVO0osfUXd2GQ6eY3TlaD4pqByJjjvnRWkqUbjqdhlI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/id.js"
    },
    {
      "hash": "sha256-gT5xsjrpTnTB5m2FRIj+svW2W7N0jFv8L+rTWpMZVMs=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/it.js"
    },
    {
      "hash": "sha256-khU7ZAwmFUdUtMXUERJULWm4JEDOiNn3q7VetHVR9jw=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ja.js"
    },
    {
      "hash": "sha256-I12k5IZOnE9UAO+a/e+HfPkHfWMptzvzcDlh3U+qbcI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/kk.js"
    },
    {
      "hash": "sha256-nEFAaf1V3GvE3aWqJe8T2TZMg7CJ/UDIGAYcKC8uDJA=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ko_KR.js"
    },
    {
      "hash": "sha256-E31Fzr4Y2F+Wdf97X5TEtdtzmLZbwsSgeeINA5fSTzI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ms.js"
    },
    {
      "hash": "sha256-v4NDzqRm+wvdJ9jeG3L8OQw/oRRbK81AQPV7f9lNKVI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/nb_NO.js"
    },
    {
      "hash": "sha256-/Na8tkwFWY/xqQPdkM35o80oXVgNQ2zPeO/5nw7AU9o=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/nl.js"
    },
    {
      "hash": "sha256-ajz3FIxEZ+JfJETFaKUbFEV0RCOumf+titQyKUyqDEU=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/pl.js"
    },
    {
      "hash": "sha256-cX3AtlOKEI0emHkJ2sl77KyEGz4LkIsrTZRm1xvJ0FU=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/pt_BR.js"
    },
    {
      "hash": "sha256-/EuHnLDVjFjicIvuVhigN6Gn3AN4OzG/70LRxavxUXY=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/pt_PT.js"
    },
    {
      "hash": "sha256-Q+LE4gPNEKRNJ6sdrNad5/6+IHslm3VkSO+Uraa3/fI=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ro.js"
    },
    {
      "hash": "sha256-S536zroPll7qSPHBtP4Ra3UzN7w1Z7Nai57J4WdSIHY=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/ru.js"
    },
    {
      "hash": "sha256-zek5rKVOP1An3kYvNlo2offlUHjEbDih2P/fzOPo+8c=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/sk.js"
    },
    {
      "hash": "sha256-4jh0s/W8GrrflWifAgMYYXHIRUxyg6Md7h+yaJ2upEg=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/sl_SI.js"
    },
    {
      "hash": "sha256-uEb1IyIhbvNXcq2ZQvkXFWzix8qM8Obmxo21UxQm3/o=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/sv_SE.js"
    },
    {
      "hash": "sha256-8xB0ot27Znge1383MgEFNNOOtpBEVsXxqAVE+vhFHGM=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/th_TH.js"
    },
    {
      "hash": "sha256-63VDYg/jmu7a6xD7DKW7Xba5yMYrVJoBGFfdRE1JdR4=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/tr.js"
    },
    {
      "hash": "sha256-DYYl2ucKhUoko7h2yAIuyyOonQzIZL27rBh0c5MIpBA=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/uk.js"
    },
    {
      "hash": "sha256-o4QQImYYeS71L1XH299ZVL9FEwWu80bGqvmwd07/2mk=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/vi.js"
    },
    {
      "hash": "sha256-AG/Tovpt8fH4t52WsZbn5MsTZ3zg064QJQMizCcnId4=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/zh_CN.js"
    },
    {
      "hash": "sha256-g3MaeLVVCde4sHbtc07+cgfFf+pN9ILtNsdyAJ/LYUc=",
      "url": "lib/tinymce/plugins/help/js/i18n/keynav/zh_TW.js"
    },
    {
      "hash": "sha256-Z03i9u71uZsNyko/y6l1KfW1YjQJ6ixXD5JXFDYNFcw=",
      "url": "lib/tinymce/plugins/help/plugin.js"
    },
    {
      "hash": "sha256-imi8pjRn/I0vD8rAVXsm5HbHFPwbuSX62QFGRMvwV08=",
      "url": "lib/tinymce/plugins/help/plugin.min.js"
    },
    {
      "hash": "sha256-jwU0hRaxDRPrX8FXXx7exO5RLqNaNJst5XQwLJi1SZI=",
      "url": "lib/tinymce/plugins/image/plugin.js"
    },
    {
      "hash": "sha256-WPSJsr8JLXskki17XzrxufxfselQ6cW5hzcRluZz3/I=",
      "url": "lib/tinymce/plugins/image/plugin.min.js"
    },
    {
      "hash": "sha256-ICaWrXw0Pvu0FQI4cwgkXsn6MapMVRSeZ/vzQ9ygqnk=",
      "url": "lib/tinymce/plugins/importcss/plugin.js"
    },
    {
      "hash": "sha256-4g3nqefrHXRAWgc6C7pVINL1RtfGm6ckfdtclwp9kgE=",
      "url": "lib/tinymce/plugins/importcss/plugin.min.js"
    },
    {
      "hash": "sha256-Nxj5SRKlilgNTJnzSbEf1ZNs8bBdnaBm3J7lIeon0Mo=",
      "url": "lib/tinymce/plugins/insertdatetime/plugin.js"
    },
    {
      "hash": "sha256-RHSJQL5lm2evGiQou6vsdSUj/0eymmlmWLSwg5ix/cE=",
      "url": "lib/tinymce/plugins/insertdatetime/plugin.min.js"
    },
    {
      "hash": "sha256-R7wUBR/3xfzNog5qp8YoiYsk+0nyM5dz1KiWNsHy9Bk=",
      "url": "lib/tinymce/plugins/link/plugin.js"
    },
    {
      "hash": "sha256-EDCjY5Yqo0uCEX2MH6inXcIm1+BxAbhoyhN23jJk6aQ=",
      "url": "lib/tinymce/plugins/link/plugin.min.js"
    },
    {
      "hash": "sha256-eZDgyj50ZFruRGkWw9agb1H5qyOK897FfRHI3OrZ3gs=",
      "url": "lib/tinymce/plugins/lists/plugin.js"
    },
    {
      "hash": "sha256-tmSsaOGavU7jJDr52bURKb0B16B9BamDAkDP8N0wj7U=",
      "url": "lib/tinymce/plugins/lists/plugin.min.js"
    },
    {
      "hash": "sha256-W6KGs4oL5PbZhJCEYuNuanonmEdnGl8XOIURen7zcic=",
      "url": "lib/tinymce/plugins/media/plugin.js"
    },
    {
      "hash": "sha256-6RoYM8kL8ZTv9XgXYnAbhmtIMI6l05m0HV2wMYD4ay0=",
      "url": "lib/tinymce/plugins/media/plugin.min.js"
    },
    {
      "hash": "sha256-65RzjamE3U0AASkdgersobDOIrTpswmHbHZKeC69BkY=",
      "url": "lib/tinymce/plugins/nonbreaking/plugin.js"
    },
    {
      "hash": "sha256-li7ITTGR7Id7uHaVxDGCb8KjKp2+xJqR87wZE7Z/oAQ=",
      "url": "lib/tinymce/plugins/nonbreaking/plugin.min.js"
    },
    {
      "hash": "sha256-4fNPVV2OCNd0TaFdgUjb/H7OJcmeGecoYRz/rUz7UVo=",
      "url": "lib/tinymce/plugins/pagebreak/plugin.js"
    },
    {
      "hash": "sha256-EcBPg0UMDggKSFhQlw7sbIOdeWObMr5+1BNEe37rx84=",
      "url": "lib/tinymce/plugins/pagebreak/plugin.min.js"
    },
    {
      "hash": "sha256-KqbPsA3CjIddMm3vn4s/NXvyBpincnrUcUIQRiygFjI=",
      "url": "lib/tinymce/plugins/preview/plugin.js"
    },
    {
      "hash": "sha256-vH9KPhjQSxyrKCvMAQL/Nl0tmPYI9zCLSu2/akOalzU=",
      "url": "lib/tinymce/plugins/preview/plugin.min.js"
    },
    {
      "hash": "sha256-DlA6LhVd7ypThUeFC7x/rExsYSPtak9/7ffFImNL91Y=",
      "url": "lib/tinymce/plugins/quickbars/plugin.js"
    },
    {
      "hash": "sha256-GhHfrDZYPaZtEfeoxv7k4F54BD1G9dfEaczUmPQMcwI=",
      "url": "lib/tinymce/plugins/quickbars/plugin.min.js"
    },
    {
      "hash": "sha256-33Sg4aKllMBopfv2dWXKLW2gVSILOTE8I5UK/GQS3Ww=",
      "url": "lib/tinymce/plugins/save/plugin.js"
    },
    {
      "hash": "sha256-ebKHnOBu0TTF4aXOggA/HTREipok5Ki+0/Rv/zFfR/E=",
      "url": "lib/tinymce/plugins/save/plugin.min.js"
    },
    {
      "hash": "sha256-JpoV3vBOae2OW+FxQJ4gNzA3+jdVfCnWJhoRcJt46GA=",
      "url": "lib/tinymce/plugins/searchreplace/plugin.js"
    },
    {
      "hash": "sha256-ympReSvA66tnDPMyMJ2RhhH/lpQcQMKhBMIxDwzeICM=",
      "url": "lib/tinymce/plugins/searchreplace/plugin.min.js"
    },
    {
      "hash": "sha256-cBPilAKyN+kG5QYGlN0lisWGOgZB34EYD0i5If8AH8I=",
      "url": "lib/tinymce/plugins/table/plugin.js"
    },
    {
      "hash": "sha256-yPnni6iQ9W2V+7Q6zftquOPS0E2PYA1XcrVJd80JLoY=",
      "url": "lib/tinymce/plugins/table/plugin.min.js"
    },
    {
      "hash": "sha256-DKL5yXR749yOr+rP4IGAxv/edWDVueb3tZHhSG9BBJk=",
      "url": "lib/tinymce/plugins/visualblocks/plugin.js"
    },
    {
      "hash": "sha256-pA8WO+Uscr35RvQp4e1lda49Nb9TIBsYZfJSkILA0+I=",
      "url": "lib/tinymce/plugins/visualblocks/plugin.min.js"
    },
    {
      "hash": "sha256-ErP9fGbo6F6MibE+VxOOsg/2bpSmwDvRtpmjdYPdZTc=",
      "url": "lib/tinymce/plugins/visualchars/plugin.js"
    },
    {
      "hash": "sha256-WgSXab+ELQcpeRabmnvkGd144+Onzp1okXdZWmmZOOQ=",
      "url": "lib/tinymce/plugins/visualchars/plugin.min.js"
    },
    {
      "hash": "sha256-UW9vDID7BziG7OWRrvsGBoNeCmycYFOE8NBuFYXbW7k=",
      "url": "lib/tinymce/plugins/wordcount/plugin.js"
    },
    {
      "hash": "sha256-DEi3h6O4JMXnlWQ77f5TcCoTqiKH0NvQKqiHI1nMUos=",
      "url": "lib/tinymce/plugins/wordcount/plugin.min.js"
    },
    {
      "hash": "sha256-sxI6nf/7uduK2Lek38GrPJgv2WNw3psxD02hOdgrtCY=",
      "url": "lib/tinymce/skins/content/dark/content.css"
    },
    {
      "hash": "sha256-HiNFQXAmgK2eSaljt3JpvDUdi56IgFYf08NLQBESGoA=",
      "url": "lib/tinymce/skins/content/dark/content.js"
    },
    {
      "hash": "sha256-83xsgS8j757mxFSSTe2Ff8r59BEE6WAi4CdkfOAf3O4=",
      "url": "lib/tinymce/skins/content/dark/content.min.css"
    },
    {
      "hash": "sha256-avMZzwGrce8mKSgirvnUhACxPMmWOeoT0c27q1Qs5dc=",
      "url": "lib/tinymce/skins/content/default/content.css"
    },
    {
      "hash": "sha256-UKi0h7MsUw4vZ0cN6jmJ97qfhpvLtLNFAVuJ19hqZ/k=",
      "url": "lib/tinymce/skins/content/default/content.js"
    },
    {
      "hash": "sha256-QYU4biaqOSt4VWQjXUxv4dRnfk+FvcXTtRfVANMmOpY=",
      "url": "lib/tinymce/skins/content/default/content.min.css"
    },
    {
      "hash": "sha256-eKNm9RJj6CROoHY3FlwS/NDs0qynGm3GR06deIsoZzQ=",
      "url": "lib/tinymce/skins/content/document/content.css"
    },
    {
      "hash": "sha256-hDuYmWg6EjKbVTM+y3LIH6+tAIkcsTbHd/vfFWVjRbw=",
      "url": "lib/tinymce/skins/content/document/content.js"
    },
    {
      "hash": "sha256-nw5QNtj2s1XfHz7ORi0vHEXRY942s9QVNS2e9b9gTvg=",
      "url": "lib/tinymce/skins/content/document/content.min.css"
    },
    {
      "hash": "sha256-dQLzNtO8lWboYJk0l4MSE6OZB1xmJjzW/YgKxYtNhUQ=",
      "url": "lib/tinymce/skins/content/tinymce-5-dark/content.css"
    },
    {
      "hash": "sha256-eya6Olq5dbXJAP3nqXopuGbw9nOBplURdagaDHT3UPU=",
      "url": "lib/tinymce/skins/content/tinymce-5-dark/content.js"
    },
    {
      "hash": "sha256-5i0OOXQ89cnwhKHct3qJbvo5ebiAVJ4huOAjY6ZZcDQ=",
      "url": "lib/tinymce/skins/content/tinymce-5-dark/content.min.css"
    },
    {
      "hash": "sha256-avMZzwGrce8mKSgirvnUhACxPMmWOeoT0c27q1Qs5dc=",
      "url": "lib/tinymce/skins/content/tinymce-5/content.css"
    },
    {
      "hash": "sha256-lgmuU4jdRvd8qn01kGevhFpdAvjWv6jlznO+OkMPn0Q=",
      "url": "lib/tinymce/skins/content/tinymce-5/content.js"
    },
    {
      "hash": "sha256-QYU4biaqOSt4VWQjXUxv4dRnfk+FvcXTtRfVANMmOpY=",
      "url": "lib/tinymce/skins/content/tinymce-5/content.min.css"
    },
    {
      "hash": "sha256-zFT6VCWEBADxBYQhXjIl0Hl8OTUkvDEGjF9uJs2XL3o=",
      "url": "lib/tinymce/skins/content/writer/content.css"
    },
    {
      "hash": "sha256-4PswBFTC1a+uWS+SB0h+4DRc9KAuQNC1dgYfl4P8KoQ=",
      "url": "lib/tinymce/skins/content/writer/content.js"
    },
    {
      "hash": "sha256-Msruq+iXTIdlnL7XVvw5Gs+JOyz9xRA8hsZ8QtGmgvE=",
      "url": "lib/tinymce/skins/content/writer/content.min.css"
    },
    {
      "hash": "sha256-+o1TfCnAVBbL24PUoX/HvmerhnzJVTD0/bYmxP3EgBE=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.css"
    },
    {
      "hash": "sha256-tbXajEavtvVDAbZcvyny/t/IC0yDzKpM6cgvj8qY6U0=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.inline.css"
    },
    {
      "hash": "sha256-hUCWn1hgiaFy8ewOHfERo9ouR1oeExTs4oJwKywGBio=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.inline.js"
    },
    {
      "hash": "sha256-BaHSEsje3yN3S+WC9Y43S5juUNJmYJDuQJBmfM9aRig=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.inline.min.css"
    },
    {
      "hash": "sha256-moP5bT7IT86GjUpng3A+Qs67ofqfZs7Svc2ZZUbb/Hw=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.js"
    },
    {
      "hash": "sha256-6/txktWlzQBn9JQ8vZldbVWUKsHaeLg/c51UkInBxaA=",
      "url": "lib/tinymce/skins/ui/oxide-dark/content.min.css"
    },
    {
      "hash": "sha256-HOCojbBBZV83cyUHl5MRHMoEQmJqK0A2peeMNyizYdI=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.css"
    },
    {
      "hash": "sha256-trpmXrce0aCt8GHMIBQcCyjUWvNR9MBBqXnkd9BUHQU=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.js"
    },
    {
      "hash": "sha256-TpuBcqXhPokCkojlL2inxUgBrPSzI/QJk/bHFMUZpGA=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.min.css"
    },
    {
      "hash": "sha256-BZEpyGabQz7WJyMnSKdvgYetoAyE+wfynHcvviGQyEg=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.shadowdom.css"
    },
    {
      "hash": "sha256-6NfU++JzC1XfBLtAveW2mCfaZT4hPrZCiRyWGkTLH1w=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.shadowdom.js"
    },
    {
      "hash": "sha256-SdjsIJy9xP2h9k3YkR0Sxw5EOTN1LH0fbtL6plw8/rI=",
      "url": "lib/tinymce/skins/ui/oxide-dark/skin.shadowdom.min.css"
    },
    {
      "hash": "sha256-47iO4/ZqPywcDRIzNAWu/YDZr0jEH2lJ8QvJsqZmpys=",
      "url": "lib/tinymce/skins/ui/oxide/content.css"
    },
    {
      "hash": "sha256-tbXajEavtvVDAbZcvyny/t/IC0yDzKpM6cgvj8qY6U0=",
      "url": "lib/tinymce/skins/ui/oxide/content.inline.css"
    },
    {
      "hash": "sha256-8R29OtTwE5XSECtwPZemob8T6GH7CMKjKP1dQNG0Dt8=",
      "url": "lib/tinymce/skins/ui/oxide/content.inline.js"
    },
    {
      "hash": "sha256-BaHSEsje3yN3S+WC9Y43S5juUNJmYJDuQJBmfM9aRig=",
      "url": "lib/tinymce/skins/ui/oxide/content.inline.min.css"
    },
    {
      "hash": "sha256-o1GhXtCGUfJ0+6vjboxoQCER8rVxXpA+qsD5NQ8OPBA=",
      "url": "lib/tinymce/skins/ui/oxide/content.js"
    },
    {
      "hash": "sha256-vL1Y7vs52PNlKoUHSCaKjltTzw/YbZrcmziqIoOtEAs=",
      "url": "lib/tinymce/skins/ui/oxide/content.min.css"
    },
    {
      "hash": "sha256-2UN9P69YyeKUvIA/Y8CCl2nxDt8V/IaaGs36/LWcSd8=",
      "url": "lib/tinymce/skins/ui/oxide/skin.css"
    },
    {
      "hash": "sha256-nQdmHgcwaLYVwhmr9q+i/AON5k3H5TsuibR9bA+r/ZA=",
      "url": "lib/tinymce/skins/ui/oxide/skin.js"
    },
    {
      "hash": "sha256-fEKSxq/vqCxB5AFIlzMBpa40qBKDTK5CkD/Qi73WS3c=",
      "url": "lib/tinymce/skins/ui/oxide/skin.min.css"
    },
    {
      "hash": "sha256-BZEpyGabQz7WJyMnSKdvgYetoAyE+wfynHcvviGQyEg=",
      "url": "lib/tinymce/skins/ui/oxide/skin.shadowdom.css"
    },
    {
      "hash": "sha256-fXs0+ZeXkL0bcCj8Nu8nU0X41ZqR4IyF6ZQe+7otN7w=",
      "url": "lib/tinymce/skins/ui/oxide/skin.shadowdom.js"
    },
    {
      "hash": "sha256-SdjsIJy9xP2h9k3YkR0Sxw5EOTN1LH0fbtL6plw8/rI=",
      "url": "lib/tinymce/skins/ui/oxide/skin.shadowdom.min.css"
    },
    {
      "hash": "sha256-MVYV6waLXEdasdzdKOxtYVmIsWyOtygg0zAxD59Q6+0=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.css"
    },
    {
      "hash": "sha256-tbXajEavtvVDAbZcvyny/t/IC0yDzKpM6cgvj8qY6U0=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.inline.css"
    },
    {
      "hash": "sha256-gPhkQVctbLppnaEf2z12IepgKJfBBuiKDAErR4Gz9HQ=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.inline.js"
    },
    {
      "hash": "sha256-BaHSEsje3yN3S+WC9Y43S5juUNJmYJDuQJBmfM9aRig=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.inline.min.css"
    },
    {
      "hash": "sha256-+RQxmmS4Rjy1qR468PueMN1eiCV435ZyCZ/I9WqMDec=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.js"
    },
    {
      "hash": "sha256-qDfkQ6EJN3iGtyNG27j9tZOMIVoRm61Tu12YCDLBT24=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/content.min.css"
    },
    {
      "hash": "sha256-vE4DFQH+5/2/cyf1ptJo6IwPbtIG4OMmb/4xll37uFc=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.css"
    },
    {
      "hash": "sha256-M5rmqBvUysO+jv9Ob9jJshS96RNF0XoyOKHcNhT3voM=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.js"
    },
    {
      "hash": "sha256-kmZe6Nuui68eh8lHxjCjmBL1NK9cbD6Mfasrp3uHyIM=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.min.css"
    },
    {
      "hash": "sha256-BZEpyGabQz7WJyMnSKdvgYetoAyE+wfynHcvviGQyEg=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.shadowdom.css"
    },
    {
      "hash": "sha256-SEiuth8sXDRX7lSJ1NbI49NXB7Mj/UCNqCRAZexSgFE=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.shadowdom.js"
    },
    {
      "hash": "sha256-SdjsIJy9xP2h9k3YkR0Sxw5EOTN1LH0fbtL6plw8/rI=",
      "url": "lib/tinymce/skins/ui/tinymce-5-dark/skin.shadowdom.min.css"
    },
    {
      "hash": "sha256-47iO4/ZqPywcDRIzNAWu/YDZr0jEH2lJ8QvJsqZmpys=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.css"
    },
    {
      "hash": "sha256-tbXajEavtvVDAbZcvyny/t/IC0yDzKpM6cgvj8qY6U0=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.inline.css"
    },
    {
      "hash": "sha256-7tes2klPwr634KNdajep/AY+LJCJKUY/ar7cdzkUeaU=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.inline.js"
    },
    {
      "hash": "sha256-BaHSEsje3yN3S+WC9Y43S5juUNJmYJDuQJBmfM9aRig=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.inline.min.css"
    },
    {
      "hash": "sha256-6owF7f7G9NgunA3mhXj6X2HAmY6iDqbx7oYaLFt1i5g=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.js"
    },
    {
      "hash": "sha256-vL1Y7vs52PNlKoUHSCaKjltTzw/YbZrcmziqIoOtEAs=",
      "url": "lib/tinymce/skins/ui/tinymce-5/content.min.css"
    },
    {
      "hash": "sha256-fb2Iz5tq9oFpLbe5OYuNl8wgLZyYV7KxV9XTT7GDoDs=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.css"
    },
    {
      "hash": "sha256-tAtV8lRos76HyAMt7RzF6XqLpCLTTSkwkojzkj6fevA=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.js"
    },
    {
      "hash": "sha256-uz9DGVKAPcXOBsReFqMJ3oPV+A9aNSB6VwpvT10YNfw=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.min.css"
    },
    {
      "hash": "sha256-BZEpyGabQz7WJyMnSKdvgYetoAyE+wfynHcvviGQyEg=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.shadowdom.css"
    },
    {
      "hash": "sha256-X1Js0lI8glpFOH1fhQ/b/UxC072hSAFhyM9eqmKIzVI=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.shadowdom.js"
    },
    {
      "hash": "sha256-SdjsIJy9xP2h9k3YkR0Sxw5EOTN1LH0fbtL6plw8/rI=",
      "url": "lib/tinymce/skins/ui/tinymce-5/skin.shadowdom.min.css"
    },
    {
      "hash": "sha256-oq2vC9ua4q9GyYgnqkB+DJyr2DD/AwXcJYvFgokl4Lc=",
      "url": "lib/tinymce/themes/silver/theme.js"
    },
    {
      "hash": "sha256-WcsWPy4u4+z7uVDoeGU+pbPRJ1/Ml9mFLJ18maSbhRE=",
      "url": "lib/tinymce/themes/silver/theme.min.js"
    },
    {
      "hash": "sha256-BoNN2nxzvqmwuaDWVIOXxSGAsJpTRbGnxnBkLDPoLO4=",
      "url": "lib/tinymce/tinymce.d.ts"
    },
    {
      "hash": "sha256-bzArTKndPckRKZkmOHdZ2tAUkVkgXzKtl7sc5c7gTUM=",
      "url": "lib/tinymce/tinymce.js"
    },
    {
      "hash": "sha256-Y9ZLPRq0aEgeOZaXVRBEwM/q5fezkTaWfhdHC8WpSm8=",
      "url": "lib/tinymce/tinymce.min.js"
    },
    {
      "hash": "sha256-yopeqjzCxvOljQcP8+8AxtYczVsbPWsimEpmpScvv8U=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    },
    {
      "hash": "sha256-dI5tA6VZrJCdBLn6kH/KNCTGvwCqRbytP2oHI45Y9ss=",
      "url": "sounds/confirm.mp3"
    },
    {
      "hash": "sha256-nuHoXpaVa1FhoV19gNnhp6q3A6BAdZRFZBRhDdr5diw=",
      "url": "sounds/confirm.wav"
    },
    {
      "hash": "sha256-oP2usefdxWxMcSsW3WplHePWjwRgiy+dxB2CkRNUtzM=",
      "url": "sounds/error.mp3"
    },
    {
      "hash": "sha256-xHY3p10KekDO2a5oEeTwKgASJ3k3srupwIRNQAEZtkw=",
      "url": "sounds/error.wav"
    },
    {
      "hash": "sha256-IIgd78FwTPvw4Uq3Y48lHSu3j3Sui+pR6NbkP7yJve8=",
      "url": "sounds/prompt.mp3"
    },
    {
      "hash": "sha256-atISTJHx5bltFBLnTeBc65UrQfBQgZFEOq2xW5MA/5Y=",
      "url": "sounds/question2.mp3"
    },
    {
      "hash": "sha256-oLBhWR4pGfQ6/46q/VkR0lAxstWRFKE/Pc4NpSuzF7A=",
      "url": "sounds/question3.mp3"
    },
    {
      "hash": "sha256-u9+XNW0YZvrLlfnAXY4RCYkKT8dbQjDCdMVwMD/3vUQ=",
      "url": "sounds/question5.mp3"
    },
    {
      "hash": "sha256-D8t6ABt/rdwaUSD6leTLlU1gFjVDD/Wa8yLZFM5xMfo=",
      "url": "sounds/question6.mp3"
    }
  ]
};
